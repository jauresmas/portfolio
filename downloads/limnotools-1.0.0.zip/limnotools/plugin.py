"""QGIS plugin entry point: provider, toolbar button, menu and dock panel."""

import os

from qgis.core import QgsApplication, QgsSettings
from qgis.PyQt.QtCore import QCoreApplication, Qt, QTranslator, QUrl
from qgis.PyQt.QtGui import QDesktopServices, QIcon

from .algorithms.base import HELP_URL
from .compat import QAction
from .provider import LimnoToolsProvider

PLUGIN_DIR = os.path.dirname(__file__)


class LimnoToolsPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.provider = None
        self.dock = None
        self.actions = []
        self.translator = None
        self._load_translation()

    # ------------------------------------------------------------------ i18n
    def _load_translation(self):
        locale = (QgsSettings().value("locale/userLocale", "") or "")[:2]
        path = os.path.join(PLUGIN_DIR, "i18n", f"limnotools_{locale}.qm")
        if locale and os.path.exists(path):
            self.translator = QTranslator()
            if self.translator.load(path):
                QCoreApplication.installTranslator(self.translator)

    @staticmethod
    def tr(text):
        return QCoreApplication.translate("LimnoTools", text)

    # ------------------------------------------------------------ processing
    def initProcessing(self):  # noqa: N802  (QGIS plugin API)
        if self.provider is not None:
            return
        self.provider = LimnoToolsProvider()
        QgsApplication.processingRegistry().addProvider(self.provider)

    # ------------------------------------------------------------------- GUI
    def initGui(self):  # noqa: N802  (QGIS plugin API)
        self.initProcessing()
        icon = QIcon(os.path.join(PLUGIN_DIR, "icons", "icon.svg"))

        panel = QAction(icon, self.tr("LimnoTools panel"), self.iface.mainWindow())
        panel.setCheckable(True)
        panel.setToolTip(self.tr("LimnoTools: lake bathymetry and limnology"))
        panel.toggled.connect(self.toggle_dock)
        self.iface.addToolBarIcon(panel)
        self.iface.addPluginToMenu("&LimnoTools", panel)
        self.panel_action = panel

        help_action = QAction(QgsApplication.getThemeIcon("/mActionHelpContents.svg"),
                              self.tr("Documentation"), self.iface.mainWindow())
        help_action.triggered.connect(lambda: QDesktopServices.openUrl(QUrl(HELP_URL)))
        self.iface.addPluginToMenu("&LimnoTools", help_action)
        self.actions = [panel, help_action]

    def unload(self):
        for action in self.actions:
            self.iface.removePluginMenu("&LimnoTools", action)
            self.iface.removeToolBarIcon(action)
        self.actions = []
        if self.dock is not None:
            self.dock.cleanup()
            self.iface.removeDockWidget(self.dock)
            self.dock.deleteLater()
            self.dock = None
        if self.provider is not None:
            QgsApplication.processingRegistry().removeProvider(self.provider)
            self.provider = None
        if self.translator is not None:
            QCoreApplication.removeTranslator(self.translator)
            self.translator = None

    def toggle_dock(self, checked):
        if self.dock is None:
            from .gui.dock import LimnoDock

            self.dock = LimnoDock(self.iface)
            self.iface.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, self.dock)
            self.dock.visibilityChanged.connect(self._sync_action)
        self.dock.setVisible(checked)
        if checked:
            self.dock.raise_()

    def _sync_action(self, visible):
        if self.panel_action.isChecked() != visible:
            self.panel_action.blockSignals(True)
            self.panel_action.setChecked(visible)
            self.panel_action.blockSignals(False)
