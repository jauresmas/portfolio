"""Compatibility layer between QGIS 3.28+ (Qt5) and QGIS 4 (Qt6).

QGIS moved many enums to the ``Qgis`` namespace (3.30 to 3.38) and Qt6
removed ``QVariant`` field types. Everything version dependent lives here so
the rest of the plugin stays clean.
"""

from qgis.core import (
    Qgis,
    QgsField,
    QgsProcessing,
    QgsProcessingParameterField,
    QgsProcessingParameterNumber,
    QgsWkbTypes,
)

try:  # Qt6 / QGIS >= 3.38
    from qgis.PyQt.QtCore import QMetaType

    _DOUBLE = QMetaType.Type.Double
    _INT = QMetaType.Type.Int
    _STRING = QMetaType.Type.QString
    _HAS_METATYPE_FIELDS = Qgis.QGIS_VERSION_INT >= 33800
except (ImportError, AttributeError):  # pragma: no cover
    _HAS_METATYPE_FIELDS = False

if not _HAS_METATYPE_FIELDS:
    from qgis.PyQt.QtCore import QVariant

    _DOUBLE = QVariant.Double
    _INT = QVariant.Int
    _STRING = QVariant.String

try:
    from qgis.PyQt.QtGui import QAction  # Qt6
except ImportError:  # pragma: no cover
    from qgis.PyQt.QtWidgets import QAction  # noqa: F401  Qt5


def double_field(name, length=20, precision=3):
    return QgsField(name, _DOUBLE, "double", length, precision)


def int_field(name):
    return QgsField(name, _INT, "integer", 10, 0)


def string_field(name, length=50):
    return QgsField(name, _STRING, "string", length, 0)


def _enum(new_path, legacy):
    """Return the ``Qgis`` scoped enum value when it exists, else ``legacy``."""
    obj = Qgis
    for part in new_path.split("."):
        obj = getattr(obj, part, None)
        if obj is None:
            return legacy
    return obj


NUMBER_DOUBLE = _enum("ProcessingNumberParameterType.Double", getattr(QgsProcessingParameterNumber, "Double", None))
NUMBER_INTEGER = _enum("ProcessingNumberParameterType.Integer", getattr(QgsProcessingParameterNumber, "Integer", None))
FIELD_NUMERIC = _enum("ProcessingFieldParameterDataType.Numeric", getattr(QgsProcessingParameterField, "Numeric", None))
FIELD_ANY = _enum("ProcessingFieldParameterDataType.Any", getattr(QgsProcessingParameterField, "Any", None))

SOURCE_POINT = _enum("ProcessingSourceType.VectorPoint", getattr(QgsProcessing, "TypeVectorPoint", None))
SOURCE_POLYGON = _enum("ProcessingSourceType.VectorPolygon", getattr(QgsProcessing, "TypeVectorPolygon", None))
SOURCE_ANY_GEOMETRY = _enum("ProcessingSourceType.VectorAnyGeometry",
                            getattr(QgsProcessing, "TypeVectorAnyGeometry", None))
SOURCE_LINE = _enum("ProcessingSourceType.VectorLine", getattr(QgsProcessing, "TypeVectorLine", None))
SOURCE_NO_GEOMETRY = _enum("ProcessingSourceType.Vector", getattr(QgsProcessing, "TypeVector", None))

WKB_POINT = _enum("WkbType.Point", getattr(QgsWkbTypes, "Point", None))
WKB_LINESTRING = _enum("WkbType.LineString", getattr(QgsWkbTypes, "LineString", None))
WKB_MULTILINESTRING = _enum("WkbType.MultiLineString", getattr(QgsWkbTypes, "MultiLineString", None))
WKB_MULTIPOLYGON = _enum("WkbType.MultiPolygon", getattr(QgsWkbTypes, "MultiPolygon", None))
WKB_NOGEOMETRY = _enum("WkbType.NoGeometry", getattr(QgsWkbTypes, "NoGeometry", None))

GEOMETRY_POLYGON = _enum("GeometryType.Polygon", getattr(QgsWkbTypes, "PolygonGeometry", None))
GEOMETRY_POINT = _enum("GeometryType.Point", getattr(QgsWkbTypes, "PointGeometry", None))

MESSAGE_SUCCESS = _enum("MessageLevel.Success", getattr(Qgis, "Success", None))
MESSAGE_WARNING = _enum("MessageLevel.Warning", getattr(Qgis, "Warning", None))
MESSAGE_CRITICAL = _enum("MessageLevel.Critical", getattr(Qgis, "Critical", None))
MESSAGE_INFO = _enum("MessageLevel.Info", getattr(Qgis, "Info", None))


def set_advanced(parameter):
    """Show a Processing parameter in the 'Advanced' section of the dialog."""
    if hasattr(Qgis, "ProcessingParameterFlag"):
        advanced = Qgis.ProcessingParameterFlag.Advanced
    else:  # pragma: no cover  QGIS < 3.36
        from qgis.core import QgsProcessingParameterDefinition

        advanced = QgsProcessingParameterDefinition.FlagAdvanced
    parameter.setFlags(parameter.flags() | advanced)
    return parameter


def flag_value(flag):
    """Return an int for Qt flags under both PyQt5 and PyQt6."""
    try:
        return int(flag)
    except TypeError:  # pragma: no cover  PyQt6 enums
        return flag.value


try:
    from qgis.core import QgsFeatureSink

    FAST_INSERT = QgsFeatureSink.Flag.FastInsert
except AttributeError:  # pragma: no cover
    FAST_INSERT = QgsFeatureSink.FastInsert
