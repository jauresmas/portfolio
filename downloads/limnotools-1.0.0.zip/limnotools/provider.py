"""Processing provider registering the LimnoTools algorithms."""

from qgis.core import QgsProcessingProvider

from .algorithms.base import icon, plugin_version
from .algorithms.bathymetry import BathymetryAlgorithm
from .algorithms.fetch import FetchAlgorithm
from .algorithms.hypsometry import HypsometryAlgorithm
from .algorithms.isobaths import IsobathsAlgorithm
from .algorithms.morphometry import MorphometryAlgorithm
from .algorithms.stratification import StratificationAlgorithm
from .algorithms.trophic import TrophicStateAlgorithm

ALGORITHMS = (
    BathymetryAlgorithm,
    IsobathsAlgorithm,
    MorphometryAlgorithm,
    HypsometryAlgorithm,
    FetchAlgorithm,
    StratificationAlgorithm,
    TrophicStateAlgorithm,
)


class LimnoToolsProvider(QgsProcessingProvider):
    def id(self):
        return "limnotools"

    def name(self):
        return "LimnoTools"

    def longName(self):  # noqa: N802
        return f"LimnoTools {plugin_version()}"

    def icon(self):
        return icon("icon")

    def svgIconPath(self):  # noqa: N802
        from .algorithms.base import ICONS_DIR
        import os

        return os.path.join(ICONS_DIR, "icon.svg")

    def loadAlgorithms(self):  # noqa: N802
        for algorithm in ALGORITHMS:
            self.addAlgorithm(algorithm())
