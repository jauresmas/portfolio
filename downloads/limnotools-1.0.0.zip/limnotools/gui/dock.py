"""LimnoTools dock panel."""

import csv
import json
import os
import shutil

from qgis.core import (
    Qgis,
    QgsApplication,
    QgsMapLayerProxyModel,
    QgsProcessingAlgRunnerTask,
    QgsProcessingContext,
    QgsProcessingFeedback,
    QgsProcessingUtils,
    QgsProject,
    QgsRasterLayer,
    QgsSettings,
    QgsVectorLayer,
)
from qgis.gui import QgsDockWidget, QgsDoubleSpinBox, QgsFieldComboBox, QgsFileWidget, QgsMapLayerComboBox
from qgis.PyQt.QtCore import QCoreApplication, Qt, QUrl
from qgis.PyQt.QtGui import QDesktopServices, QIcon
from qgis.PyQt.QtWidgets import (
    QButtonGroup,
    QCheckBox,
    QComboBox,
    QDial,
    QFileDialog,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QSlider,
    QSpinBox,
    QStackedWidget,
    QToolButton,
    QVBoxLayout,
    QWidget,
)

from ..algorithms.base import HELP_URL, ICONS_DIR, PLUGIN_DIR, plugin_version
from ..compat import GEOMETRY_POINT, MESSAGE_CRITICAL, MESSAGE_SUCCESS
from ..core.limnology import trophic_class
from ..core.textfmt import is_missing
from ..core.styles import STYLE_FUNCTIONS, TROPHIC_STYLE
from .widgets import (
    Card,
    HypsoChart,
    ProfileChart,
    TileGrid,
    TrophicBar,
    fmt_area,
    fmt_length,
    fmt_number,
    fmt_volume,
    stylesheet,
    theme_for,
)

SAMPLE_GPKG = os.path.join(PLUGIN_DIR, "resources", "sample_data", "demo_lake.gpkg")
GROUP_NAME = "LimnoTools"


def tr(text):
    return QCoreApplication.translate("LimnoTools", text)


def _filter(name):
    """Layer filter compatible with QGIS 3.28 to 4."""
    if hasattr(Qgis, "LayerFilter"):
        return getattr(Qgis.LayerFilter, name)
    return getattr(QgsMapLayerProxyModel, name)  # pragma: no cover


def svg_icon(name):
    return QIcon(os.path.join(ICONS_DIR, f"{name}.svg"))


class LimnoDock(QgsDockWidget):
    PAGES = (
        ("bathymetry", "Bathymetry"),
        ("morphometry", "Morphometry"),
        ("hypsometry", "Hypsometry"),
        ("fetch", "Fetch"),
        ("trophic", "Trophic"),
        ("stratification", "Thermal"),
        ("report", "Report"),
    )

    def __init__(self, iface, parent=None):
        super().__init__(tr("LimnoTools"), parent or iface.mainWindow())
        self.iface = iface
        self.setObjectName("LimnoToolsDock")
        self._jobs = []
        self._last_report = None
        self._hypso_rows = []
        self._study = {}

        root = QWidget()
        root.setObjectName("limnoRoot")
        self.root = root
        outer = QVBoxLayout(root)
        outer.setContentsMargins(10, 10, 10, 8)
        outer.setSpacing(10)

        outer.addLayout(self._build_header())
        outer.addWidget(self._build_nav())

        self.stack = QStackedWidget()
        builders = (self._page_bathymetry, self._page_morphometry, self._page_hypsometry,
                    self._page_fetch, self._page_trophic, self._page_stratification,
                    self._page_report)
        for build in builders:
            self.stack.addWidget(self._scrollable(build()))
        outer.addWidget(self.stack, 1)
        outer.addLayout(self._build_footer())

        self.setWidget(root)
        self.apply_theme()
        self.nav_buttons[0].setChecked(True)

    # ------------------------------------------------------------------ chrome
    def apply_theme(self):
        self.theme = theme_for(self)
        self.root.setStyleSheet(stylesheet(self.theme))
        for widget in (getattr(self, "chart", None), getattr(self, "trophic_bar", None),
                       getattr(self, "profile_chart", None)):
            if widget is not None:
                widget.theme = self.theme
                widget.update()

    def changeEvent(self, event):  # noqa: N802
        super().changeEvent(event)
        if event.type() == event.Type.PaletteChange:
            self.apply_theme()

    def _build_header(self):
        layout = QHBoxLayout()
        layout.setSpacing(10)
        logo = QLabel()
        logo.setPixmap(svg_icon("icon").pixmap(38, 38))
        layout.addWidget(logo)
        titles = QVBoxLayout()
        titles.setSpacing(0)
        title = QLabel("LimnoTools")
        title.setObjectName("limnoHeaderTitle")
        sub = QLabel(tr("Lake bathymetry and limnology"))
        sub.setObjectName("limnoHeaderSub")
        titles.addWidget(title)
        titles.addWidget(sub)
        layout.addLayout(titles, 1)
        return layout

    def _build_nav(self):
        frame = QWidget()
        frame.setObjectName("limnoNav")
        frame.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        layout = QGridLayout(frame)
        layout.setContentsMargins(4, 4, 4, 4)
        layout.setSpacing(2)
        self.nav_group = QButtonGroup(self)
        self.nav_buttons = []
        for index, (key, label) in enumerate(self.PAGES):
            button = QToolButton()
            button.setObjectName("navButton")
            button.setIcon(svg_icon(key))
            button.setIconSize(_size(22))
            button.setText(tr(label))
            button.setToolButtonStyle(Qt.ToolButtonStyle.ToolButtonTextUnderIcon)
            button.setCheckable(True)
            button.setAutoRaise(True)
            button.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
            self.nav_group.addButton(button, index)
            layout.addWidget(button, index // 4, index % 4)
            self.nav_buttons.append(button)
        if hasattr(self.nav_group, "idClicked"):
            self.nav_group.idClicked.connect(self.stack_set)
        else:  # pragma: no cover  Qt < 5.15
            self.nav_group.buttonClicked[int].connect(self.stack_set)
        return frame

    def stack_set(self, index):
        self.stack.setCurrentIndex(index)
        if self.PAGES[index][0] == "report":
            self._refresh_contents()

    def _build_footer(self):
        layout = QHBoxLayout()
        layout.setSpacing(6)
        self.status = QLabel(tr("Ready"))
        self.status.setObjectName("status")
        self.status.setWordWrap(True)
        layout.addWidget(self.status, 1)
        demo = QPushButton(tr("Load demo data"))
        demo.setObjectName("link")
        demo.setCursor(Qt.CursorShape.PointingHandCursor)
        demo.clicked.connect(self.load_demo_data)
        layout.addWidget(demo)
        help_button = QPushButton("?")
        help_button.setObjectName("link")
        help_button.setToolTip(tr("Documentation") + f" (v{plugin_version()})")
        help_button.setCursor(Qt.CursorShape.PointingHandCursor)
        help_button.clicked.connect(lambda: QDesktopServices.openUrl(QUrl(HELP_URL)))
        layout.addWidget(help_button)
        return layout

    @staticmethod
    def _scrollable(widget):
        area = QScrollArea()
        area.setWidgetResizable(True)
        area.setFrameShape(area.Shape.NoFrame)
        area.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        area.setWidget(widget)
        return area

    @staticmethod
    def _page(title, description):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 0, 4, 0)
        layout.setSpacing(10)
        heading = QLabel(title)
        heading.setObjectName("pageTitle")
        text = QLabel(description)
        text.setObjectName("pageDescription")
        text.setWordWrap(True)
        layout.addWidget(heading)
        layout.addWidget(text)
        return page, layout

    def _run_row(self, layout, label, slot):
        button = QPushButton(label)
        button.setObjectName("primary")
        button.setCursor(Qt.CursorShape.PointingHandCursor)
        button.clicked.connect(slot)
        progress = QProgressBar()
        progress.setObjectName("thinProgress")
        progress.setTextVisible(False)
        progress.setRange(0, 100)
        progress.setValue(0)
        progress.setVisible(False)
        layout.addWidget(button)
        layout.addWidget(progress)
        return button, progress

    @staticmethod
    def _layer_combo(filter_name, allow_empty=False):
        combo = QgsMapLayerComboBox()
        combo.setFilters(_filter(filter_name))
        combo.setAllowEmptyLayer(allow_empty)
        if allow_empty:
            combo.setLayer(None)
        return combo

    # ------------------------------------------------------------------ pages
    def _page_bathymetry(self):
        page, layout = self._page(
            tr("Bathymetry"),
            tr("Interpolate a depth raster from echo-sounding points, clipped to the lake outline, "
               "then draw isobaths."))
        inputs = Card(tr("Inputs"))
        self.b_points = inputs.add_field(tr("Soundings (points)"), self._layer_combo("PointLayer"))
        self.b_field = inputs.add_field(tr("Depth field"), QgsFieldComboBox())
        self.b_points.layerChanged.connect(self.b_field.setLayer)
        self.b_field.setLayer(self.b_points.currentLayer())
        self.b_lake = inputs.add_field(tr("Lake outline (polygons)"), self._layer_combo("PolygonLayer"))
        layout.addWidget(inputs)

        options = Card(tr("Options"))
        self.b_method = options.add_field(tr("Method"), QComboBox())
        self.b_method.addItems([tr("TIN (triangulation, linear)"), tr("IDW (inverse distance weighting)")])
        self.b_pixel = options.add_field(tr("Pixel size (m)"), QgsDoubleSpinBox())
        self.b_pixel.setRange(0, 10000)
        self.b_pixel.setDecimals(2)
        self.b_pixel.setSpecialValueText(tr("Automatic"))
        self.b_pixel.setClearValue(0)
        self.b_shore = options.add(QCheckBox(tr("Force zero depth along the shoreline")))
        self.b_shore.setChecked(True)
        iso_row = QHBoxLayout()
        self.b_iso = QCheckBox(tr("Isobaths every"))
        self.b_iso.setChecked(True)
        self.b_interval = QgsDoubleSpinBox()
        self.b_interval.setRange(0.1, 1000)
        self.b_interval.setValue(1.0)
        self.b_interval.setSuffix(" m")
        iso_row.addWidget(self.b_iso)
        iso_row.addWidget(self.b_interval, 1)
        options.layout_.addLayout(iso_row)
        self.b_zones = options.add(QCheckBox(tr("Also create depth zones (polygons)")))
        layout.addWidget(options)

        self.b_run, self.b_progress = self._run_row(layout, tr("Interpolate"), self.run_bathymetry)
        results = Card(tr("Results"))
        self.b_tiles = results.add(TileGrid([
            ("zmax", tr("Maximum depth")), ("zmean", tr("Mean depth")),
            ("volume", tr("Volume")), ("pixel", tr("Pixel size"))]))
        layout.addWidget(results)
        layout.addStretch(1)
        return page

    def _page_morphometry(self):
        page, layout = self._page(
            tr("Morphometry"),
            tr("Standard morphometric indices of each lake. Add the bathymetry raster to get the "
               "volume and depth based indices."))
        inputs = Card(tr("Inputs"))
        self.m_lake = inputs.add_field(tr("Lake outline (polygons)"), self._layer_combo("PolygonLayer"))
        self.m_name = inputs.add_field(tr("Name field (optional)"), QgsFieldComboBox())
        self.m_name.setAllowEmptyFieldName(True)
        self.m_lake.layerChanged.connect(self.m_name.setLayer)
        self.m_name.setLayer(self.m_lake.currentLayer())
        self.m_raster = inputs.add_field(tr("Bathymetry raster (optional)"), self._layer_combo("RasterLayer", True))
        self.m_lines = inputs.add(QCheckBox(tr("Add maximum length and width lines to the map")))
        self.m_lines.setChecked(True)
        layout.addWidget(inputs)

        self.m_run, self.m_progress = self._run_row(layout, tr("Compute"), self.run_morphometry)
        results = Card(tr("Results"))
        self.m_select = results.add(QComboBox())
        self.m_select.setVisible(False)
        self.m_select.currentIndexChanged.connect(self._show_morphometry)
        self.m_tiles = results.add(TileGrid([
            ("AREA_M2", tr("Surface area")), ("PERIM_M", tr("Shoreline length")),
            ("LMAX_M", tr("Maximum length")), ("WMAX_M", tr("Maximum width")),
            ("DL", tr("Shoreline development")), ("ISLANDS", tr("Islands")),
            ("VOLUME_M3", tr("Volume")), ("ZMAX_M", tr("Maximum depth")),
            ("ZMEAN_M", tr("Mean depth")), ("ZR_PCT", tr("Relative depth")),
            ("DV", tr("Volume development")), ("WMEAN_M", tr("Mean width"))]))
        buttons = QHBoxLayout()
        self.m_open = QPushButton(tr("Open report"))
        self.m_open.setObjectName("secondary")
        self.m_open.clicked.connect(self.open_report)
        self.m_save = QPushButton(tr("Save report..."))
        self.m_save.setObjectName("secondary")
        self.m_save.clicked.connect(self.save_report)
        for button in (self.m_open, self.m_save):
            button.setEnabled(False)
            buttons.addWidget(button)
        results.layout_.addLayout(buttons)
        layout.addWidget(results)
        layout.addStretch(1)
        self._morpho_rows = []
        return page

    def _page_hypsometry(self):
        page, layout = self._page(
            tr("Hypsometry"),
            tr("Area and volume of the lake at every depth. Use the slider to simulate a drop of the "
               "water level."))
        inputs = Card(tr("Inputs"))
        self.h_raster = inputs.add_field(tr("Bathymetry raster"), self._layer_combo("RasterLayer"))
        self.h_lake = inputs.add_field(tr("Lake outline (optional mask)"), self._layer_combo("PolygonLayer", True))
        self.h_step = inputs.add_field(tr("Depth step (m)"), QgsDoubleSpinBox())
        self.h_step.setRange(0, 1000)
        self.h_step.setDecimals(2)
        self.h_step.setSpecialValueText(tr("Automatic"))
        layout.addWidget(inputs)

        self.h_run, self.h_progress = self._run_row(layout, tr("Compute curve"), self.run_hypsometry)
        results = Card(tr("Hypsographic curve"))
        self.chart = results.add(HypsoChart())
        self.chart.labels = (tr("Area at depth"), tr("Cumulative volume"))
        self.chart.empty_text = tr("Run the tool to draw the curve")
        self.chart.hover_format = tr("{depth:.2f} m   area {area:.0f}%   volume {vol:.0f}%")
        caption = QLabel(tr("Water level drop"))
        caption.setObjectName("fieldLabel")
        results.add(caption)
        self.h_slider = results.add(QSlider(Qt.Orientation.Horizontal))
        self.h_slider.setRange(0, 1000)
        self.h_slider.setEnabled(False)
        self.h_slider.valueChanged.connect(self._update_drawdown)
        self.h_tiles = results.add(TileGrid([
            ("drop", tr("Level drop")), ("area", tr("Remaining surface")),
            ("volume", tr("Remaining volume")), ("lost", tr("Volume lost"))]))
        self.h_export = QPushButton(tr("Export table (CSV)..."))
        self.h_export.setObjectName("secondary")
        self.h_export.setEnabled(False)
        self.h_export.clicked.connect(self.export_hypsometry)
        results.add(self.h_export)
        layout.addWidget(results)
        layout.addStretch(1)
        return page

    def _page_fetch(self):
        page, layout = self._page(
            tr("Wind fetch"),
            tr("Open-water distance over which the wind blows before reaching each site: a proxy "
               "for wave exposure, shore erosion and sediment resuspension."))
        inputs = Card(tr("Inputs"))
        self.f_lake = inputs.add_field(tr("Lake outline (polygons)"), self._layer_combo("PolygonLayer"))
        self.f_points = inputs.add_field(tr("Sites (points)"), self._layer_combo("PointLayer"))
        layout.addWidget(inputs)

        options = Card(tr("Wind"))
        row = QHBoxLayout()
        self.f_dial = QDial()
        self.f_dial.setRange(0, 359)
        self.f_dial.setWrapping(True)
        self.f_dial.setNotchesVisible(True)
        self.f_dial.setFixedSize(84, 84)
        self.f_dial.setValue(45)  # dial 0 is at the bottom: shift by 180 degrees
        right = QVBoxLayout()
        caption = QLabel(tr("Dominant wind from (degrees)"))
        caption.setObjectName("fieldLabel")
        caption.setWordWrap(True)
        self.f_wind = QSpinBox()
        self.f_wind.setRange(0, 359)
        self.f_wind.setWrapping(True)
        self.f_wind.setSuffix("°")
        self.f_wind.setValue(225)
        self.f_wind_name = QLabel()
        self.f_wind_name.setObjectName("status")
        right.addWidget(caption)
        right.addWidget(self.f_wind)
        right.addWidget(self.f_wind_name)
        right.addStretch(1)
        row.addWidget(self.f_dial)
        row.addLayout(right, 1)
        options.layout_.addLayout(row)
        self.f_dial.valueChanged.connect(lambda v: self.f_wind.setValue((v + 180) % 360))
        self.f_wind.valueChanged.connect(self._wind_changed)
        self._wind_changed(225)
        self.f_step = options.add_field(tr("Angular step"), QSpinBox())
        self.f_step.setRange(1, 90)
        self.f_step.setValue(10)
        self.f_step.setSuffix("°")
        self.f_rays = options.add(QCheckBox(tr("Add the fetch rays to the map")))
        layout.addWidget(options)

        self.f_run, self.f_progress = self._run_row(layout, tr("Compute fetch"), self.run_fetch)
        results = Card(tr("Results"))
        self.f_tiles = results.add(TileGrid([
            ("max", tr("Longest fetch")), ("eff", tr("Mean effective fetch")),
            ("site", tr("Most exposed site")), ("n", tr("Sites"))]))
        layout.addWidget(results)
        layout.addStretch(1)
        return page

    def _page_trophic(self):
        page, layout = self._page(
            tr("Trophic state"),
            tr("Carlson Trophic State Index from Secchi depth, chlorophyll-a and total phosphorus. "
               "One variable is enough, three are better."))
        inputs = Card(tr("Inputs"))
        self.t_layer = inputs.add_field(tr("Sampling stations"), self._layer_combo("VectorLayer"))
        self.t_sd = inputs.add_field(tr("Secchi depth (m)"), QgsFieldComboBox())
        self.t_chl = inputs.add_field(tr("Chlorophyll-a"), QgsFieldComboBox())
        self.t_tp = inputs.add_field(tr("Total phosphorus"), QgsFieldComboBox())
        for combo in (self.t_sd, self.t_chl, self.t_tp):
            combo.setAllowEmptyFieldName(True)
            self.t_layer.layerChanged.connect(combo.setLayer)
            combo.setLayer(self.t_layer.currentLayer())
        self.t_layer.layerChanged.connect(self._guess_trophic_fields)
        self.t_unit = inputs.add_field(tr("Concentration unit"), QComboBox())
        self.t_unit.addItems(["µg/L", "mg/L"])
        layout.addWidget(inputs)

        self.t_run, self.t_progress = self._run_row(layout, tr("Compute index"), self.run_trophic)
        results = Card(tr("Results"))
        self.trophic_bar = results.add(TrophicBar())
        self.t_tiles = results.add(TileGrid([("mean", tr("Mean TSI")), ("class", tr("Overall state"))]))
        layout.addWidget(results)
        layout.addStretch(1)
        self._guess_trophic_fields(self.t_layer.currentLayer())
        return page

    # --------------------------------------------------------------- helpers
    def _page_stratification(self):
        page, layout = self._page(
            tr("Thermal stratification"),
            tr("Layers of the water column from probe profiles: epilimnion, thermocline, hypolimnion, "
               "oxycline and Schmidt stability."))
        inputs = Card(tr("Inputs"))
        self.s_layer = inputs.add_field(tr("Vertical profiles (table or CSV)"), self._layer_combo("VectorLayer"))
        self.s_station = inputs.add_field(tr("Station field"), QgsFieldComboBox())
        self.s_date = inputs.add_field(tr("Date field"), QgsFieldComboBox())
        self.s_depth = inputs.add_field(tr("Depth field (m)"), QgsFieldComboBox())
        self.s_temp = inputs.add_field(tr("Temperature (\u00b0C)"), QgsFieldComboBox())
        self.s_oxygen = inputs.add_field(tr("Dissolved oxygen (mg/L, optional)"), QgsFieldComboBox())
        for combo in (self.s_station, self.s_date, self.s_oxygen):
            combo.setAllowEmptyFieldName(True)
        for combo in (self.s_station, self.s_date, self.s_depth, self.s_temp, self.s_oxygen):
            self.s_layer.layerChanged.connect(combo.setLayer)
            combo.setLayer(self.s_layer.currentLayer())
        self.s_layer.layerChanged.connect(self._guess_profile_fields)
        self.s_raster = inputs.add_field(tr("Bathymetry raster (optional, for stability and volumes)"),
                                         self._layer_combo("RasterLayer", True))
        layout.addWidget(inputs)

        self.s_run, self.s_progress = self._run_row(layout, tr("Analyse profiles"), self.run_stratification)
        results = Card(tr("Results"))
        self.s_select = results.add(QComboBox())
        self.s_select.currentIndexChanged.connect(self._show_profile)
        self.profile_chart = results.add(ProfileChart())
        self.profile_chart.empty_text = tr("Run the tool to draw the profile")
        self.profile_chart.labels = (tr("Temperature (\u00b0C)"), tr("Oxygen (mg/L)"), tr("Epilimnion"),
                                     tr("Metalimnion"), tr("Hypolimnion"), tr("Thermocline"))
        self.s_tiles = results.add(TileGrid([
            ("status", tr("Water column")), ("thermo", tr("Thermocline")),
            ("epi", tr("Epilimnion")), ("hypo", tr("Hypolimnion")),
            ("oxycline", tr("Oxycline")), ("hypoxia", tr("Hypoxia (< 2 mg/L)")),
            ("schmidt", tr("Schmidt stability")), ("vhypo", tr("Hypolimnion volume"))]))
        layout.addWidget(results)
        layout.addStretch(1)
        self._profiles = []
        self._guess_profile_fields(self.s_layer.currentLayer())
        return page

    def _page_report(self):
        page, layout = self._page(
            tr("Report"),
            tr("Gather every analysis in a print layout (map sheet and result pages), export it as PDF or "
               "produce a complete HTML report."))
        document = Card(tr("Document"))
        self.r_title = document.add_field(tr("Title"), QLineEdit())
        self.r_title.setPlaceholderText(tr("Limnological study of the lake"))
        self.r_subtitle = document.add_field(tr("Subtitle"), QLineEdit())
        self.r_subtitle.setPlaceholderText(tr("e.g. 2026 field campaign"))
        self.r_reference = document.add_field(tr("Report reference (optional)"), QLineEdit())
        self.r_reference.setPlaceholderText(tr("e.g. 2026-042"))
        self.r_page = document.add_field(tr("Page format"), QComboBox())
        self.r_page.addItem(tr("A4 landscape"), "A4")
        self.r_page.addItem(tr("A3 landscape"), "A3")
        layout.addWidget(document)

        branding = Card(tr("Organisation"))
        self.r_org = branding.add_field(tr("Organisation (consultancy, agency...)"), QLineEdit())
        self.r_author = branding.add_field(tr("Author"), QLineEdit())
        self.r_logo = branding.add_field(tr("Logo (PNG, JPG or SVG)"), QgsFileWidget())
        self.r_logo.setFilter(tr("Images (*.png *.jpg *.jpeg *.svg)"))
        self.r_sources = branding.add_field(tr("Data sources"), QLineEdit())
        self.r_sources.setPlaceholderText(tr("e.g. bathymetric survey 2026, water analyses by the client"))
        hint = branding.add(QLabel(tr("Saved in QGIS: filled in once, reused in every report. "
                                      "Without a logo, the LimnoTools logo is used.")))
        hint.setObjectName("pageDescription")
        hint.setWordWrap(True)
        layout.addWidget(branding)
        self._load_branding()

        contents = Card(tr("Contents"))
        self.r_contents = contents.add(QLabel())
        self.r_contents.setWordWrap(True)
        self.r_contents.setTextFormat(Qt.TextFormat.RichText)
        layout.addWidget(contents)

        self.r_layout = QPushButton(tr("Create the map layout"))
        self.r_layout.setObjectName("primary")
        self.r_layout.setCursor(Qt.CursorShape.PointingHandCursor)
        self.r_layout.clicked.connect(self.create_layout)
        layout.addWidget(self.r_layout)
        row = QHBoxLayout()
        self.r_pdf = QPushButton(tr("Export PDF..."))
        self.r_html = QPushButton(tr("HTML report..."))
        for button, slot in ((self.r_pdf, self.export_study_pdf), (self.r_html, self.export_study_html)):
            button.setObjectName("secondary")
            button.setCursor(Qt.CursorShape.PointingHandCursor)
            button.clicked.connect(slot)
            row.addWidget(button)
        layout.addLayout(row)
        note = QLabel(tr("The layout is added to the project (Project > Layouts): it can be edited freely in the "
                         "layout designer before printing."))
        note.setObjectName("pageDescription")
        note.setWordWrap(True)
        layout.addWidget(note)
        layout.addStretch(1)
        return page

    def _refresh_contents(self):
        names = (("bathymetry", tr("Bathymetry")), ("morphometry", tr("Morphometry")),
                 ("hypsography", tr("Hypsometry")), ("stratification", tr("Thermal stratification")),
                 ("trophic", tr("Trophic state")), ("fetch", tr("Wind fetch")))
        lines = []
        for key, label in names:
            done = bool(self._study.get(key))
            mark = "&#10003;" if done else "&#8211;"
            color = self.theme["accent"] if done else self.theme["muted"]
            lines.append(f'<span style="color:{color}">{mark}&nbsp; {label}</span>')
        self.r_contents.setText("<br>".join(lines))

    def _guess_profile_fields(self, layer):
        if layer is None:
            return
        lower = {f.name().lower(): f.name() for f in layer.fields()}
        for combo, keys in ((self.s_station, ("station", "site", "point")),
                            (self.s_date, ("date", "datetime", "time")),
                            (self.s_depth, ("depth", "profondeur", "prof", "z")),
                            (self.s_temp, ("temp", "wtemp", "t_")),
                            (self.s_oxygen, ("do", "o2", "oxy", "odo"))):
            match = next((lower[n] for key in keys for n in lower if n.startswith(key)), None)
            if match:
                combo.setField(match)

    def _wind_changed(self, value):
        names = [tr("N"), tr("NE"), tr("E"), tr("SE"), tr("S"), tr("SW"), tr("W"), tr("NW")]
        self.f_wind_name.setText(tr("Wind from {}").format(names[int((value + 22.5) % 360 // 45)]))
        dial_value = (value + 180) % 360
        if self.f_dial.value() != dial_value:
            self.f_dial.blockSignals(True)
            self.f_dial.setValue(dial_value)
            self.f_dial.blockSignals(False)

    def _guess_trophic_fields(self, layer):
        if layer is None:
            return
        names = [f.name() for f in layer.fields()]
        lower = {n.lower(): n for n in names}
        for combo, keys in ((self.t_sd, ("secchi", "sd", "transp")),
                            (self.t_chl, ("chl", "chla", "chlorophyll")),
                            (self.t_tp, ("tp", "ptot", "phosph", "p_tot"))):
            for key in keys:
                match = next((lower[n] for n in lower if n.startswith(key)), None)
                if match:
                    combo.setField(match)
                    break

    def set_status(self, text, error=False):
        self.status.setObjectName("statusError" if error else "status")
        self.status.setStyleSheet("")
        self.status.style().unpolish(self.status)
        self.status.style().polish(self.status)
        self.status.setText(text)

    def _require(self, *pairs):
        for value, message in pairs:
            if not value:
                self.set_status(message, error=True)
                return False
        return True

    def _group(self):
        root = QgsProject.instance().layerTreeRoot()
        group = root.findGroup(GROUP_NAME)
        if group is None:
            group = root.insertGroup(0, GROUP_NAME)
        return group

    def _add_layer(self, layer, style_key=None):
        if layer is None or not layer.isValid():
            return None
        if style_key:
            try:
                STYLE_FUNCTIONS[style_key](layer)
            except Exception as err:  # noqa: BLE001  style must never block results
                self.set_status(tr("Style not applied: {}").format(err), error=True)
        QgsProject.instance().addMapLayer(layer, False)
        self._group().insertLayer(0, layer)
        return layer

    @staticmethod
    def _take_layer(context, value, name):
        layer = None
        if isinstance(value, str):
            layer = context.takeResultLayer(value)
            if layer is None and os.path.exists(value):
                if value.lower().endswith((".tif", ".tiff")):
                    layer = QgsRasterLayer(value, name)
                else:
                    layer = QgsVectorLayer(value, name, "ogr")
        if layer is not None:
            layer.setName(name)
        return layer

    def run_algorithm(self, algorithm_id, parameters, button, progress, on_done):
        algorithm = QgsApplication.processingRegistry().createAlgorithmById(algorithm_id)
        if algorithm is None:
            self.set_status(tr("Algorithm {} not found.").format(algorithm_id), error=True)
            return
        context = QgsProcessingContext()
        context.setProject(QgsProject.instance())
        feedback = QgsProcessingFeedback()
        task = QgsProcessingAlgRunnerTask(algorithm, parameters, context, feedback)
        job = {"task": task, "context": context, "feedback": feedback, "algorithm": algorithm}
        self._jobs.append(job)
        button.setEnabled(False)
        progress.setValue(0)
        progress.setVisible(True)
        feedback.progressChanged.connect(lambda value: progress.setValue(int(value)))
        self.set_status(tr("Running {}...").format(algorithm.displayName()))

        def finished(ok, results):
            button.setEnabled(True)
            progress.setVisible(False)
            if job in self._jobs:
                self._jobs.remove(job)
            if not ok:
                message = feedback.textLog().strip().splitlines()
                detail = message[-1] if message else ""
                self.set_status(tr("{} failed. {}").format(algorithm.displayName(), detail), error=True)
                self.iface.messageBar().pushMessage("LimnoTools", tr("{} failed, see the log for details.").format(
                    algorithm.displayName()), level=MESSAGE_CRITICAL, duration=6)
                return
            try:
                on_done(results, context)
            except Exception as err:  # noqa: BLE001  report any unexpected error to the user
                self.set_status(str(err), error=True)
                raise

        task.executed.connect(finished)
        QgsApplication.taskManager().addTask(task)

    def _done(self, message):
        self.set_status(message)
        self.iface.messageBar().pushMessage("LimnoTools", message, level=MESSAGE_SUCCESS, duration=4)

    # ----------------------------------------------------------------- runs
    def run_bathymetry(self):
        points, lake, field = self.b_points.currentLayer(), self.b_lake.currentLayer(), self.b_field.currentField()
        if not self._require((points, tr("Choose a soundings layer.")), (field, tr("Choose the depth field.")),
                             (lake, tr("Choose the lake outline layer."))):
            return
        params = {
            "SOUNDINGS": points, "DEPTH_FIELD": field, "LAKE": lake,
            "METHOD": self.b_method.currentIndex(), "PIXEL_SIZE": self.b_pixel.value(),
            "SHORE_ZERO": self.b_shore.isChecked(), "OUTPUT": "TEMPORARY_OUTPUT",
        }

        def done(results, context):
            raster = self._take_layer(context, results["OUTPUT"], tr("Bathymetry ({})").format(lake.name()))
            self._add_layer(raster, "bathymetry")
            self.b_tiles.set("zmax", fmt_number(results.get("MAX_DEPTH"), 2, "m"))
            self.b_tiles.set("zmean", fmt_number(results.get("MEAN_DEPTH"), 2, "m"))
            self.b_tiles.set("volume", fmt_volume(results.get("VOLUME")))
            self._study["bathymetry"] = {
                "zmax": results.get("MAX_DEPTH"), "zmean": results.get("MEAN_DEPTH"),
                "volume": results.get("VOLUME"), "lake": lake.id(),
                "raster": raster.id() if raster is not None else None,
                "pixel": raster.rasterUnitsPerPixelX() if raster is not None else None,
            }
            if raster is not None:
                self.b_tiles.set("pixel", fmt_number(raster.rasterUnitsPerPixelX(), 2, "m"))
                for combo in (self.m_raster, self.h_raster, self.s_raster):
                    combo.setLayer(raster)
            if raster is not None and self.b_iso.isChecked():
                self._run_isobaths(raster)
            else:
                self._done(tr("Bathymetry created."))

        self.run_algorithm("limnotools:bathymetry", params, self.b_run, self.b_progress, done)

    def _run_isobaths(self, raster):
        params = {"INPUT": raster, "BAND": 1, "INTERVAL": self.b_interval.value(), "OUTPUT": "TEMPORARY_OUTPUT"}
        if self.b_zones.isChecked():
            params["OUTPUT_ZONES"] = "TEMPORARY_OUTPUT"

        def done(results, context):
            bathy = self._study.setdefault("bathymetry", {})
            bathy.pop("zones", None)
            if "OUTPUT_ZONES" in results:
                zones = self._add_layer(self._take_layer(context, results["OUTPUT_ZONES"], tr("Depth zones")),
                                        "depth_zones")
                bathy["zones"] = zones.id() if zones is not None else None
            isobaths = self._add_layer(self._take_layer(context, results["OUTPUT"], tr("Isobaths")), "isobaths")
            bathy["isobaths"] = isobaths.id() if isobaths is not None else None
            self._done(tr("Bathymetry and isobaths created."))

        self.run_algorithm("limnotools:isobaths", params, self.b_run, self.b_progress, done)

    def run_morphometry(self):
        lake = self.m_lake.currentLayer()
        if not self._require((lake, tr("Choose the lake outline layer."))):
            return
        report = os.path.join(QgsProcessingUtils.tempFolder(), "limnotools_morphometry_report.html")
        params = {
            "LAKE": lake, "NAME_FIELD": self.m_name.currentField() or None,
            "DEPTH": self.m_raster.currentLayer(), "OUTPUT": "TEMPORARY_OUTPUT",
            "OUTPUT_HTML": report,
        }
        if self.m_lines.isChecked():
            params["OUTPUT_LINES"] = "TEMPORARY_OUTPUT"

        def done(results, context):
            self._morpho_rows = json.loads(results.get("SUMMARY") or "[]")
            lines = None
            if "OUTPUT_LINES" in results:
                lines = self._add_layer(self._take_layer(context, results["OUTPUT_LINES"],
                                                         tr("Max length and width ({})").format(lake.name())),
                                        "morphometry_lines")
            self._study["morphometry"] = {"rows": self._morpho_rows, "lake": lake.id(),
                                          "lines": lines.id() if lines is not None else None}
            self._add_layer(self._take_layer(context, results["OUTPUT"], tr("Morphometry ({})").format(lake.name())))
            self.m_select.blockSignals(True)
            self.m_select.clear()
            self.m_select.addItems([str(r.get("NAME")) for r in self._morpho_rows])
            self.m_select.blockSignals(False)
            self.m_select.setVisible(len(self._morpho_rows) > 1)
            self._show_morphometry(0)
            self._last_report = results.get("OUTPUT_HTML")
            for button in (self.m_open, self.m_save):
                button.setEnabled(bool(self._last_report))
            self._done(tr("Morphometry computed for {} lake(s).").format(len(self._morpho_rows)))

        self.run_algorithm("limnotools:morphometry", params, self.m_run, self.m_progress, done)

    def _show_morphometry(self, index):
        if not (0 <= index < len(self._morpho_rows)):
            self.m_tiles.clear()
            return
        row = self._morpho_rows[index]
        self.m_tiles.set("AREA_M2", fmt_area(row.get("AREA_M2")))
        for key in ("PERIM_M", "LMAX_M", "WMAX_M", "WMEAN_M"):
            self.m_tiles.set(key, fmt_length(row.get(key)))
        self.m_tiles.set("DL", fmt_number(row.get("DL"), 2), tr("1 = perfect circle"))
        self.m_tiles.set("ISLANDS", fmt_number(row.get("ISLANDS"), 0))
        self.m_tiles.set("VOLUME_M3", fmt_volume(row.get("VOLUME_M3")))
        self.m_tiles.set("ZMAX_M", fmt_number(row.get("ZMAX_M"), 2, "m"))
        self.m_tiles.set("ZMEAN_M", fmt_number(row.get("ZMEAN_M"), 2, "m"))
        self.m_tiles.set("ZR_PCT", fmt_number(row.get("ZR_PCT"), 2, "%"),
                         tr("Most lakes < 2 %; above 4 % the lake tends to stratify strongly"))
        self.m_tiles.set("DV", fmt_number(row.get("DV"), 2),
                         tr("1 = cone shaped basin, > 1 = flat bottom, < 1 = deep hole"))

    def open_report(self):
        if self._last_report and os.path.exists(self._last_report):
            QDesktopServices.openUrl(QUrl.fromLocalFile(self._last_report))

    def save_report(self):
        if not self._last_report:
            return
        path, _ = QFileDialog.getSaveFileName(self, tr("Save report"), "morphometry_report.html",
                                              tr("HTML files (*.html)"))
        if path:
            shutil.copyfile(self._last_report, path)
            self.set_status(tr("Report saved: {}").format(path))

    def run_hypsometry(self):
        raster = self.h_raster.currentLayer()
        if not self._require((raster, tr("Choose a bathymetry raster."))):
            return
        params = {"INPUT": raster, "LAKE": self.h_lake.currentLayer(), "STEP": self.h_step.value(),
                  "OUTPUT": "TEMPORARY_OUTPUT"}

        def done(results, context):
            self._hypso_rows = json.loads(results.get("TABLE") or "[]")
            self._study["hypsography"] = self._hypso_rows
            self._add_layer(self._take_layer(context, results["OUTPUT"], tr("Hypsographic table")))
            self.chart.set_rows(self._hypso_rows)
            self.h_slider.setEnabled(bool(self._hypso_rows))
            self.h_export.setEnabled(bool(self._hypso_rows))
            self.h_slider.setValue(0)
            self._update_drawdown(0)
            self._done(tr("Hypsographic curve computed ({} levels).").format(len(self._hypso_rows)))

        self.run_algorithm("limnotools:hypsometry", params, self.h_run, self.h_progress, done)

    def _update_drawdown(self, value):
        if not self._hypso_rows:
            self.h_tiles.clear()
            return
        zmax = self._hypso_rows[-1]["depth"]
        drop = zmax * value / 1000.0
        self.chart.set_drawdown(drop if value else None)
        area = self.chart.value_at(drop, "area")
        vol_below = self.chart.value_at(drop, "volume_below")
        total = self._hypso_rows[0]["volume_below"] or 1.0
        surface = self._hypso_rows[0]["area"] or 1.0
        self.h_tiles.set("drop", fmt_number(drop, 2, "m"))
        self.h_tiles.set("area", f"{fmt_area(area)} ({100 * area / surface:.0f}%)")
        self.h_tiles.set("volume", f"{fmt_volume(vol_below)} ({100 * vol_below / total:.0f}%)")
        self.h_tiles.set("lost", fmt_volume(total - vol_below))

    def export_hypsometry(self):
        path, _ = QFileDialog.getSaveFileName(self, tr("Export table"), "hypsography.csv", tr("CSV files (*.csv)"))
        if not path:
            return
        keys = ["depth", "area", "area_pct", "volume_above", "volume_below", "volume_above_pct"]
        with open(path, "w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=keys)
            writer.writeheader()
            for row in self._hypso_rows:
                writer.writerow({k: row[k] for k in keys})
        self.set_status(tr("Table exported: {}").format(path))

    def run_fetch(self):
        lake, points = self.f_lake.currentLayer(), self.f_points.currentLayer()
        if not self._require((lake, tr("Choose the lake outline layer.")), (points, tr("Choose a sites layer."))):
            return
        params = {"LAKE": lake, "POINTS": points, "STEP": self.f_step.value(), "WIND": float(self.f_wind.value()),
                  "OUTPUT": "TEMPORARY_OUTPUT"}
        if self.f_rays.isChecked():
            params["OUTPUT_RAYS"] = "TEMPORARY_OUTPUT"

        def done(results, context):
            if "OUTPUT_RAYS" in results:
                self._add_layer(self._take_layer(context, results["OUTPUT_RAYS"], tr("Fetch rays")), "fetch_rays")
            layer = self._add_layer(self._take_layer(context, results["OUTPUT"],
                                                     tr("Fetch, wind from {} deg").format(self.f_wind.value())),
                                    "fetch_points")
            if layer is not None:
                self._study["fetch"] = {"layer": layer.id(), "wind": float(self.f_wind.value())}
                features = list(layer.getFeatures())
                best = max(features, key=lambda f: f["FETCH_EFF"] or 0, default=None)
                eff = [f["FETCH_EFF"] for f in features if f["FETCH_EFF"]]
                self.f_tiles.set("max", fmt_length(max((f["FETCH_MAX"] or 0 for f in features), default=None)))
                self.f_tiles.set("eff", fmt_length(sum(eff) / len(eff) if eff else None))
                self.f_tiles.set("site", _feature_label(best) if best else "-",
                                 tr("Site with the highest effective fetch"))
                self.f_tiles.set("n", fmt_number(len(features)))
            self._done(tr("Fetch computed."))

        self.run_algorithm("limnotools:fetch", params, self.f_run, self.f_progress, done)

    def run_trophic(self):
        layer = self.t_layer.currentLayer()
        fields = (self.t_sd.currentField(), self.t_chl.currentField(), self.t_tp.currentField())
        if not self._require((layer, tr("Choose the stations layer.")),
                             (any(fields), tr("Choose at least one variable."))):
            return
        params = {"INPUT": layer, "SECCHI": fields[0] or None, "CHL": fields[1] or None, "TP": fields[2] or None,
                  "UNIT": self.t_unit.currentIndex(), "OUTPUT": "TEMPORARY_OUTPUT"}

        def done(results, context):
            out = self._take_layer(context, results["OUTPUT"], tr("Trophic state ({})").format(layer.name()))
            is_point = out is not None and out.geometryType() == GEOMETRY_POINT
            self._add_layer(out, "trophic" if is_point else None)
            if out is None:
                return
            self._study["trophic"] = {"layer": out.id(), "fields": fields,
                                      "factor": 1000.0 if self.t_unit.currentIndex() == 1 else 1.0}
            counts, values = {}, []
            for feature in out.getFeatures():
                counts[feature["TROPHIC"]] = counts.get(feature["TROPHIC"], 0) + 1
                if feature["TSI_MEAN"] is not None:
                    values.append(feature["TSI_MEAN"])
            labels = {k: (c, tr(lbl)) for k, (c, lbl) in TROPHIC_STYLE.items()}
            self.trophic_bar.set_data(counts, labels)
            mean = sum(values) / len(values) if values else None
            self.t_tiles.set("mean", fmt_number(mean, 1))
            key = trophic_class(mean)
            self.t_tiles.set("class", tr(key.capitalize()) if key else "-")
            self._done(tr("Trophic state computed for {} station(s).").format(len(values)))

        self.run_algorithm("limnotools:trophicstate", params, self.t_run, self.t_progress, done)

    def run_stratification(self):
        layer = self.s_layer.currentLayer()
        depth, temp = self.s_depth.currentField(), self.s_temp.currentField()
        if not self._require((layer, tr("Choose the profiles layer.")), (depth, tr("Choose the depth field.")),
                             (temp, tr("Choose the temperature field."))):
            return
        params = {"INPUT": layer, "STATION": self.s_station.currentField() or None,
                  "DATE": self.s_date.currentField() or None, "DEPTH": depth, "TEMPERATURE": temp,
                  "OXYGEN": self.s_oxygen.currentField() or None, "BATHYMETRY": self.s_raster.currentLayer(),
                  "OUTPUT": "TEMPORARY_OUTPUT"}

        def done(results, context):
            self._profiles = json.loads(results.get("PROFILES") or "[]")
            self._study["stratification"] = self._profiles
            self._add_layer(self._take_layer(context, results["OUTPUT"],
                                             tr("Stratification ({})").format(layer.name())))
            self.s_select.blockSignals(True)
            self.s_select.clear()
            for profile in self._profiles:
                state = tr("stratified") if profile["stratified"] else tr("mixed")
                label = " | ".join(v for v in (profile["station"], profile["date"]) if v) or tr("Profile")
                self.s_select.addItem(f"{label}  ({state})")
            self.s_select.blockSignals(False)
            first = next((i for i, p in enumerate(self._profiles) if p["stratified"]), 0)
            self.s_select.setCurrentIndex(first)
            self._show_profile(first)
            n = sum(1 for p in self._profiles if p["stratified"])
            self._done(tr("{} profile(s) analysed, {} stratified.").format(len(self._profiles), n))

        self.run_algorithm("limnotools:stratification", params, self.s_run, self.s_progress, done)

    def _show_profile(self, index):
        if not (0 <= index < len(self._profiles)):
            self.profile_chart.set_profile(None)
            self.s_tiles.clear()
            return
        p = self._profiles[index]
        self.profile_chart.set_profile(p)
        if p["stratified"]:
            self.s_tiles.set("status", tr("Stratified"), tr("Maximum density gradient: {:.2f} kg/m3/m").format(
                p["max_gradient"] or 0))
            self.s_tiles.set("thermo", fmt_number(p["thermocline"], 1, "m"))
            self.s_tiles.set("epi", tr("0 to {}").format(fmt_number(p["epi_bottom"], 1, "m")))
            self.s_tiles.set("hypo", tr("below {}").format(fmt_number(p["hypo_top"], 1, "m")))
        else:
            self.s_tiles.set("status", tr("Mixed"), tr("No density gradient above the threshold"))
            for key in ("thermo", "epi", "hypo"):
                self.s_tiles.set(key, "-")
        self.s_tiles.set("oxycline", fmt_number(p["oxycline"], 1, "m"))
        self.s_tiles.set("hypoxia", fmt_number(p["hypoxia"], 1, "m") if p["hypoxia"] is not None else tr("none"))
        self.s_tiles.set("schmidt", fmt_number(p["schmidt"], 0, "J/m\u00b2"),
                         tr("Energy needed to mix the whole lake"))
        if p.get("vol_hypo") is not None:
            self.s_tiles.set("vhypo", f"{fmt_volume(p['vol_hypo'])} ({p['pct_hypo']:.0f}%)")
        else:
            self.s_tiles.set("vhypo", "-")

    # ------------------------------------------------------------- report
    @staticmethod
    def _layer(layer_id):
        return QgsProject.instance().mapLayer(layer_id) if layer_id else None

    def _collect_study(self):
        """Data, map layers, legend entries and extent of the current study."""
        study = self._study
        bathy = study.get("bathymetry") or {}
        morpho = study.get("morphometry") or {}
        lake = self._layer(morpho.get("lake")) or self._layer(bathy.get("lake")) or self.b_lake.currentLayer()
        rows = morpho.get("rows") or []
        data = {
            "lake_name": (rows[0].get("NAME") if rows else None) or (lake.name() if lake else ""),
            "crs": lake.crs().authid() if lake else "",
            "bathymetry": {k: bathy.get(k) for k in ("zmax", "zmean", "volume", "pixel")}
            if bathy.get("zmax") is not None else None,
            "morphometry": rows[0] if rows else None,
            "hypsography": study.get("hypsography"),
            "stratification": study.get("stratification"),
            "trophic": None,
            "fetch": None,
        }
        trophic = study.get("trophic") or {}
        layer = self._layer(trophic.get("layer"))
        if layer is not None:
            sd, chl, tp = trophic.get("fields", (None, None, None))
            factor = trophic.get("factor", 1.0)

            def value(feature, field, scale=1.0):
                try:
                    return float(feature[field]) * scale if field else None
                except (TypeError, ValueError, KeyError):
                    return None

            data["trophic"] = [{"name": _feature_label(f), "secchi": value(f, sd), "chl": value(f, chl, factor),
                                "tp": value(f, tp, factor), "tsi": f["TSI_MEAN"], "class": f["TROPHIC"]}
                               for f in layer.getFeatures()]
        fetch = study.get("fetch") or {}
        layer = self._layer(fetch.get("layer"))
        if layer is not None:
            data["fetch"] = {"wind": fetch.get("wind"), "rows": [
                {"name": _feature_label(f), "fetch_max": f["FETCH_MAX"], "dir_max": f["DIR_MAX"] or 0,
                 "fetch_mean": f["FETCH_MEAN"], "fetch_eff": f["FETCH_EFF"]} for f in layer.getFeatures()]}

        map_layers, legend = [], []
        trophic_layer = self._layer(trophic.get("layer"))
        if trophic_layer is not None and trophic_layer.geometryType() == GEOMETRY_POINT:
            map_layers.append(trophic_layer)
            legend.append((trophic_layer, tr("Trophic state (TSI)")))
        fetch_layer = self._layer(fetch.get("layer"))
        if fetch_layer is not None:
            map_layers.append(fetch_layer)
            legend.append((fetch_layer, tr("Effective fetch")))
        lines = self._layer(morpho.get("lines"))
        if lines is not None:
            map_layers.append(lines)
            legend.append((lines, tr("Lake axes")))
        isobaths = self._layer(bathy.get("isobaths"))
        if isobaths is not None:
            map_layers.append(isobaths)
            legend.append((isobaths, tr("Isobaths")))
        zones, raster = self._layer(bathy.get("zones")), self._layer(bathy.get("raster"))
        depth_layer = zones or raster
        if depth_layer is not None:
            map_layers.append(depth_layer)
            legend.insert(0, (depth_layer, tr("Depth (m)")))
        if lake is not None:
            map_layers.append(lake)
            legend.append((lake, tr("Lake outline")))
        analyses = ("bathymetry", "morphometry", "hypsography", "stratification", "trophic", "fetch")
        if not any(data[k] for k in analyses) or lake is None:
            raise ValueError(tr("Run at least one analysis on a lake before creating the report."))
        return data, map_layers, legend, lake.extent()

    BRANDING_KEYS = ("organisation", "author", "logo", "sources")

    def _branding_widgets(self):
        return {"organisation": self.r_org, "author": self.r_author, "logo": self.r_logo, "sources": self.r_sources}

    def _load_branding(self):
        settings = QgsSettings()
        for key, widget in self._branding_widgets().items():
            value = settings.value(f"limnotools/report/{key}", "") or ""
            if isinstance(widget, QgsFileWidget):
                widget.setFilePath(value)
            else:
                widget.setText(value)

    def _save_branding(self, options):
        settings = QgsSettings()
        for key in self.BRANDING_KEYS:
            settings.setValue(f"limnotools/report/{key}", options.get(key, ""))

    def _report_options(self, data):
        title = self.r_title.text().strip() or tr("Limnological study: {}").format(data["lake_name"])
        options = {"title": title, "subtitle": self.r_subtitle.text().strip(),
                   "organisation": self.r_org.text().strip(), "author": self.r_author.text().strip(),
                   "logo": self.r_logo.filePath().strip(), "sources": self.r_sources.text().strip(),
                   "reference": self.r_reference.text().strip(),
                   "page": self.r_page.currentData() or "A4", "version": plugin_version()}
        self._save_branding(options)
        return options

    def _build_layout(self, reuse=False):
        """Layout of the study. With ``reuse``, an existing layout of the same
        name is returned untouched so the edits made in the designer are kept."""
        from ..core.layout import build_study_layout, layout_name

        try:
            data, map_layers, legend, extent = self._collect_study()
        except ValueError as err:
            self.set_status(str(err), error=True)
            return None, None, None
        options = self._report_options(data)
        existing = QgsProject.instance().layoutManager().layoutByName(layout_name(options["title"]))
        if reuse and existing is not None:
            return existing, data, options
        layout = build_study_layout(QgsProject.instance(), data, map_layers, legend, extent, options)
        return layout, data, options

    def create_layout(self):
        from ..core.layout import layout_name

        try:
            data = self._collect_study()[0]
        except ValueError as err:
            self.set_status(str(err), error=True)
            return
        name = layout_name(self._report_options(data)["title"])
        if QgsProject.instance().layoutManager().layoutByName(name) is not None:
            answer = QMessageBox.question(
                self, tr("Replace the layout"),
                tr("The layout \"{}\" already exists. Replace it? Changes made in the layout designer will be "
                   "lost.").format(name))
            if answer != QMessageBox.StandardButton.Yes:
                return
        layout, _data, _options = self._build_layout()
        if layout is None:
            return
        self.iface.openLayoutDesigner(layout)
        self._done(tr("Layout \"{}\" created ({} pages).").format(layout.name(), layout.pageCollection().pageCount()))

    def export_study_pdf(self):
        from ..core.layout import export_pdf

        layout, data, _options = self._build_layout(reuse=True)
        if layout is None:
            return
        name = _safe_name(data["lake_name"]) or "lake"
        path, _ = QFileDialog.getSaveFileName(self, tr("Export PDF"), f"limnotools_{name}.pdf", tr("PDF files (*.pdf)"))
        if not path:
            return
        if export_pdf(layout, path):
            self._done(tr("PDF exported: {}").format(path))
            QDesktopServices.openUrl(QUrl.fromLocalFile(path))
        else:
            self.set_status(tr("The PDF could not be written: {}").format(path), error=True)

    def export_study_html(self):
        from ..core.layout import map_page_png
        from ..core.report import build_full_report

        layout, data, options = self._build_layout(reuse=True)
        if layout is None:
            return
        name = _safe_name(data["lake_name"]) or "lake"
        path, _ = QFileDialog.getSaveFileName(self, tr("HTML report"), f"limnotools_{name}.html",
                                              tr("HTML files (*.html)"))
        if not path:
            return
        html_text = build_full_report(data, options, map_page_png(layout))
        with open(path, "w", encoding="utf-8") as handle:
            handle.write(html_text)
        self._done(tr("Report saved: {}").format(path))
        QDesktopServices.openUrl(QUrl.fromLocalFile(path))

    # ------------------------------------------------------------- demo data
    def load_demo_data(self):
        if not os.path.exists(SAMPLE_GPKG):
            self.set_status(tr("Demo data not found."), error=True)
            return
        project = QgsProject.instance()
        root = project.layerTreeRoot()
        group = root.findGroup(tr("LimnoTools demo")) or root.insertGroup(0, tr("LimnoTools demo"))
        layers = {}
        loaded = {os.path.normcase(layer.source()): layer for layer in project.mapLayers().values()}
        new_layers = {}
        for table, name in (("stations", tr("Demo stations")), ("soundings", tr("Demo soundings")),
                            ("lake", tr("Demo lake")), ("profiles", tr("Demo probe profiles"))):
            source = f"{SAMPLE_GPKG}|layername={table}"
            existing = loaded.get(os.path.normcase(source))
            if existing is not None:  # already in the project: reuse it
                layers[table] = existing
                continue
            layer = QgsVectorLayer(source, name, "ogr")
            if not layer.isValid():
                continue
            project.addMapLayer(layer, False)
            group.addLayer(layer)
            layers[table] = new_layers[table] = layer
        _style_demo(new_layers)
        if "lake" in layers:
            canvas = self.iface.mapCanvas()
            if not project.crs().isValid() or len(project.mapLayers()) <= len(layers):
                project.setCrs(layers["lake"].crs())
            canvas.setExtent(canvas.mapSettings().layerExtentToOutputExtent(
                layers["lake"], layers["lake"].extent().buffered(layers["lake"].extent().width() * 0.08)))
            canvas.refresh()
            for combo in (self.b_lake, self.m_lake, self.f_lake):
                combo.setLayer(layers["lake"])
        if "soundings" in layers:
            self.b_points.setLayer(layers["soundings"])
            self.b_field.setField("depth")
        if "stations" in layers:
            self.f_points.setLayer(layers["stations"])
            self.t_layer.setLayer(layers["stations"])
        if "profiles" in layers:
            self.s_layer.setLayer(layers["profiles"])
            self._guess_profile_fields(layers["profiles"])
        if "lake" in layers:
            self.m_name.setLayer(layers["lake"])
            self.m_name.setField("name")
        self.set_status(tr("Demo data loaded: start with the Bathymetry tab."))

    def cleanup(self):
        for job in list(self._jobs):
            try:
                job["task"].cancel()
            except RuntimeError:
                pass
        self._jobs = []


def _safe_name(text):
    return "".join(c if c.isalnum() else "_" for c in (text or "")).strip("_").lower()


def _feature_label(feature):
    """Human readable name of a feature: a name-like field, else its id."""
    names = {f.name().lower(): f.name() for f in feature.fields()}
    for key in ("name", "nom", "station", "site", "label", "code", "id"):
        if key in names and not is_missing(feature[names[key]]):
            return str(feature[names[key]])
    return f"#{feature.id()}"


def _size(pixels):
    from qgis.PyQt.QtCore import QSize

    return QSize(pixels, pixels)


def _style_demo(layers):
    from qgis.core import QgsFillSymbol, QgsMarkerSymbol, QgsSingleSymbolRenderer

    if "lake" in layers:
        layers["lake"].setRenderer(QgsSingleSymbolRenderer(QgsFillSymbol.createSimple(
            {"color": "166,206,227,90", "outline_color": "#1f4e8c", "outline_width": "0.5"})))
    if "soundings" in layers:
        layers["soundings"].setRenderer(QgsSingleSymbolRenderer(QgsMarkerSymbol.createSimple(
            {"name": "circle", "color": "#1f4e8c", "size": "0.9", "outline_style": "no"})))
    if "stations" in layers:
        layers["stations"].setRenderer(QgsSingleSymbolRenderer(QgsMarkerSymbol.createSimple(
            {"name": "diamond", "color": "#e07a1f", "size": "3.2", "outline_color": "#ffffff"})))
    for layer in layers.values():
        layer.triggerRepaint()
