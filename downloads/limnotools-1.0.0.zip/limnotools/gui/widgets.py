"""Custom widgets and theme of the LimnoTools panel."""

from qgis.PyQt.QtCore import QPointF, QRectF, Qt, pyqtSignal
from qgis.PyQt.QtGui import QBrush, QColor, QFont, QPainter, QPainterPath, QPalette, QPen
from qgis.PyQt.QtWidgets import QFrame, QGridLayout, QLabel, QSizePolicy, QVBoxLayout, QWidget

from ..core.textfmt import area as fmt_area
from ..core.textfmt import length as fmt_length
from ..core.textfmt import number as fmt_number
from ..core.textfmt import volume as fmt_volume

__all__ = ["fmt_area", "fmt_length", "fmt_number", "fmt_volume"]

LIGHT = {
    "accent": "#0f6e8c",
    "accent_hover": "#0b5872",
    "accent_soft": "#e2f0f4",
    "warm": "#e07a1f",
    "card": "#ffffff",
    "tile": "#f4f7fa",
    "border": "#dbe2ea",
    "text": "#14213d",
    "muted": "#5b6475",
    "grid": "#e8edf2",
    "on_accent": "#ffffff",
}

DARK = {
    "accent": "#3cb8cf",
    "accent_hover": "#5fc8db",
    "accent_soft": "#1d3a42",
    "warm": "#f0a050",
    "card": "#2a2e35",
    "tile": "#23272d",
    "border": "#3b414b",
    "text": "#e8ecf1",
    "muted": "#a2aab6",
    "grid": "#363c45",
    "on_accent": "#0d1b22",
}


def theme_for(widget):
    window = widget.palette().color(QPalette.ColorRole.Window)
    return DARK if window.lightness() < 128 else LIGHT


def stylesheet(t):
    return f"""
#limnoRoot {{ font-size: 9pt; }}
#limnoHeaderTitle {{ font-size: 13pt; font-weight: 600; color: {t['text']}; }}
#limnoHeaderSub {{ color: {t['muted']}; }}
#limnoNav {{ background: {t['card']}; border: 1px solid {t['border']}; border-radius: 8px; }}
QToolButton#navButton {{
    border: none; border-radius: 6px; padding: 5px 2px; color: {t['muted']}; font-size: 8pt;
}}
QToolButton#navButton:hover {{ background: {t['tile']}; color: {t['text']}; }}
QToolButton#navButton:checked {{ background: {t['accent_soft']}; color: {t['accent']}; font-weight: 600; }}
#pageTitle {{ font-size: 12pt; font-weight: 600; color: {t['text']}; }}
#pageDescription {{ color: {t['muted']}; }}
QFrame#card {{ background: {t['card']}; border: 1px solid {t['border']}; border-radius: 8px; }}
QFrame#card QLabel {{ background: transparent; }}
QLabel#fieldLabel {{ color: {t['muted']}; font-size: 8pt; font-weight: 600; }}
QLabel#sectionLabel {{ color: {t['muted']}; font-size: 8pt; font-weight: 600; letter-spacing: 1px; }}
QPushButton#primary {{
    background: {t['accent']}; color: {t['on_accent']}; border: none; border-radius: 6px;
    padding: 7px 14px; font-weight: 600;
}}
QPushButton#primary:hover {{ background: {t['accent_hover']}; }}
QPushButton#primary:disabled {{ background: {t['border']}; color: {t['muted']}; }}
QPushButton#secondary {{
    background: transparent; color: {t['text']}; border: 1px solid {t['border']}; border-radius: 6px;
    padding: 5px 10px;
}}
QPushButton#secondary:hover {{ border-color: {t['accent']}; color: {t['accent']}; }}
QPushButton#link {{ background: transparent; border: none; color: {t['accent']}; padding: 2px; }}
QPushButton#link:hover {{ text-decoration: underline; }}
QProgressBar#thinProgress {{ background: {t['grid']}; border: none; border-radius: 2px; max-height: 4px; }}
QProgressBar#thinProgress::chunk {{ background: {t['accent']}; border-radius: 2px; }}
QFrame#tile {{ background: {t['tile']}; border: 1px solid {t['border']}; border-radius: 7px; }}
QLabel#tileValue {{ font-size: 12pt; font-weight: 600; color: {t['text']}; background: transparent; }}
QLabel#tileLabel {{ color: {t['muted']}; font-size: 8pt; background: transparent; }}
QLabel#status {{ color: {t['muted']}; font-size: 8pt; }}
QLabel#statusError {{ color: #d1453b; font-size: 8pt; }}
QScrollArea {{ background: transparent; border: none; }}
QScrollArea > QWidget > QWidget {{ background: transparent; }}
"""


class Card(QFrame):
    """Rounded container with an optional small caps title."""

    def __init__(self, title=None, parent=None):
        super().__init__(parent)
        self.setObjectName("card")
        self.layout_ = QVBoxLayout(self)
        self.layout_.setContentsMargins(12, 10, 12, 12)
        self.layout_.setSpacing(6)
        if title:
            label = QLabel(title.upper())
            label.setObjectName("sectionLabel")
            self.layout_.addWidget(label)

    def add(self, widget):
        self.layout_.addWidget(widget)
        return widget

    def add_field(self, label, widget):
        caption = QLabel(label)
        caption.setObjectName("fieldLabel")
        self.layout_.addWidget(caption)
        self.layout_.addWidget(widget)
        return widget


class Tile(QFrame):
    def __init__(self, label, parent=None):
        super().__init__(parent)
        self.setObjectName("tile")
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 7, 10, 7)
        layout.setSpacing(0)
        self.value = QLabel("-")
        self.value.setObjectName("tileValue")
        self.value.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self.caption = QLabel(label)
        self.caption.setObjectName("tileLabel")
        self.caption.setWordWrap(True)
        layout.addWidget(self.value)
        layout.addWidget(self.caption)

    def set_value(self, text, tooltip=None):
        self.value.setText(text)
        if tooltip:
            self.setToolTip(tooltip)


class TileGrid(QWidget):
    """Two column grid of metric tiles."""

    def __init__(self, items, columns=2, parent=None):
        super().__init__(parent)
        grid = QGridLayout(self)
        grid.setContentsMargins(0, 0, 0, 0)
        grid.setSpacing(6)
        self.tiles = {}
        for i, (key, label) in enumerate(items):
            tile = Tile(label)
            grid.addWidget(tile, i // columns, i % columns)
            self.tiles[key] = tile

    def set(self, key, text, tooltip=None):
        if key in self.tiles:
            self.tiles[key].set_value(text, tooltip)

    def clear(self):
        for tile in self.tiles.values():
            tile.set_value("-")


class HypsoChart(QWidget):
    """Interactive hypsographic curve (area and cumulative volume vs depth)."""

    hovered = pyqtSignal(float)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.rows = []
        self.theme = LIGHT
        self.hover_depth = None
        self.drawdown = None
        self.labels = ("Area at depth", "Cumulative volume")
        self.empty_text = "Run the tool to draw the hypsographic curve"
        self.hover_format = "{depth:.2f} m   area {area:.0f}%   volume {vol:.0f}%"
        self.setMinimumHeight(250)
        self.setMouseTracking(True)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)

    def set_rows(self, rows):
        self.rows = rows or []
        self.hover_depth = None
        self.update()

    def set_drawdown(self, depth):
        self.drawdown = depth
        self.update()

    def _plot_rect(self):
        return QRectF(42, 12, max(10, self.width() - 54), max(10, self.height() - 62))

    def mouseMoveEvent(self, event):  # noqa: N802
        if not self.rows:
            return
        rect = self._plot_rect()
        pos = event.position() if hasattr(event, "position") else QPointF(event.pos())
        if rect.contains(pos):
            zmax = self.rows[-1]["depth"] or 1.0
            self.hover_depth = (pos.y() - rect.top()) / rect.height() * zmax
            self.hovered.emit(self.hover_depth)
        else:
            self.hover_depth = None
        self.update()

    def leaveEvent(self, event):  # noqa: N802
        self.hover_depth = None
        self.update()

    def value_at(self, depth, key):
        rows = self.rows
        if not rows:
            return None
        if depth <= rows[0]["depth"]:
            return rows[0][key]
        for a, b in zip(rows, rows[1:]):
            if a["depth"] <= depth <= b["depth"]:
                span = b["depth"] - a["depth"] or 1.0
                f = (depth - a["depth"]) / span
                return a[key] + (b[key] - a[key]) * f
        return rows[-1][key]

    def paintEvent(self, event):  # noqa: N802
        t = self.theme
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        rect = self._plot_rect()
        small = QFont(self.font())
        small.setPointSizeF(max(6.5, small.pointSizeF() * 0.85))
        painter.setFont(small)

        if not self.rows:
            painter.setPen(QColor(t["muted"]))
            painter.drawText(QRectF(self.rect()), Qt.AlignmentFlag.AlignCenter,
                             self.empty_text)
            return

        zmax = self.rows[-1]["depth"] or 1.0

        def px(pct):
            return rect.left() + rect.width() * pct / 100.0

        def py(depth):
            return rect.top() + rect.height() * depth / zmax

        grid_pen = QPen(QColor(t["grid"]))
        grid_pen.setWidthF(1)
        for i in range(6):
            pct = i * 20
            painter.setPen(grid_pen)
            painter.drawLine(QPointF(px(pct), rect.top()), QPointF(px(pct), rect.bottom()))
            painter.setPen(QColor(t["muted"]))
            painter.drawText(QRectF(px(pct) - 20, rect.bottom() + 3, 40, 14), Qt.AlignmentFlag.AlignCenter, f"{pct}%")
            depth = zmax * i / 5
            painter.setPen(grid_pen)
            painter.drawLine(QPointF(rect.left(), py(depth)), QPointF(rect.right(), py(depth)))
            painter.setPen(QColor(t["muted"]))
            painter.drawText(QRectF(0, py(depth) - 7, rect.left() - 5, 14),
                             Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter, fmt_number(depth, 1))

        area_path = QPainterPath(QPointF(px(0), py(0)))
        for row in self.rows:
            area_path.lineTo(QPointF(px(row["area_pct"]), py(row["depth"])))
        fill = QPainterPath(area_path)
        fill.lineTo(QPointF(px(0), py(zmax)))
        fill.closeSubpath()
        accent = QColor(t["accent"])
        soft = QColor(accent)
        soft.setAlpha(40)
        painter.fillPath(fill, QBrush(soft))
        pen = QPen(accent)
        pen.setWidthF(2.2)
        painter.setPen(pen)
        painter.drawPath(area_path)

        vol_path = QPainterPath(QPointF(px(self.rows[0]["volume_above_pct"]), py(self.rows[0]["depth"])))
        for row in self.rows[1:]:
            vol_path.lineTo(QPointF(px(row["volume_above_pct"]), py(row["depth"])))
        pen = QPen(QColor(t["warm"]))
        pen.setWidthF(2.2)
        pen.setStyle(Qt.PenStyle.DashLine)
        painter.setPen(pen)
        painter.drawPath(vol_path)

        if self.drawdown:
            pen = QPen(QColor("#d1453b"))
            pen.setWidthF(1.4)
            painter.setPen(pen)
            painter.drawLine(QPointF(rect.left(), py(self.drawdown)), QPointF(rect.right(), py(self.drawdown)))

        # Legend
        ly = rect.bottom() + 36
        painter.setPen(QPen(accent, 2.2))
        painter.drawLine(QPointF(rect.left(), ly), QPointF(rect.left() + 16, ly))
        painter.setPen(QColor(t["muted"]))
        painter.drawText(QPointF(rect.left() + 20, ly + 4), self.labels[0])
        x2 = rect.left() + rect.width() / 2
        dash = QPen(QColor(t["warm"]), 2.2)
        dash.setStyle(Qt.PenStyle.DashLine)
        painter.setPen(dash)
        painter.drawLine(QPointF(x2, ly), QPointF(x2 + 16, ly))
        painter.setPen(QColor(t["muted"]))
        painter.drawText(QPointF(x2 + 20, ly + 4), self.labels[1])

        if self.hover_depth is not None:
            depth = max(0.0, min(zmax, self.hover_depth))
            area = self.value_at(depth, "area_pct")
            vol = self.value_at(depth, "volume_above_pct")
            pen = QPen(QColor(t["text"]))
            pen.setWidthF(0.8)
            pen.setStyle(Qt.PenStyle.DotLine)
            painter.setPen(pen)
            painter.drawLine(QPointF(rect.left(), py(depth)), QPointF(rect.right(), py(depth)))
            for pct, color in ((area, accent), (vol, QColor(t["warm"]))):
                painter.setPen(QPen(QColor(t["card"]), 1.5))
                painter.setBrush(QBrush(color))
                painter.drawEllipse(QPointF(px(pct), py(depth)), 4, 4)
            text = self.hover_format.format(depth=depth, area=area, vol=vol)
            width = painter.fontMetrics().horizontalAdvance(text) + 14
            box = QRectF(rect.right() - width, rect.top() + 2, width, 20)
            painter.setPen(QPen(QColor(t["border"])))
            painter.setBrush(QBrush(QColor(t["card"])))
            painter.drawRoundedRect(box, 5, 5)
            painter.setPen(QColor(t["text"]))
            painter.drawText(box, Qt.AlignmentFlag.AlignCenter, text)
        painter.end()


class TrophicBar(QWidget):
    """Stacked bar showing how many stations fall in each trophic class."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.counts = {}
        self.styles = {}
        self.theme = LIGHT
        self.setMinimumHeight(86)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)

    def set_data(self, counts, styles):
        self.counts, self.styles = counts, styles
        self.update()

    def paintEvent(self, event):  # noqa: N802
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        t = self.theme
        total = sum(self.counts.get(k, 0) for k in self.styles)
        bar = QRectF(0, 4, self.width(), 18)
        if not total:
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(QBrush(QColor(t["grid"])))
            painter.drawRoundedRect(bar, 6, 6)
            painter.end()
            return
        clip = QPainterPath()
        clip.addRoundedRect(bar, 6, 6)
        painter.setClipPath(clip)
        x = bar.left()
        for key, (color, _label) in self.styles.items():
            n = self.counts.get(key, 0)
            if not n:
                continue
            w = bar.width() * n / total
            painter.fillRect(QRectF(x, bar.top(), w, bar.height()), QColor(color))
            x += w
        painter.setClipping(False)
        small = QFont(self.font())
        small.setPointSizeF(max(6.5, small.pointSizeF() * 0.85))
        painter.setFont(small)
        col_w = self.width() / 2
        for i, (key, (color, label)) in enumerate(self.styles.items()):
            cx = (i % 2) * col_w
            cy = 34 + (i // 2) * 22
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(QBrush(QColor(color)))
            painter.drawRoundedRect(QRectF(cx, cy, 10, 10), 2, 2)
            painter.setPen(QColor(t["text"]))
            painter.drawText(QPointF(cx + 15, cy + 9), f"{label}: {self.counts.get(key, 0)}")
        painter.end()


class ProfileChart(QWidget):
    """Vertical profile: temperature and oxygen against depth, with the
    epilimnion, metalimnion and hypolimnion shaded."""

    LAYER_COLORS = ("#f4a259", "#9b8fd6", "#3d7ea6")  # epi, meta, hypo

    def __init__(self, parent=None):
        super().__init__(parent)
        self.data = None
        self.theme = LIGHT
        self.empty_text = "Run the tool to draw the profile"
        self.labels = ("Temperature (°C)", "Oxygen (mg/L)", "Epilimnion", "Metalimnion", "Hypolimnion",
                       "Thermocline")
        self.setMinimumHeight(300)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)

    def set_profile(self, data):
        self.data = data
        self.update()

    @staticmethod
    def _range(values, pad):
        values = [v for v in values if v is not None and v == v]
        if not values:
            return 0.0, 1.0
        low, high = min(values), max(values)
        if high - low < pad:
            mid = (high + low) / 2
            low, high = mid - pad / 2, mid + pad / 2
        return low, high

    def paintEvent(self, event):  # noqa: N802
        t = self.theme
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        small = QFont(self.font())
        small.setPointSizeF(max(6.5, small.pointSizeF() * 0.85))
        painter.setFont(small)
        rect = QRectF(40, 30, max(10, self.width() - 52), max(10, self.height() - 76))

        if not self.data:
            painter.setPen(QColor(t["muted"]))
            painter.drawText(QRectF(self.rect()), Qt.AlignmentFlag.AlignCenter, self.empty_text)
            painter.end()
            return

        profile = self.data["profile"]
        depths = profile["depth"]
        zmax = max(depths) if depths else 1.0
        zmax = max(zmax, 0.5)
        tmin, tmax = self._range(profile["temp"], 1.0)
        oxygen = profile.get("oxygen")
        omin, omax = (0.0, max(1.0, max((o for o in oxygen if o is not None and o == o), default=1.0))) \
            if oxygen else (0.0, 1.0)

        def py(z):
            return rect.top() + rect.height() * z / zmax

        def px_t(v):
            return rect.left() + rect.width() * (v - tmin) / (tmax - tmin)

        def px_o(v):
            return rect.left() + rect.width() * (v - omin) / (omax - omin)

        # Layers
        if self.data.get("stratified"):
            bounds = (0.0, self.data.get("epi_bottom") or 0.0, self.data.get("hypo_top") or zmax, zmax)
            for k, color in enumerate(self.LAYER_COLORS):
                top, bottom = min(bounds[k], zmax), min(bounds[k + 1], zmax)
                if bottom > top:
                    fill = QColor(color)
                    fill.setAlpha(45)
                    painter.fillRect(QRectF(rect.left(), py(top), rect.width(), py(bottom) - py(top)), fill)
                    painter.setPen(QColor(color))
                    if k < 2:  # curves are on the right in the warm, oxygenated layers
                        painter.drawText(QRectF(rect.left() + 4, py(top) + 2, 110, 14),
                                         Qt.AlignmentFlag.AlignLeft, self.labels[2 + k])
                    else:
                        painter.drawText(QRectF(rect.right() - 110, py(top) + 2, 106, 14),
                                         Qt.AlignmentFlag.AlignRight, self.labels[2 + k])

        # Grid and depth axis
        grid = QPen(QColor(t["grid"]))
        for i in range(6):
            z = zmax * i / 5
            painter.setPen(grid)
            painter.drawLine(QPointF(rect.left(), py(z)), QPointF(rect.right(), py(z)))
            painter.setPen(QColor(t["muted"]))
            painter.drawText(QRectF(0, py(z) - 7, rect.left() - 5, 14),
                             Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter, fmt_number(z, 1))
        for i in range(5):
            x = rect.left() + rect.width() * i / 4
            painter.setPen(grid)
            painter.drawLine(QPointF(x, rect.top()), QPointF(x, rect.bottom()))
            painter.setPen(QColor("#d1453b"))
            painter.drawText(QRectF(x - 24, rect.bottom() + 3, 48, 14), Qt.AlignmentFlag.AlignCenter,
                             fmt_number(tmin + (tmax - tmin) * i / 4, 1))
            if oxygen:
                painter.setPen(QColor(t["accent"]))
                painter.drawText(QRectF(x - 24, rect.top() - 17, 48, 14), Qt.AlignmentFlag.AlignCenter,
                                 fmt_number(omin + (omax - omin) * i / 4, 1))

        # Thermocline
        thermo = self.data.get("thermocline")
        if thermo is not None:
            pen = QPen(QColor(t["text"]), 1.2)
            pen.setStyle(Qt.PenStyle.DashLine)
            painter.setPen(pen)
            painter.drawLine(QPointF(rect.left(), py(thermo)), QPointF(rect.right(), py(thermo)))
            label = f"{self.labels[5]} {fmt_number(thermo, 1, 'm')}"
            painter.drawText(QPointF(rect.left() + 4, py(thermo) + 12), label)

        def curve(values, mapper, color, dashed=False):
            path = None
            for z, v in zip(depths, values):
                if v is None or v != v:
                    continue
                point = QPointF(mapper(v), py(z))
                if path is None:
                    path = QPainterPath(point)
                else:
                    path.lineTo(point)
            if path is None:
                return
            pen = QPen(QColor(color), 2.2)
            if dashed:
                pen.setStyle(Qt.PenStyle.DashLine)
            painter.setPen(pen)
            painter.setBrush(Qt.BrushStyle.NoBrush)
            painter.drawPath(path)

        if oxygen:
            curve(oxygen, px_o, t["accent"], dashed=True)
        curve(profile["temp"], px_t, "#d1453b")

        # Legend
        ly = rect.bottom() + 32
        painter.setPen(QPen(QColor("#d1453b"), 2.2))
        painter.drawLine(QPointF(rect.left(), ly), QPointF(rect.left() + 16, ly))
        painter.setPen(QColor(t["muted"]))
        painter.drawText(QPointF(rect.left() + 20, ly + 4), self.labels[0])
        if oxygen:
            x2 = rect.left() + rect.width() / 2
            dash = QPen(QColor(t["accent"]), 2.2)
            dash.setStyle(Qt.PenStyle.DashLine)
            painter.setPen(dash)
            painter.drawLine(QPointF(x2, ly), QPointF(x2 + 16, ly))
            painter.setPen(QColor(t["muted"]))
            painter.drawText(QPointF(x2 + 20, ly + 4), self.labels[1])
        painter.end()
