"""Pure limnological formulas (NumPy only, no QGIS dependency).

References
----------
* Hutchinson G.E. (1957). A Treatise on Limnology, vol. 1. Wiley.
* Wetzel R.G. (2001). Limnology: Lake and River Ecosystems, 3rd ed. Academic Press.
* Hakanson L. (2004). Lakes: Form and Function. Blackburn Press.
* Carlson R.E. (1977). A trophic state index for lakes. Limnology and
  Oceanography 22(2): 361-369.
* Carlson R.E. & Simpson J. (1996). A Coordinator's Guide to Volunteer Lake
  Monitoring Methods. North American Lake Management Society.
* U.S. Army Corps of Engineers (1984). Shore Protection Manual, 4th ed.
"""

import math

import numpy as np

# --------------------------------------------------------------------------
# Morphometric indices
# --------------------------------------------------------------------------


def shoreline_development(perimeter, area):
    """Shoreline development index D_L = L / (2 * sqrt(pi * A)).

    Equals 1 for a perfect circle and grows with the irregularity of the
    shoreline (bays, peninsulas, islands).
    """
    if area <= 0:
        return float("nan")
    return perimeter / (2.0 * math.sqrt(math.pi * area))


def relative_depth(max_depth, area):
    """Relative depth Z_r (%) = 50 * Z_max * sqrt(pi) / sqrt(A).

    Most lakes have Z_r < 2 %; deep lakes with a small surface reach > 4 %
    and tend to stratify strongly.
    """
    if area <= 0:
        return float("nan")
    return 50.0 * max_depth * math.sqrt(math.pi) / math.sqrt(area)


def volume_development(mean_depth, max_depth):
    """Volume development D_V = 3 * Z_mean / Z_max.

    1 for a cone-shaped basin, > 1 for a flat bottomed basin (bowl), < 1 for
    a basin with a deep narrow hole.
    """
    if max_depth <= 0:
        return float("nan")
    return 3.0 * mean_depth / max_depth


def depth_statistics(depths, pixel_area):
    """Volume and depth statistics from a 1-D array of valid depths (m).

    ``depths`` must contain positive depths of the wet pixels only.
    Returns a dict with volume (m3), wet area (m2), max, mean and median depth.
    """
    depths = np.asarray(depths, dtype="float64")
    depths = depths[np.isfinite(depths)]
    depths = np.clip(depths, 0.0, None)
    if depths.size == 0:
        return {"volume": 0.0, "wet_area": 0.0, "max_depth": 0.0, "mean_depth": 0.0, "median_depth": 0.0}
    volume = float(depths.sum() * pixel_area)
    wet_area = float(depths.size * pixel_area)
    return {
        "volume": volume,
        "wet_area": wet_area,
        "max_depth": float(depths.max()),
        "mean_depth": volume / wet_area if wet_area else 0.0,
        "median_depth": float(np.median(depths)),
    }


# --------------------------------------------------------------------------
# Hypsometry
# --------------------------------------------------------------------------


def hypsometry(depths, pixel_area, step):
    """Hypsographic table from an array of positive depths (m).

    For every depth level ``z`` (0, step, 2*step ... down to the maximum
    depth) the table gives:

    * ``area``: horizontal area of the lake section at depth z (m2),
    * ``area_pct``: that area as a percentage of the surface area,
    * ``volume_above``: water volume between the surface and z (m3),
    * ``volume_below``: water volume deeper than z (m3), which is also the
      volume left if the water level drops by z metres,
    * ``volume_above_pct``: cumulative volume percentage.

    Returns a list of dicts, ordered from the surface to the bottom.
    """
    if step <= 0:
        raise ValueError("The depth step must be strictly positive.")
    depths = np.asarray(depths, dtype="float64")
    depths = depths[np.isfinite(depths)]
    depths = np.clip(depths, 0.0, None)
    if depths.size == 0:
        return []

    total_area = depths.size * pixel_area
    total_volume = float(depths.sum() * pixel_area)
    zmax = float(depths.max())

    levels = np.arange(0.0, zmax + step * 1e-6, step)
    if levels[-1] < zmax - 1e-9:
        levels = np.append(levels, zmax)

    sorted_depths = np.sort(depths)
    cumsum = np.concatenate([[0.0], np.cumsum(sorted_depths)])
    n = sorted_depths.size

    rows = []
    for z in levels:
        # pixels strictly deeper than z (the section at depth z)
        idx = np.searchsorted(sorted_depths, z, side="right")
        deeper = n - idx
        area = deeper * pixel_area
        if z == 0.0:
            area = total_area
        volume_below = float((cumsum[n] - cumsum[idx]) - z * deeper) * pixel_area
        volume_above = total_volume - volume_below
        rows.append(
            {
                "depth": float(round(z, 6)),
                "area": float(area),
                "area_pct": 100.0 * area / total_area if total_area else 0.0,
                "volume_above": float(volume_above),
                "volume_below": float(volume_below),
                "volume_above_pct": 100.0 * volume_above / total_volume if total_volume else 0.0,
            }
        )
    return rows


# --------------------------------------------------------------------------
# Wind fetch
# --------------------------------------------------------------------------


def effective_fetch(directions_deg, fetches, wind_direction_deg, half_window_deg=45.0):
    """Effective fetch (Shore Protection Manual, 1984).

    F_eff = sum(F_i * cos(a_i)^2) / sum(cos(a_i)) for the radials a_i lying
    within +/- ``half_window_deg`` of the wind direction. ``directions_deg``
    are the azimuths (degrees, clockwise from north) towards which the fetch
    was measured; the wind blows *from* ``wind_direction_deg`` so the waves
    reaching the point travel over the water located upwind.
    """
    directions = np.asarray(directions_deg, dtype="float64")
    fetches = np.asarray(fetches, dtype="float64")
    diff = (directions - wind_direction_deg + 180.0) % 360.0 - 180.0
    mask = np.abs(diff) <= half_window_deg + 1e-9
    if not mask.any():
        return 0.0
    cosines = np.cos(np.radians(diff[mask]))
    denominator = cosines.sum()
    if denominator <= 0:
        return 0.0
    return float((fetches[mask] * cosines ** 2).sum() / denominator)


# --------------------------------------------------------------------------
# Carlson Trophic State Index
# --------------------------------------------------------------------------

TROPHIC_CLASSES = (
    # (upper bound, key)
    (40.0, "oligotrophic"),
    (50.0, "mesotrophic"),
    (70.0, "eutrophic"),
    (float("inf"), "hypereutrophic"),
)


def _valid_positive(value):
    try:
        value = float(value)
    except (TypeError, ValueError):
        return None
    if not math.isfinite(value) or value <= 0:
        return None
    return value


def tsi_secchi(secchi_m):
    """TSI(SD) = 60 - 14.41 ln(SD), Secchi depth in metres."""
    value = _valid_positive(secchi_m)
    return None if value is None else 60.0 - 14.41 * math.log(value)


def tsi_chlorophyll(chl_ug_l):
    """TSI(CHL) = 9.81 ln(CHL) + 30.6, chlorophyll-a in ug/L."""
    value = _valid_positive(chl_ug_l)
    return None if value is None else 9.81 * math.log(value) + 30.6


def tsi_phosphorus(tp_ug_l):
    """TSI(TP) = 14.42 ln(TP) + 4.15, total phosphorus in ug/L."""
    value = _valid_positive(tp_ug_l)
    return None if value is None else 14.42 * math.log(value) + 4.15


def trophic_class(tsi):
    """Trophic state key for a TSI value (Carlson & Simpson 1996)."""
    if tsi is None:
        return None
    for upper, key in TROPHIC_CLASSES:
        if tsi < upper:
            return key
    return TROPHIC_CLASSES[-1][1]


def carlson_tsi(secchi_m=None, chl_ug_l=None, tp_ug_l=None):
    """All Carlson indices for one sample.

    Returns a dict with the three partial indices (None when the variable is
    missing), their mean, the trophic class and the two classic deviations
    used to interpret limitation (Carlson 1991):

    * TSI(CHL) - TSI(SD) < 0: non algal turbidity (clay, colour);
    * TSI(CHL) - TSI(TP) < 0: phosphorus is not the limiting factor
      (nitrogen or light limitation, grazing).
    """
    sd = tsi_secchi(secchi_m)
    chl = tsi_chlorophyll(chl_ug_l)
    tp = tsi_phosphorus(tp_ug_l)
    values = [v for v in (sd, chl, tp) if v is not None]
    mean = sum(values) / len(values) if values else None
    return {
        "tsi_sd": sd,
        "tsi_chl": chl,
        "tsi_tp": tp,
        "tsi_mean": mean,
        "trophic_class": trophic_class(mean),
        "dev_chl_sd": chl - sd if chl is not None and sd is not None else None,
        "dev_chl_tp": chl - tp if chl is not None and tp is not None else None,
    }
