"""Standalone HTML reports (inline CSS, SVG and images, no external resources)."""

import base64
import datetime
import html

from qgis.PyQt.QtCore import QCoreApplication

from . import sections
from . import textfmt as tf
from .svg import class_bar_svg, hypsography_svg, profile_svg


def _t(text):
    return QCoreApplication.translate("LimnoTools", text)


def _e(text):
    return html.escape(str(text))


CSS = """
:root{--ink:#14213d;--muted:#5b6475;--line:#dfe5ee;--accent:#0f6e8c;--bg:#f6f8fb;--card:#fff}
*{box-sizing:border-box}body{margin:0;font-family:"Segoe UI",Roboto,Helvetica,Arial,sans-serif;
color:var(--ink);background:var(--bg);line-height:1.45}
header{background:linear-gradient(120deg,#0b3c5d,#0f6e8c 60%,#2aa7b8);color:#fff;padding:28px 40px}
header h1{margin:0;font-size:26px;font-weight:600}header p{margin:4px 0 0;opacity:.9;font-size:14px}
header .meta{font-size:12px;opacity:.75;margin-top:10px}
header .brand{display:flex;align-items:center;gap:18px}
header .logo{background:#fff;border-radius:8px;padding:8px 12px;display:flex;align-items:center}
header .logo img{max-height:56px;max-width:180px;display:block}
nav{max-width:1000px;margin:16px auto 0;padding:0 20px;display:flex;flex-wrap:wrap;gap:8px}
nav a{font-size:13px;color:var(--accent);text-decoration:none;border:1px solid var(--line);
background:#fff;border-radius:999px;padding:4px 12px}
main{max-width:1000px;margin:0 auto;padding:20px 20px 48px}
section{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:20px 24px;margin-bottom:20px}
h2{font-size:19px;margin:0 0 14px}h3{font-size:13px;margin:18px 0 8px;color:var(--muted);
text-transform:uppercase;letter-spacing:.05em}
.tiles{display:grid;grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:10px}
.tile{border:1px solid var(--line);border-radius:8px;padding:10px 12px}
.tile .v{font-size:19px;font-weight:600;font-variant-numeric:tabular-nums}
.tile .l{font-size:12px;color:var(--muted)}
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:18px}
@media (max-width:760px){.grid2{grid-template-columns:1fr}}
table{border-collapse:collapse;width:100%;font-size:13px;font-variant-numeric:tabular-nums}
th,td{padding:6px 8px;border-bottom:1px solid var(--line);text-align:right}
th:first-child,td:first-child{text-align:left}th{color:var(--muted);font-weight:600}
.swatch{display:inline-block;width:10px;height:10px;border-radius:2px;margin-right:6px}
.note{font-size:12px;color:var(--muted)}footer{text-align:center;font-size:12px;color:var(--muted)}
.map img{width:100%;border:1px solid var(--line);border-radius:6px}
svg{max-width:100%;height:auto}svg text{font-family:"Segoe UI",Roboto,Helvetica,Arial,sans-serif}
ol{font-size:12px;color:var(--muted);padding-left:18px}
"""


def fmt(value, decimals=2, unit=""):
    return tf.number(value, decimals, unit)


# ------------------------------------------------------------ small builders
def tiles_html(pairs):
    cells = "".join(f'<div class="tile"><div class="v">{_e(v)}</div><div class="l">{_e(label)}</div></div>'
                    for label, v in pairs)
    return f'<div class="tiles">{cells}</div>'


def table_html(headers, rows, colors=None):
    head = "".join(f"<th>{_e(h)}</th>" for h in headers)
    body = []
    for i, row in enumerate(rows):
        cells = []
        for j, cell in enumerate(row):
            swatch = ""
            if j == 0 and colors and colors[i]:
                swatch = f'<span class="swatch" style="background:{colors[i]}"></span>'
            cells.append(f"<td>{swatch}{_e(cell)}</td>")
        body.append("<tr>" + "".join(cells) + "</tr>")
    return f"<table><thead><tr>{head}</tr></thead><tbody>{''.join(body)}</tbody></table>"


def _logo_html(path):
    """Organisation logo embedded in the page (no external file needed)."""
    import mimetypes
    import os

    if not path or not os.path.isfile(path):
        return ""
    mime = mimetypes.guess_type(path)[0] or "image/png"
    with open(path, "rb") as handle:
        encoded = base64.b64encode(handle.read()).decode()
    return f'<div class="logo"><img alt="" src="data:{mime};base64,{encoded}"></div>'


def _page(title, subtitle, meta, sections_html, nav="", logo="", footer=""):
    footer = footer or _t("Generated with LimnoTools for QGIS")
    return (
        f"<!doctype html><html lang=\"{_e(_t('en'))}\"><head><meta charset=\"utf-8\">"
        "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
        f"<title>{_e(title)}</title><style>{CSS}</style></head><body>"
        f"<header><div class=\"brand\">{logo}<div><h1>{_e(title)}</h1>"
        f"{f'<p>{_e(subtitle)}</p>' if subtitle else ''}"
        f"<div class=\"meta\">{_e(meta)}</div></div></div></header>{nav}"
        f"<main>{sections_html}<footer>{_e(footer)}</footer></main></body></html>"
    )


# ------------------------------------------------- single analysis (Processing)
MORPHO_TILES = (
    ("AREA_HA", "Surface area", 2, "ha"),
    ("PERIM_M", "Shoreline length", 0, "m"),
    ("LMAX_M", "Maximum length", 0, "m"),
    ("WMAX_M", "Maximum width", 0, "m"),
    ("WMEAN_M", "Mean width", 0, "m"),
    ("DL", "Shoreline development", 2, ""),
    ("ISLANDS", "Islands", 0, ""),
    ("VOLUME_M3", "Volume", 0, "m³"),
    ("ZMAX_M", "Maximum depth", 2, "m"),
    ("ZMEAN_M", "Mean depth", 2, "m"),
    ("ZR_PCT", "Relative depth", 2, "%"),
    ("DV", "Volume development", 2, ""),
)


def build_report(title, lakes, version="", crs=""):
    """Report of the morphometry or hypsometry algorithm.

    ``lakes``: list of dicts {"name", "metrics" (dict), "hypsography" (rows or None)}.
    """
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    body = []
    for lake in lakes:
        metrics = lake["metrics"]
        pairs = [(_t(label), fmt(metrics[key], decimals, unit)) for key, label, decimals, unit in MORPHO_TILES
                 if metrics.get(key) is not None]
        body.append(f"<section><h2>{_e(lake['name'])}</h2><h3>{_e(_t('Morphometry'))}</h3>{tiles_html(pairs)}")
        if lake.get("hypsography"):
            headers, rows = sections.hypsography_table({"hypsography": lake["hypsography"]}, max_rows=40)
            body.append(f"<h3>{_e(_t('Hypsographic curve'))}</h3>{hypsography_svg(lake['hypsography'])}")
            body.append(f"<h3>{_e(_t('Hypsographic table'))}</h3>{table_html(headers, rows)}")
            body.append('<p class="note">' + _e(_t(
                "\"Volume below\" is also the volume left in the lake if the water level drops by the depth "
                "given in the first column.")) + "</p>")
        body.append("</section>")
    method_text = _t(
        "Shoreline development D<sub>L</sub> = L / (2&radic;(&pi;A)); relative depth Z<sub>r</sub> = "
        "50 Z<sub>max</sub> &radic;&pi; / &radic;A; volume development D<sub>V</sub> = 3 Z<sub>mean</sub> / "
        "Z<sub>max</sub>; mean depth Z<sub>mean</sub> = V / A (Hutchinson 1957, Wetzel 2001, H&aring;kanson "
        "2004). Maximum length: longest straight line between two shoreline points crossing only water. "
        "Maximum width: longest such line perpendicular to the maximum length. Distances computed in {}.")
    body.append(f"<section><h2>{_e(_t('Methods'))}</h2><p class=\"note\">"
                f"{method_text.format(_e(crs) or _t('the layer CRS'))}</p></section>")
    return _page(title, "", f"LimnoTools {version} · {now}", "".join(body))


# ------------------------------------------------------------ full report
def build_full_report(data, options, map_png=None):
    """Complete report of every analysis available in ``data`` (see sections.py).

    ``options``: same dictionary as the print layout (title, subtitle, organisation, author, logo,
    reference, sources, version).
    """
    from .layout import footer_text

    title = options.get("title") or _t("Lake study")
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    reference = _t("Ref. {}").format(options["reference"]) if options.get("reference") else ""
    fields = (options.get("organisation"), options.get("author"), reference, data.get("lake_name"), now)
    meta = " \u00b7 ".join(v for v in fields if v)
    footer = footer_text(options, data.get("crs") or "", now[:10])
    parts, links = [], []

    def section(anchor, heading, content):
        links.append(f'<a href="#{anchor}">{_e(heading)}</a>')
        parts.append(f'<section id="{anchor}"><h2>{_e(heading)}</h2>{content}</section>')

    overview = tiles_html(sections.key_figures(data))
    if map_png:
        overview = (f'<div class="map"><img alt="{_e(_t("Map"))}" src="data:image/png;base64,'
                    f'{base64.b64encode(map_png).decode()}"></div><h3>{_e(_t("Key figures"))}</h3>{overview}')
    section("overview", _t("Overview"), overview)

    if data.get("bathymetry") or data.get("morphometry"):
        content = ""
        if data.get("bathymetry"):
            content += f"<h3>{_e(_t('Bathymetry'))}</h3>{tiles_html(sections.bathymetry_rows(data))}"
        if data.get("morphometry"):
            content += f"<h3>{_e(_t('Morphometry'))}</h3>{tiles_html(sections.morphometry_rows(data))}"
        section("morphometry", _t("Bathymetry and morphometry"), content)

    if data.get("hypsography"):
        headers, rows = sections.hypsography_table(data, max_rows=30)
        content = (f"{hypsography_svg(data['hypsography'])}<h3>{_e(_t('Hypsographic table'))}</h3>"
                   f"{table_html(headers, rows)}<p class=\"note\">" + _e(_t(
                       "\"Volume below\" is also the volume left in the lake if the water level drops by the "
                       "depth given in the first column.")) + "</p>")
        section("hypsography", _t("Hypsographic curve"), content)

    if data.get("stratification"):
        headers, rows = sections.stratification_table(data)
        charts = "".join(f"<div>{profile_svg(p)}</div>" for p in sections.featured_profiles(data))
        content = f'<div class="grid2">{charts}</div><h3>{_e(_t("Profiles"))}</h3>{table_html(headers, rows)}'
        section("stratification", _t("Thermal stratification"), content)

    if data.get("trophic"):
        headers, rows, colors = sections.trophic_table(data)
        labels = {k: sections.class_label(k) for k in sections.CLASS_LABELS}
        content = class_bar_svg(sections.trophic_counts(data), labels) + table_html(headers, rows, colors)
        section("trophic", _t("Trophic state"), content)

    if data.get("fetch"):
        headers, rows = sections.fetch_table(data)
        wind = data["fetch"].get("wind")
        note = _t("Dominant wind from {} degrees.").format(f"{wind:.0f}") if wind is not None else ""
        section("fetch", _t("Wind fetch"), f'<p class="note">{_e(note)}</p>{table_html(headers, rows)}')

    methods = "".join(f'<p class="note">{_e(p)}</p>' for p in sections.methods(data))
    references = "".join(f"<li>{_e(r)}</li>" for r in sections.REFERENCES)
    section("methods", _t("Methods and references"), f"{methods}<ol>{references}</ol>")

    nav = f"<nav>{''.join(links)}</nav>"
    return _page(title, options.get("subtitle", ""), meta, "".join(parts), nav, _logo_html(options.get("logo")),
                 footer)
