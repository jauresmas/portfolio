"""Content of the report sections, shared by the HTML report and the print layout.

Every function receives the ``data`` dictionary collected from the analyses:

* ``lake_name``, ``crs``
* ``bathymetry``: {"zmax", "zmean", "volume", "pixel"}
* ``morphometry``: metrics of the lake (fields of the morphometry table)
* ``hypsography``: rows of the hypsographic table
* ``fetch``: {"wind", "rows": [{"name", "fetch_max", "dir_max", "fetch_mean", "fetch_eff"}]}
* ``trophic``: [{"name", "secchi", "chl", "tp", "tsi", "class"}]
* ``stratification``: profiles returned by the stratification algorithm

Missing analyses are simply ``None``.
"""

from qgis.PyQt.QtCore import QCoreApplication

from . import textfmt as tf


def _t(text):
    return QCoreApplication.translate("LimnoTools", text)


CLASS_LABELS = {
    "oligotrophic": "Oligotrophic",
    "mesotrophic": "Mesotrophic",
    "eutrophic": "Eutrophic",
    "hypereutrophic": "Hypereutrophic",
}


def class_label(key):
    return _t(CLASS_LABELS[key]) if key in CLASS_LABELS else "-"


def available(data):
    """Names of the analyses present in ``data``."""
    keys = ("bathymetry", "morphometry", "hypsography", "stratification", "trophic", "fetch")
    return [k for k in keys if data.get(k)]


def key_figures(data):
    """Short list of (label, value) for the map sheet."""
    out = []
    morpho = data.get("morphometry") or {}
    bathy = data.get("bathymetry") or {}
    if morpho.get("AREA_M2") is not None:
        out.append((_t("Surface area"), tf.area(morpho["AREA_M2"])))
    volume = morpho.get("VOLUME_M3") if morpho.get("VOLUME_M3") is not None else bathy.get("volume")
    if volume is not None:
        out.append((_t("Volume"), tf.volume(volume)))
    zmax = morpho.get("ZMAX_M") if morpho.get("ZMAX_M") is not None else bathy.get("zmax")
    if zmax is not None:
        out.append((_t("Maximum depth"), tf.number(zmax, 1, "m")))
    zmean = morpho.get("ZMEAN_M") if morpho.get("ZMEAN_M") is not None else bathy.get("zmean")
    if zmean is not None:
        out.append((_t("Mean depth"), tf.number(zmean, 1, "m")))
    if morpho.get("LMAX_M") is not None:
        out.append((_t("Maximum length"), tf.length(morpho["LMAX_M"])))
    if morpho.get("DL") is not None:
        out.append((_t("Shoreline development"), tf.number(morpho["DL"], 2)))
    trophic = data.get("trophic")
    if trophic:
        values = [r["tsi"] for r in trophic if r["tsi"] is not None]
        if values:
            from .limnology import trophic_class

            mean = sum(values) / len(values)
            out.append((_t("Mean TSI"), f"{tf.number(mean, 1)} ({class_label(trophic_class(mean))})"))
    profiles = data.get("stratification")
    if profiles:
        stratified = [p for p in profiles if p["stratified"]]
        out.append((_t("Stratified profiles"), f"{len(stratified)} / {len(profiles)}"))
        thermos = [p["thermocline"] for p in stratified if p["thermocline"] is not None]
        if thermos:
            out.append((_t("Mean thermocline"), tf.number(sum(thermos) / len(thermos), 1, "m")))
    fetch = data.get("fetch")
    if fetch and fetch.get("rows"):
        out.append((_t("Longest fetch"), tf.length(max(r["fetch_max"] or 0 for r in fetch["rows"]))))
    return out


def bathymetry_rows(data):
    bathy = data.get("bathymetry") or {}
    return [
        (_t("Maximum depth"), tf.number(bathy.get("zmax"), 2, "m")),
        (_t("Mean depth"), tf.number(bathy.get("zmean"), 2, "m")),
        (_t("Volume"), tf.volume(bathy.get("volume"))),
        (_t("Pixel size"), tf.number(bathy.get("pixel"), 1, "m")),
    ]


def morphometry_rows(data):
    m = data.get("morphometry") or {}
    rows = [
        (_t("Surface area"), tf.area(m.get("AREA_M2"))),
        (_t("Shoreline length"), tf.length(m.get("PERIM_M"))),
        (_t("Islands"), tf.number(m.get("ISLANDS"), 0)),
        (_t("Maximum length"), tf.length(m.get("LMAX_M"))),
        (_t("Maximum width"), tf.length(m.get("WMAX_M"))),
        (_t("Mean width"), tf.length(m.get("WMEAN_M"))),
        (_t("Shoreline development"), tf.number(m.get("DL"), 2)),
    ]
    if m.get("VOLUME_M3") is not None:
        rows += [
            (_t("Volume"), tf.volume(m.get("VOLUME_M3"))),
            (_t("Maximum depth"), tf.number(m.get("ZMAX_M"), 2, "m")),
            (_t("Mean depth"), tf.number(m.get("ZMEAN_M"), 2, "m")),
            (_t("Relative depth"), tf.number(m.get("ZR_PCT"), 2, "%")),
            (_t("Volume development"), tf.number(m.get("DV"), 2)),
        ]
    return rows


def hypsography_table(data, max_rows=14):
    rows = data.get("hypsography") or []
    if not rows:
        return [], []
    step = max(1, -(-len(rows) // max_rows))
    selected = rows[::step]
    if selected[-1] is not rows[-1]:
        selected.append(rows[-1])
    headers = [_t("Depth (m)"), _t("Area (ha)"), _t("Area (%)"), _t("Volume above (m3)"),
               _t("Volume below (m3)"), _t("Volume (%)")]
    body = [[tf.number(r["depth"], 2), tf.number(r["area"] / 1e4, 2), tf.number(r["area_pct"], 1),
             tf.number(r["volume_above"], 0), tf.number(r["volume_below"], 0),
             tf.number(r["volume_above_pct"], 1)] for r in selected]
    return headers, body


def stratification_table(data):
    profiles = data.get("stratification") or []
    headers = [_t("Station"), _t("Date"), _t("State"), _t("Thermocline"), _t("Epilimnion"), _t("Hypolimnion"),
               _t("Oxycline"), _t("Hypoxia"), _t("Schmidt (J/m2)")]
    body = []
    for p in profiles:
        state = _t("Stratified") if p["stratified"] else _t("Mixed")
        body.append([
            p.get("station") or "-", p.get("date") or "-", state,
            tf.number(p.get("thermocline"), 1, "m"),
            ("0 - " + tf.number(p.get("epi_bottom"), 1, "m")) if p.get("epi_bottom") is not None else "-",
            ("> " + tf.number(p.get("hypo_top"), 1, "m")) if p.get("hypo_top") is not None else "-",
            tf.number(p.get("oxycline"), 1, "m"),
            tf.number(p.get("hypoxia"), 1, "m"),
            tf.number(p.get("schmidt"), 0),
        ])
    return headers, body


def featured_profiles(data, limit=2):
    """The most informative profiles: deepest stratified ones first."""
    profiles = data.get("stratification") or []
    stratified = sorted((p for p in profiles if p["stratified"]), key=lambda p: -(p.get("max_depth") or 0))
    chosen = stratified[:limit]
    if len(chosen) < limit:
        # a mixed profile of the same station shows the seasonal contrast
        for p in sorted(profiles, key=lambda p: -(p.get("max_depth") or 0)):
            if p not in chosen and (not chosen or p.get("station") == chosen[0].get("station")):
                chosen.append(p)
            if len(chosen) >= limit:
                break
    return chosen


def trophic_table(data):
    rows = data.get("trophic") or []
    headers = [_t("Station"), _t("Secchi (m)"), _t("Chl-a (µg/L)"), _t("TP (µg/L)"), _t("TSI"),
               _t("Trophic state")]
    body, colors = [], []
    from .svg import TROPHIC_COLORS

    for r in rows:
        body.append([r.get("name") or "-", tf.number(r.get("secchi"), 2), tf.number(r.get("chl"), 1),
                     tf.number(r.get("tp"), 0), tf.number(r.get("tsi"), 1), class_label(r.get("class"))])
        colors.append(TROPHIC_COLORS.get(r.get("class")))
    return headers, body, colors


def trophic_counts(data):
    counts = {}
    for r in data.get("trophic") or []:
        counts[r.get("class")] = counts.get(r.get("class"), 0) + 1
    return counts


def fetch_table(data):
    fetch = data.get("fetch") or {}
    headers = [_t("Site"), _t("Longest fetch"), _t("Direction"), _t("Mean fetch"), _t("Effective fetch")]
    body = [[r.get("name") or "-", tf.length(r.get("fetch_max")), f"{r.get('dir_max', 0):.0f}°",
             tf.length(r.get("fetch_mean")), tf.length(r.get("fetch_eff"))] for r in fetch.get("rows", [])]
    return headers, body


def methods(data):
    """Plain text paragraphs describing the methods actually used."""
    paragraphs = []
    if data.get("bathymetry"):
        paragraphs.append(_t("Bathymetry: interpolation of the echo-sounding depths (TIN or inverse distance "
                             "weighting) clipped to the lake outline, with the shoreline set to 0 m."))
    if data.get("morphometry"):
        paragraphs.append(_t("Morphometry: shoreline development DL = L / (2 sqrt(pi A)); relative depth "
                             "Zr = 50 Zmax sqrt(pi) / sqrt(A); volume development DV = 3 Zmean / Zmax; mean depth "
                             "Zmean = V / A (Hutchinson 1957, Wetzel 2001, Hakanson 2004)."))
    if data.get("hypsography"):
        paragraphs.append(_t("Hypsography: area of the horizontal section and water volume above and below "
                             "every depth level, computed from the bathymetry pixels."))
    if data.get("stratification"):
        paragraphs.append(_t("Stratification: water density from temperature (Martin & McCutcheon 1999); "
                             "thermocline at the maximum density gradient, metalimnion limits where the "
                             "gradient falls under 0.1 kg/m3/m, Schmidt stability (Idso 1973), methods of "
                             "rLakeAnalyzer (Read et al. 2011). Hypoxia: dissolved oxygen below 2 mg/L."))
    if data.get("trophic"):
        paragraphs.append(_t("Trophic state: Carlson Trophic State Index (1977) from Secchi depth, "
                             "chlorophyll-a and total phosphorus; classes after Carlson & Simpson (1996)."))
    if data.get("fetch"):
        paragraphs.append(_t("Wind fetch: open-water distance along rays cast from each site; effective fetch "
                             "for the dominant wind after the Shore Protection Manual (1984)."))
    return paragraphs


REFERENCES = (
    "Carlson R.E. (1977). A trophic state index for lakes. Limnology and Oceanography 22: 361-369.",
    "Carlson R.E. & Simpson J. (1996). A Coordinator's Guide to Volunteer Lake Monitoring Methods. NALMS.",
    "Hakanson L. (2004). Lakes: Form and Function. Blackburn Press.",
    "Hutchinson G.E. (1957). A Treatise on Limnology, vol. 1. Wiley.",
    "Idso S.B. (1973). On the concept of lake stability. Limnology and Oceanography 18: 681-683.",
    "Martin J.L. & McCutcheon S.C. (1999). Hydrodynamics and Transport for Water Quality Modeling. CRC Press.",
    "Read J.S. et al. (2011). Derivation of lake mixing and stratification indices from high-resolution lake "
    "buoy data. Environmental Modelling & Software 26: 1325-1336.",
    "U.S. Army Corps of Engineers (1984). Shore Protection Manual, 4th ed.",
    "Wetzel R.G. (2001). Limnology: Lake and River Ecosystems, 3rd ed. Academic Press.",
)
