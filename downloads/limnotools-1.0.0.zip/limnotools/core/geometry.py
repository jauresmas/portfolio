"""Geometric helpers built on QGIS geometries and GDAL rasters."""

import math

import numpy as np
from osgeo import gdal, ogr, osr
from qgis.core import QgsGeometry, QgsPointXY

gdal.UseExceptions()
ogr.UseExceptions()


def _polygon_parts(geometry):
    """Single polygons composing ``geometry`` (as QgsGeometry objects)."""
    if geometry.isMultipart():
        return [QgsGeometry.fromPolygonXY(p) for p in geometry.asMultiPolygon()]
    return [QgsGeometry(geometry)]


def shoreline_points(geometry, spacing, max_points=400):
    """Points regularly spaced along the outer and inner rings of a polygon."""
    boundary = QgsGeometry(geometry.constGet().boundary())
    length = boundary.length()
    if length <= 0:
        return []
    spacing = max(spacing, length / max_points)
    densified = boundary.densifyByDistance(spacing)
    points = [QgsPointXY(v) for v in densified.vertices()]
    return points


def segment_inside(geometry, p1, p2, tolerance):
    """True if the straight segment p1-p2 stays on the water surface."""
    line = QgsGeometry.fromPolylineXY([p1, p2])
    return geometry.buffer(tolerance, 4).contains(line) if tolerance > 0 else geometry.contains(line)


def working_geometry(geometry):
    """Lightly simplified copy of a lake for the heavy searches.

    Detailed outlines (tens of thousands of vertices, many islands) make the
    maximum length search very slow. A simplification tolerance of
    sqrt(area) / 5000 (about 2 m for a 100 km2 lake) is far below the
    digitising precision and divides the computing time several times.
    Returns (geometry, tolerance).
    """
    area = geometry.area()
    if area <= 0:
        return geometry, 0.0
    tolerance = math.sqrt(area) / 5000.0
    simple = geometry.simplify(tolerance)
    if simple is None or simple.isEmpty():
        return geometry, 0.0
    if not simple.isGeosValid():
        simple = simple.makeValid()
    return simple, tolerance


def maximum_length(geometry, feedback=None, max_points=300):
    """Maximum length: the longest straight line joining two shoreline points
    that only crosses water (Hakanson 2004). Returns (length, QgsGeometry).
    """
    geometry, simplify_tolerance = working_geometry(geometry)
    candidates = []
    best = (0.0, None)
    for part in _polygon_parts(geometry):
        outer = QgsGeometry.fromPolylineXY(part.asPolygon()[0])
        perimeter = outer.length()
        if perimeter <= 0:
            continue
        spacing = perimeter / max_points
        densified = outer.densifyByDistance(spacing)
        pts = [QgsPointXY(v) for v in densified.vertices()][:-1]
        xy = np.array([[p.x(), p.y()] for p in pts])
        if len(xy) < 2:
            continue
        diff = xy[:, None, :] - xy[None, :, :]
        dist = np.sqrt((diff ** 2).sum(axis=2))
        i_idx, j_idx = np.triu_indices(len(xy), k=1)
        d = dist[i_idx, j_idx]
        order = np.argsort(d)[::-1]
        candidates.append((part, pts, i_idx, j_idx, d, order, spacing))

    tolerance_cache = {}
    for part, pts, i_idx, j_idx, d, order, spacing in candidates:
        tolerance = max(spacing * 0.01, simplify_tolerance)
        buffered = tolerance_cache.setdefault(id(part), part.buffer(tolerance, 4))
        engine = QgsGeometry.createGeometryEngine(buffered.constGet())
        engine.prepareGeometry()
        tested = 0
        for k in order:
            if d[k] <= best[0]:
                break
            line = QgsGeometry.fromPolylineXY([pts[i_idx[k]], pts[j_idx[k]]])
            tested += 1
            if engine.contains(line.constGet()):
                best = (float(d[k]), line)
                break
            if feedback is not None and feedback.isCanceled():
                return best
            if tested > 200000:
                break
    return best


def maximum_width(geometry, length_line, samples=200):
    """Maximum width: the longest line perpendicular to the maximum length
    line that only crosses water. Returns (width, QgsGeometry)."""
    if length_line is None or length_line.isEmpty():
        return 0.0, None
    geometry = working_geometry(geometry)[0]
    a, b = length_line.asPolyline()
    dx, dy = b.x() - a.x(), b.y() - a.y()
    length = math.hypot(dx, dy)
    if length == 0:
        return 0.0, None
    ux, uy = dx / length, dy / length
    nx, ny = -uy, ux
    bbox = geometry.boundingBox()
    reach = math.hypot(bbox.width(), bbox.height()) * 2

    best = (0.0, None)
    for i in range(1, samples):
        t = length * i / samples
        cx, cy = a.x() + ux * t, a.y() + uy * t
        centre = QgsGeometry.fromPointXY(QgsPointXY(cx, cy))
        probe = QgsGeometry.fromPolylineXY(
            [QgsPointXY(cx - nx * reach, cy - ny * reach), QgsPointXY(cx + nx * reach, cy + ny * reach)]
        )
        inter = probe.intersection(geometry)
        if inter.isEmpty():
            continue
        pieces = inter.asMultiPolyline() if inter.isMultipart() else [inter.asPolyline()]
        for piece in pieces:
            if len(piece) < 2:
                continue
            seg = QgsGeometry.fromPolylineXY(piece)
            if seg.distance(centre) > length * 1e-6:
                continue
            if seg.length() > best[0]:
                best = (seg.length(), QgsGeometry.fromPolylineXY([piece[0], piece[-1]]))
    return best


def fetch_rays(geometry, point, directions_deg, max_distance):
    """Open-water distance from ``point`` towards each azimuth.

    Returns a list of (azimuth, distance, QgsGeometry line). The distance is
    0 when the point is not on the water surface.
    """
    origin = QgsGeometry.fromPointXY(point)
    on_water = geometry.buffer(1e-6 * max_distance, 4).contains(origin)
    results = []
    for azimuth in directions_deg:
        rad = math.radians(azimuth)
        end = QgsPointXY(point.x() + math.sin(rad) * max_distance, point.y() + math.cos(rad) * max_distance)
        if not on_water:
            results.append((azimuth, 0.0, QgsGeometry.fromPolylineXY([point, point])))
            continue
        ray = QgsGeometry.fromPolylineXY([point, end])
        inter = ray.intersection(geometry)
        distance, seg_end = 0.0, point
        if not inter.isEmpty():
            pieces = inter.asMultiPolyline() if inter.isMultipart() else [inter.asPolyline()]
            for piece in pieces:
                if len(piece) < 2:
                    continue
                start = QgsGeometry.fromPointXY(piece[0])
                if start.distance(origin) <= max_distance * 1e-6:
                    seg_end = piece[-1]
                    distance = math.hypot(seg_end.x() - point.x(), seg_end.y() - point.y())
                    break
        results.append((azimuth, distance, QgsGeometry.fromPolylineXY([point, seg_end])))
    return results


# --------------------------------------------------------------------------
# Raster access
# --------------------------------------------------------------------------


def read_depths_in_polygon(raster_path, geometry_wkt, band=1, positive_down=True):
    """Valid depth values of the raster pixels whose centre falls inside the
    polygon (given as WKT in the raster CRS).

    Returns (depths ndarray, pixel_area). Depth values are made positive.
    """
    dataset = gdal.Open(raster_path)
    gt = dataset.GetGeoTransform()
    rb = dataset.GetRasterBand(band)
    nodata = rb.GetNoDataValue()
    pixel_area = abs(gt[1] * gt[5])

    geom = ogr.CreateGeometryFromWkt(geometry_wkt)
    minx, maxx, miny, maxy = geom.GetEnvelope()
    inv = gdal.InvGeoTransform(gt)
    cols, rows = dataset.RasterXSize, dataset.RasterYSize
    px = [gdal.ApplyGeoTransform(inv, x, y) for x, y in ((minx, maxy), (maxx, miny))]
    x0 = max(0, int(math.floor(min(px[0][0], px[1][0]))))
    y0 = max(0, int(math.floor(min(px[0][1], px[1][1]))))
    x1 = min(cols, int(math.ceil(max(px[0][0], px[1][0]))))
    y1 = min(rows, int(math.ceil(max(px[0][1], px[1][1]))))
    if x1 <= x0 or y1 <= y0:
        return np.array([]), pixel_area

    data = rb.ReadAsArray(x0, y0, x1 - x0, y1 - y0).astype("float64")
    mask = rasterize_mask(geometry_wkt, (gt[0] + x0 * gt[1], gt[1], 0.0, gt[3] + y0 * gt[5], 0.0, gt[5]),
                          x1 - x0, y1 - y0, dataset.GetProjection())
    valid = mask & np.isfinite(data)
    if nodata is not None:
        valid &= data != nodata
    values = data[valid]
    if not positive_down:
        values = -values
    if values.size and np.nanmedian(values) < 0:
        values = -values  # elevations (negative below the surface)
    return np.clip(values, 0.0, None), pixel_area


def rasterize_mask(geometry_wkt, geotransform, width, height, projection_wkt):
    """Boolean array, True where the pixel centre is inside the geometry."""
    driver = gdal.GetDriverByName("MEM")
    target = driver.Create("", width, height, 1, gdal.GDT_Byte)
    target.SetGeoTransform(geotransform)
    if projection_wkt:
        target.SetProjection(projection_wkt)
    mem = ogr.GetDriverByName("Memory").CreateDataSource("mask")
    srs = osr.SpatialReference()
    if projection_wkt:
        srs.ImportFromWkt(projection_wkt)
    layer = mem.CreateLayer("mask", srs, ogr.wkbMultiPolygon)
    feature = ogr.Feature(layer.GetLayerDefn())
    feature.SetGeometry(ogr.CreateGeometryFromWkt(geometry_wkt))
    layer.CreateFeature(feature)
    gdal.RasterizeLayer(target, [1], layer, burn_values=[1])
    return target.GetRasterBand(1).ReadAsArray().astype(bool)
