"""Thermal stratification of the water column (NumPy only).

Methods follow rLakeAnalyzer (Read et al. 2011), the reference toolbox of the
Global Lake Ecological Observatory Network.

References
----------
* Read J.S. et al. (2011). Derivation of lake mixing and stratification
  indices from high-resolution lake buoy data. Environmental Modelling &
  Software 26: 1325-1336.
* Idso S.B. (1973). On the concept of lake stability. Limnology and
  Oceanography 18: 681-683.
* Martin J.L. & McCutcheon S.C. (1999). Hydrodynamics and Transport for
  Water Quality Modeling. CRC Press.
"""

import numpy as np

GRAVITY = 9.81
HYPOXIA_MG_L = 2.0
MIN_GRADIENT = 0.1  # kg/m3/m
OXYCLINE_MIN_GRADIENT = 0.5  # mg/L per m


def water_density(temperature_c):
    """Density of fresh water (kg/m3) from temperature (Martin & McCutcheon 1999)."""
    t = np.asarray(temperature_c, dtype="float64")
    return 1000.0 * (1.0 - (t + 288.9414) / (508929.2 * (t + 68.12963)) * (t - 3.9863) ** 2)


def clean_profile(depths, values):
    """Profile sorted by depth, finite values only, duplicated depths averaged."""
    depths = np.asarray(depths, dtype="float64")
    values = np.asarray(values, dtype="float64")
    keep = np.isfinite(depths) & np.isfinite(values) & (depths >= 0)
    depths, values = depths[keep], values[keep]
    unique = np.unique(depths)
    means = np.array([values[depths == d].mean() for d in unique])
    return unique, means


def _gradient(z, t):
    rho = water_density(t)
    return np.diff(rho) / np.diff(z), (z[:-1] + z[1:]) / 2.0


def thermocline_depth(depths, temperatures, min_gradient=MIN_GRADIENT):
    """Depth of the thermocline (m) and the maximum density gradient (kg/m3/m).

    The thermocline is where density changes fastest with depth. Its depth is
    refined between the two measurements around the maximum gradient with the
    neighbouring gradients (rLakeAnalyzer ``thermo.depth``). Returns
    (None, max_gradient) when the maximum gradient is below ``min_gradient``:
    the water column is then considered mixed.
    """
    z, t = clean_profile(depths, temperatures)
    if len(z) < 3:
        return None, 0.0
    gradient, mids = _gradient(z, t)
    i = int(np.argmax(gradient))
    max_gradient = float(gradient[i])
    if max_gradient < min_gradient:
        return None, max_gradient
    depth = float(mids[i])
    if 0 < i < len(gradient) - 1:
        up = down = None
        if gradient[i] != gradient[i - 1]:
            up = (mids[i] - mids[i - 1]) / (gradient[i] - gradient[i - 1])
        if gradient[i + 1] != gradient[i]:
            down = -(mids[i + 1] - mids[i]) / (gradient[i + 1] - gradient[i])
        if up and down and up > 0 and down > 0:
            depth = float(z[i + 1] * (down / (down + up)) + z[i] * (up / (down + up)))
    return depth, max_gradient


def metalimnion_bounds(depths, temperatures, thermocline, slope=MIN_GRADIENT):
    """Top and bottom of the metalimnion (m).

    From the thermocline, the boundaries are the depths above and below where
    the density gradient falls under ``slope`` (rLakeAnalyzer ``meta.depths``).
    The epilimnion lies above the top and the hypolimnion below the bottom.
    """
    z, t = clean_profile(depths, temperatures)
    if thermocline is None or len(z) < 3:
        return None, None
    gradient, mids = _gradient(z, t)
    i = int(np.argmin(np.abs(mids - thermocline)))

    top = float(z[0])
    for k in range(i, 0, -1):
        if gradient[k - 1] < slope <= gradient[k]:
            f = (slope - gradient[k - 1]) / (gradient[k] - gradient[k - 1])
            top = float(mids[k - 1] + f * (mids[k] - mids[k - 1]))
            break
    bottom = float(z[-1])
    for k in range(i, len(gradient) - 1):
        if gradient[k + 1] < slope <= gradient[k]:
            f = (gradient[k] - slope) / (gradient[k] - gradient[k + 1])
            bottom = float(mids[k] + f * (mids[k + 1] - mids[k]))
            break
    return min(top, thermocline), max(bottom, thermocline)


def oxygen_markers(depths, oxygen, hypoxia=HYPOXIA_MG_L):
    """Oxycline (middle of the steepest oxygen decrease, if steeper than
    ``OXYCLINE_MIN_GRADIENT``) and the shallowest
    depth where dissolved oxygen falls below ``hypoxia`` mg/L."""
    z, o = clean_profile(depths, oxygen)
    if len(z) < 2:
        return None, None
    gradient = np.diff(o) / np.diff(z)
    i = int(np.argmin(gradient))
    oxycline = float((z[i] + z[i + 1]) / 2.0) if gradient[i] <= -OXYCLINE_MIN_GRADIENT else None
    hypoxic = None
    below = np.where(o < hypoxia)[0]
    if below.size:
        k = int(below[0])
        if k == 0:
            hypoxic = float(z[0])
        else:
            f = (o[k - 1] - hypoxia) / (o[k - 1] - o[k])
            hypoxic = float(z[k - 1] + f * (z[k] - z[k - 1]))
    return oxycline, hypoxic


def area_at_depth(lake_depths, pixel_area, levels):
    """Horizontal area (m2) of the lake at each depth of ``levels``."""
    sorted_depths = np.sort(np.asarray(lake_depths, dtype="float64"))
    n = sorted_depths.size
    return (n - np.searchsorted(sorted_depths, np.asarray(levels), side="right")) * pixel_area


def schmidt_stability(depths, temperatures, lake_depths, pixel_area):
    """Schmidt stability (J/m2): the work needed to mix the whole lake to a
    uniform temperature (Idso 1973, rLakeAnalyzer ``schmidt.stability``).

    ``lake_depths`` are the depths of the wet pixels of the bathymetry; they
    give the area of the lake at every depth.
    """
    z, t = clean_profile(depths, temperatures)
    lake_depths = np.asarray(lake_depths, dtype="float64")
    if len(z) < 2 or lake_depths.size == 0:
        return None
    zmax = float(lake_depths.max())
    dz = max(zmax / 400.0, 0.02)
    levels = np.arange(0.0, zmax, dz) + dz / 2.0
    areas = area_at_depth(lake_depths, pixel_area, levels)
    if areas.sum() <= 0:
        return None
    surface = lake_depths.size * pixel_area
    rho = water_density(np.interp(levels, z, t))
    centre = float((levels * areas).sum() / areas.sum())
    return float(GRAVITY / surface * ((levels - centre) * rho * areas).sum() * dz)


def layer_volume(lake_depths, pixel_area, top, bottom=None):
    """Water volume (m3) between the depths ``top`` and ``bottom``."""
    d = np.asarray(lake_depths, dtype="float64")
    upper = d if bottom is None else np.minimum(d, bottom)
    return float(np.clip(upper - top, 0.0, None).sum() * pixel_area)


def analyse_profile(depths, temperatures, oxygen=None, lake_depths=None, pixel_area=None,
                    min_gradient=MIN_GRADIENT):
    """All the stratification indicators of one temperature profile."""
    z, t = clean_profile(depths, temperatures)
    has = len(z) > 0
    result = {
        "n_depths": int(len(z)),
        "max_depth": float(z[-1]) if has else None,
        "t_surface": float(t[0]) if has else None,
        "t_bottom": float(t[-1]) if has else None,
        "delta_t": float(t[0] - t[-1]) if has else None,
        "max_gradient": None,
        "stratified": False,
        "thermocline": None,
        "epi_bottom": None,
        "hypo_top": None,
        "oxycline": None,
        "hypoxia": None,
        "schmidt": None,
        "vol_epi": None,
        "vol_meta": None,
        "vol_hypo": None,
        "pct_hypo": None,
    }
    if len(z) >= 3:
        thermo, gradient = thermocline_depth(z, t, min_gradient)
        result["max_gradient"] = gradient
        if thermo is not None:
            top, bottom = metalimnion_bounds(z, t, thermo, min_gradient)
            result.update({"stratified": True, "thermocline": thermo, "epi_bottom": top, "hypo_top": bottom})
    if oxygen is not None:
        result["oxycline"], result["hypoxia"] = oxygen_markers(depths, oxygen)
    if lake_depths is not None and pixel_area and len(lake_depths):
        result["schmidt"] = schmidt_stability(z, t, lake_depths, pixel_area)
        if result["stratified"]:
            total = layer_volume(lake_depths, pixel_area, 0.0)
            result["vol_epi"] = layer_volume(lake_depths, pixel_area, 0.0, result["epi_bottom"])
            result["vol_meta"] = layer_volume(lake_depths, pixel_area, result["epi_bottom"], result["hypo_top"])
            result["vol_hypo"] = layer_volume(lake_depths, pixel_area, result["hypo_top"])
            result["pct_hypo"] = 100.0 * result["vol_hypo"] / total if total else None
    return result
