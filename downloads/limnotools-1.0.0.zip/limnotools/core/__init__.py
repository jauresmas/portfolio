"""LimnoTools core (formulas, geometry, styles, reports)."""
