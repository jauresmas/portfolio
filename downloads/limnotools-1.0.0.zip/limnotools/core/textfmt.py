"""Locale aware number formatting (decimal comma in French, etc.)."""

import math

COMMA_LANGUAGES = {"fr", "de", "es", "it", "pt", "nl", "pl", "ru", "cs", "da", "fi", "nb", "sv", "tr", "ro",
                   "hu", "el", "uk", "id", "vi"}
NARROW_NBSP = " "


def to_float(value):
    """Tolerant number reader for field values: ``12.5``, ``"12,5"``, ``"1 234,5"``.

    Returns None for empty, invalid or non finite values. Text values are
    common when a CSV is opened without type detection or with a decimal
    comma (French spreadsheets).
    """
    if value is None:
        return None
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        number = float(value)
    else:
        text = str(value).strip().replace(" ", "").replace(NARROW_NBSP, "").replace(" ", "")
        if not text or text.upper() in ("NULL", "NA", "N/A", "NAN", "-"):
            return None
        if "," in text and "." not in text:
            text = text.replace(",", ".")
        elif "," in text and "." in text:  # 1,234.5 or 1.234,5
            text = text.replace(",", "") if text.rfind(".") > text.rfind(",") else \
                text.replace(".", "").replace(",", ".")
        try:
            number = float(text)
        except ValueError:
            return None
    return number if math.isfinite(number) else None


def is_missing(value):
    """True for None, QGIS NULL and empty strings."""
    return value is None or str(value).strip() in ("", "NULL")


def language():
    """Two letter language of the QGIS user interface."""
    try:
        from qgis.core import QgsSettings

        locale = (QgsSettings().value("locale/userLocale", "") or "")[:2]
        if locale:
            return locale.lower()
    except ImportError:  # pragma: no cover
        pass
    try:
        from qgis.PyQt.QtCore import QLocale

        return QLocale.system().name()[:2].lower()
    except ImportError:  # pragma: no cover
        return "en"


def decimal_separator():
    return "," if language() in COMMA_LANGUAGES else "."


def number(value, decimals=0, unit=""):
    """``1234.5`` -> ``1 234,5`` (fr) or ``1 234.5`` (en); '-' for missing values."""
    if value is None:
        return "-"
    try:
        value = float(value)
    except (TypeError, ValueError):
        return str(value)
    if not math.isfinite(value):
        return "-"
    text = f"{value:,.{decimals}f}".replace(",", NARROW_NBSP)
    if decimal_separator() == ",":
        text = text.replace(".", ",")
    return f"{text} {unit}" if unit else text


def volume(value):
    if value is None:
        return "-"
    if value >= 1e9:
        return number(value / 1e9, 2, "km³")
    if value >= 1e6:
        return number(value / 1e6, 2, "hm³")
    return number(value, 0, "m³")


def area(value_m2):
    if value_m2 is None:
        return "-"
    if value_m2 >= 1e6:
        return number(value_m2 / 1e6, 2, "km²")
    return number(value_m2 / 1e4, 2, "ha")


def length(value_m):
    if value_m is None:
        return "-"
    if value_m >= 10000:
        return number(value_m / 1000, 2, "km")
    return number(value_m, 0, "m")
