"""Professional print layout of a LimnoTools study.

The layout is a regular QGIS print layout added to the project: the user can
open it in the layout designer, adjust anything and export it. Charts and
tables are vector SVG pictures embedded in the layout.
"""

import base64
import datetime
import os

from qgis.core import (
    Qgis,
    QgsFillSymbol,
    QgsLayoutExporter,
    QgsLayoutItemLabel,
    QgsLayoutItemLegend,
    QgsLayoutItemMap,
    QgsLayoutItemMapGrid,
    QgsLayoutItemPage,
    QgsLayoutItemPicture,
    QgsLayoutItemScaleBar,
    QgsLayoutItemShape,
    QgsLayoutMeasurement,
    QgsLayoutPoint,
    QgsLayoutSize,
    QgsLegendStyle,
    QgsMapLayerLegendUtils,
    QgsPathResolver,
    QgsPrintLayout,
    QgsScaleBarSettings,
    QgsSymbolLayerUtils,
    QgsTextFormat,
    QgsUnitTypes,
)
from qgis.PyQt.QtCore import QBuffer, QByteArray, QCoreApplication, QIODevice, QSize, Qt
from qgis.PyQt.QtGui import QColor, QFont

from . import sections
from .svg import class_bar_svg, hypsography_svg, profile_svg, table_svg

PLUGIN_DIR = os.path.dirname(os.path.dirname(__file__))
ACCENT_DARK = "#0b3c5d"
ACCENT = "#0f6e8c"
ACCENT_LIGHT = "#2aa7b8"
INK = "#14213d"
MUTED = "#5b6475"
PAGE_SIZES = {"A4": (297.0, 210.0), "A3": (420.0, 297.0)}


def _t(text):
    return QCoreApplication.translate("LimnoTools", text)


def _enum(path, legacy):
    obj = Qgis
    for part in path.split("."):
        obj = getattr(obj, part, None)
        if obj is None:
            return legacy
    return obj


MM = _enum("LayoutUnit.Millimeters", getattr(QgsUnitTypes, "LayoutMillimeters", None))
KILOMETERS = _enum("DistanceUnit.Kilometers", getattr(QgsUnitTypes, "DistanceKilometers", None))
METERS = _enum("DistanceUnit.Meters", getattr(QgsUnitTypes, "DistanceMeters", None))
SVG_FORMAT = _enum("PictureFormat.SVG", getattr(QgsLayoutItemPicture, "FormatSVG", None))
FIT_WIDTH = getattr(QgsScaleBarSettings, "SegmentSizeFitWidth", None)
if FIT_WIDTH is None:  # pragma: no cover
    FIT_WIDTH = _enum("ScaleBarSegmentSizeMode.FitWidth", None)


class LayoutBuilder:
    """Builds the layout page by page. All dimensions are given for an A4
    landscape sheet and scaled for larger formats."""

    def __init__(self, project, name, page="A4"):
        self.project = project
        self.width, self.height = PAGE_SIZES.get(page, PAGE_SIZES["A4"])
        self.k = self.width / PAGE_SIZES["A4"][0]
        manager = project.layoutManager()
        old = manager.layoutByName(name)
        if old is not None:
            manager.removeLayout(old)
        self.layout = QgsPrintLayout(project)
        self.layout.initializeDefaults()
        self.layout.setName(name)
        self.layout.pageCollection().page(0).setPageSize(QgsLayoutSize(self.width, self.height, MM))
        manager.addLayout(self.layout)
        self.page = 0
        self.logo = None  # organisation logo shown in every header

    # ----------------------------------------------------------- helpers
    def s(self, value):
        return value * self.k

    def _place(self, item, x, y, w, h):
        self.layout.addLayoutItem(item)
        item.attemptResize(QgsLayoutSize(self.s(w), self.s(h), MM))
        item.attemptMove(QgsLayoutPoint(self.s(x), self.s(y), MM), True, False, self.page)
        return item

    def new_page(self):
        page = QgsLayoutItemPage(self.layout)
        page.setPageSize(QgsLayoutSize(self.width, self.height, MM))
        self.layout.pageCollection().addPage(page)
        self.page = self.layout.pageCollection().pageCount() - 1

    def text_format(self, size, color=INK, bold=False):
        fmt = QgsTextFormat()
        font = QFont("Segoe UI")
        font.setBold(bold)
        fmt.setFont(font)
        fmt.setSize(size * self.k)
        fmt.setColor(QColor(color))
        return fmt

    def rect(self, x, y, w, h, color):
        shape = QgsLayoutItemShape(self.layout)
        shape.setShapeType(QgsLayoutItemShape.Rectangle)
        shape.setSymbol(QgsFillSymbol.createSimple({"color": color, "outline_style": "no"}))
        shape.setFrameEnabled(False)
        return self._place(shape, x, y, w, h)

    def label(self, text, x, y, w, h, size=9, color=INK, bold=False, align="left", valign="top"):
        item = QgsLayoutItemLabel(self.layout)
        item.setText(text)
        item.setTextFormat(self.text_format(size, color, bold))
        item.setHAlign({"left": Qt.AlignmentFlag.AlignLeft, "right": Qt.AlignmentFlag.AlignRight,
                        "center": Qt.AlignmentFlag.AlignHCenter}[align])
        item.setVAlign({"top": Qt.AlignmentFlag.AlignTop, "middle": Qt.AlignmentFlag.AlignVCenter,
                        "bottom": Qt.AlignmentFlag.AlignBottom}[valign])
        item.setMargin(0)
        return self._place(item, x, y, w, h)

    def svg(self, svg_text, x, y, w):
        """Embedded SVG picture; returns its height in A4 millimetres."""
        width = float(svg_text.split('width="', 1)[1].split('"', 1)[0])
        height = float(svg_text.split('height="', 1)[1].split('"', 1)[0])
        h = w * height / width
        picture = QgsLayoutItemPicture(self.layout)
        data = "base64:" + base64.b64encode(svg_text.encode("utf-8")).decode()
        if SVG_FORMAT is not None:
            picture.setPicturePath(data, SVG_FORMAT)
        else:  # pragma: no cover
            picture.setPicturePath(data)
        picture.setResizeMode(QgsLayoutItemPicture.Zoom)
        self._place(picture, x, y, w, h)
        return h

    def section_title(self, text, x, y, w=120):
        self.label(text.upper(), x, y, w, 5, 8.5, ACCENT, True)

    def header(self, title, subtitle=None, height=20.0):
        self.rect(0, 0, self.width / self.k, height, ACCENT_DARK)
        self.rect(0, height, self.width / self.k, 1.0, ACCENT_LIGHT)
        if self.logo:
            # organisation logo on a white card, whatever its colours and proportions
            card_w, card_h = 34.0, height - 5.0
            card = self.rect(5, 2.5, card_w, card_h, "#ffffff")
            card.setCornerRadius(QgsLayoutMeasurement(1.2 * self.k, MM))
            icon = QgsLayoutItemPicture(self.layout)  # created after the card so it is drawn above it
            icon.setPicturePath(self.logo)
            icon.setResizeMode(QgsLayoutItemPicture.Zoom)
            self._place(icon, 6.5, 3.5, card_w - 3, card_h - 2)
            x = 5 + card_w + 5
        else:
            icon = QgsLayoutItemPicture(self.layout)
            icon.setPicturePath(os.path.join(PLUGIN_DIR, "icons", "icon.svg"))
            self._place(icon, 6, (height - 13) / 2, 13, 13)
            x = 23
        if subtitle:
            self.label(title, x, 2.5, 190, 9, 17, "#ffffff", True, valign="middle")
            self.label(subtitle, x, 11.5, 190, 6, 9.5, "#d7ecf2", valign="middle")
        else:
            self.label(title, x, 0, 190, height, 15, "#ffffff", True, valign="middle")

    def footer(self, text):
        w = self.width / self.k
        h = self.height / self.k
        self.rect(8, h - 13, w - 16, 0.3, "#c9d3de")
        self.label(text, 8, h - 11.5, w - 60, 8, 6.5, MUTED)
        self.label(_t("Page [% @layout_page %] / [% @layout_numpages %]"), w - 48, h - 11.5, 40, 5, 6.5, MUTED,
                   align="right")


def _nice(value):
    import math

    if value <= 0:
        return 1.0
    exponent = math.floor(math.log10(value))
    for factor in (1, 2, 2.5, 5, 10):
        if factor * 10 ** exponent >= value:
            return factor * 10 ** exponent
    return 10 ** (exponent + 1)


def footer_text(options, crs, date):
    """Sources and credits printed at the bottom of every page."""
    parts = []
    if options.get("organisation"):
        parts.append(options["organisation"])
    if options.get("reference"):
        parts.append(_t("Ref. {}").format(options["reference"]))
    parts.append(_t("Sources: {}").format(options.get("sources") or _t("field surveys")))
    parts.append(_t("Processing: LimnoTools {} for QGIS").format(options.get("version", "")).strip())
    if crs:
        parts.append(_t("CRS: {}").format(crs))
    parts.append(_t("Date: {}").format(date))
    return "  \u00b7  ".join(parts)


def layout_name(title):
    return f"LimnoTools - {title}"


def build_study_layout(project, data, map_layers, legend_layers, extent, options):
    """Create (or replace) the print layout of the study.

    ``map_layers``: layers drawn on the map, top to bottom.
    ``legend_layers``: (layer, legend label) shown in the legend.
    ``options``: {"title", "subtitle", "organisation", "author", "logo", "reference", "sources", "page",
    "version"}. The organisation, its logo and the author replace the LimnoTools branding, which is only
    credited in the footer.
    """
    title = options.get("title") or _t("Lake study")
    name = layout_name(title)
    b = LayoutBuilder(project, name, options.get("page", "A4"))
    logo = options.get("logo")
    b.logo = logo if logo and os.path.isfile(logo) else None
    width = b.width / b.k
    height = b.height / b.k
    date = datetime.date.today().strftime("%d/%m/%Y" if _t("en") == "fr" else "%Y-%m-%d")
    source = footer_text(options, data.get("crs") or "", date)

    # ------------------------------------------------------------ page 1: map
    b.header(title, options.get("subtitle") or data.get("lake_name"))
    signature = [options.get("organisation"), options.get("author"), date]
    if options.get("reference"):
        signature.append(_t("Ref. {}").format(options["reference"]))
    b.label("\n".join(v for v in signature if v), width - 80, 2, 74, 16, 8, "#d7ecf2", align="right",
            valign="middle")

    map_x, map_y, map_w, map_h = 14, 28, 190, 162
    item_map = QgsLayoutItemMap(b.layout)
    item_map.setFrameEnabled(True)
    item_map.setFrameStrokeWidth(QgsLayoutMeasurement(0.3 * b.k, MM))
    b._place(item_map, map_x, map_y, map_w, map_h)
    if map_layers:
        item_map.setCrs(map_layers[-1].crs())
    item_map.setLayers(map_layers)
    item_map.setKeepLayerSet(True)
    item_map.zoomToExtent(extent.buffered(max(extent.width(), extent.height()) * 0.06))

    grid = QgsLayoutItemMapGrid(_t("Grid"), item_map)
    item_map.grids().addGrid(grid)
    interval = _nice(item_map.extent().width() / 4.5)
    grid.setIntervalX(interval)
    grid.setIntervalY(interval)
    grid.setStyle(QgsLayoutItemMapGrid.FrameAnnotationsOnly)
    grid.setFrameStyle(QgsLayoutItemMapGrid.Zebra)
    grid.setFrameWidth(1.4 * b.k)
    grid.setFramePenSize(0.2 * b.k)
    grid.setAnnotationEnabled(True)
    grid.setAnnotationPrecision(0)
    grid.setAnnotationTextFormat(b.text_format(6, MUTED))
    grid.setAnnotationFrameDistance(1.0 * b.k)
    for side in (QgsLayoutItemMapGrid.Left, QgsLayoutItemMapGrid.Right):
        grid.setAnnotationDirection(QgsLayoutItemMapGrid.Vertical, side)
    for side in (QgsLayoutItemMapGrid.Top, QgsLayoutItemMapGrid.Bottom):
        grid.setAnnotationDirection(QgsLayoutItemMapGrid.Horizontal, side)
    item_map.updateBoundingRect()

    north = QgsLayoutItemPicture(b.layout)
    north.setPicturePath(QgsSymbolLayerUtils.svgSymbolNameToPath("arrows/NorthArrow_11.svg", QgsPathResolver()))
    north.setLinkedMap(item_map)
    north.setBackgroundEnabled(True)
    north.setBackgroundColor(QColor(255, 255, 255, 210))
    b._place(north, map_x + map_w - 15, map_y + 3, 12, 12)

    col_x, col_w = 213, width - 213 - 8
    y = 28
    figures = sections.key_figures(data)
    if figures:
        b.section_title(_t("Key figures"), col_x, y, col_w)
        y += 6
        y += b.svg(table_svg(None, figures, [1.25, 1], ["l", "r"], width=330, row_height=21, font_size=11.5),
                   col_x, y, col_w) + 6

    b.section_title(_t("Legend"), col_x, y, col_w)
    y += 6
    legend = QgsLayoutItemLegend(b.layout)
    legend.setTitle("")
    legend.setLinkedMap(item_map)
    legend.setAutoUpdateModel(False)
    root = legend.model().rootGroup()
    root.removeAllChildren()
    for layer, label in legend_layers:
        node = root.addLayer(layer)
        node.setCustomProperty("legend/title-label", label)
        if len(legend.model().layerOriginalLegendNodes(node)) == 1:
            # single symbol: the label is drawn next to the symbol, not as a title
            QgsMapLayerLegendUtils.setLegendNodeUserLabel(node, 0, label)
            legend.model().refreshLayerLegend(node)
    legend.setColumnCount(2)
    legend.setSplitLayer(False)  # never cut a layer between the two columns
    legend.setEqualColumnWidth(True)
    legend.setColumnSpace(3 * b.k)
    legend.setSymbolHeight(3.0 * b.k)
    legend.setSymbolWidth(6 * b.k)
    legend.setBoxSpace(1.0 * b.k)
    for style_key, size, bold in ((QgsLegendStyle.Subgroup, 7.5, True), (QgsLegendStyle.SymbolLabel, 7, False)):
        style = legend.style(style_key)
        if hasattr(style, "setTextFormat"):
            style.setTextFormat(b.text_format(size, INK, bold))
        else:  # pragma: no cover
            font = QFont("Segoe UI", int(size * b.k))
            font.setBold(bold)
            style.setFont(font)
        legend.setStyle(style_key, style)
    legend.setResizeToContents(True)
    b._place(legend, col_x, y, col_w, max(20, 192 - y))
    legend.adjustBoxSize()
    legend.refresh()

    scalebar = QgsLayoutItemScaleBar(b.layout)
    scalebar.setStyle("Single Box")
    scalebar.setLinkedMap(item_map)
    scalebar.setUnits(KILOMETERS if item_map.extent().width() > 3000 else METERS)
    scalebar.setUnitLabel("km" if item_map.extent().width() > 3000 else "m")
    scalebar.setNumberOfSegments(2)
    scalebar.setNumberOfSegmentsLeft(0)
    scalebar.applyDefaultSize()
    if FIT_WIDTH is not None:
        scalebar.setSegmentSizeMode(FIT_WIDTH)
        scalebar.setMinimumBarWidth(35 * b.k)
        scalebar.setMaximumBarWidth(55 * b.k)
    scalebar.setHeight(2.0 * b.k)
    scalebar.setTextFormat(b.text_format(7, INK))
    scalebar.setBackgroundEnabled(True)
    scalebar.setBackgroundColor(QColor(255, 255, 255, 225))
    b._place(scalebar, map_x + 4, map_y + map_h - 13, 62, 10)
    scalebar.update()
    b.footer(source)

    # ------------------------------------------------- page 2: morphometry
    has_morpho = bool(data.get("morphometry") or data.get("bathymetry"))
    if has_morpho or data.get("hypsography"):
        b.new_page()
        b.header(_t("Bathymetry, morphometry and hypsometry"), height=16)
        y = 24
        if data.get("morphometry"):
            b.section_title(_t("Morphometry"), 10, y)
            y += 6
            y += b.svg(table_svg(None, sections.morphometry_rows(data), [1.4, 1], ["l", "r"], width=420,
                                 row_height=21, font_size=11.5), 10, y, 118) + 6
        if data.get("bathymetry"):
            b.section_title(_t("Bathymetry"), 10, y)
            y += 6
            b.svg(table_svg(None, sections.bathymetry_rows(data), [1.4, 1], ["l", "r"], width=420,
                            row_height=21, font_size=11.5), 10, y, 118)
        if data.get("hypsography"):
            b.section_title(_t("Hypsographic curve"), 140, 24, 140)
            h = b.svg(hypsography_svg(data["hypsography"], 620, 330), 140, 30, 147)
            headers, rows = sections.hypsography_table(data, max_rows=10)
            b.section_title(_t("Hypsographic table"), 140, 30 + h + 4, 140)
            b.svg(table_svg(headers, rows, [0.9, 1, 0.9, 1.4, 1.4, 1], width=700, row_height=21, font_size=11),
                  140, 30 + h + 10, 147)
        b.footer(source)

    # --------------------------------------------- page 3: stratification
    if data.get("stratification"):
        b.new_page()
        b.header(_t("Thermal stratification"), height=16)
        y = 24
        for profile in sections.featured_profiles(data):
            y += b.svg(profile_svg(profile, 420, 360), 10, y, 82) + 4
        headers, rows = sections.stratification_table(data)
        extra = len(rows) - 20
        rows = rows[:20]
        b.section_title(_t("Profiles"), 100, 24, 180)
        h = b.svg(table_svg(headers, rows, [1.6, 1.25, 1, 1, 1.05, 1, 1, 1, 1.1], width=980, row_height=21,
                            font_size=11), 100, 30, width - 108)
        if extra > 0:
            b.label(_t("{} more profiles in the Stratification table.").format(extra), 100, 32 + h,
                    120, 5, 7, MUTED)
        b.footer(source)

    # --------------------------------------------- page 4: water quality, fetch
    if data.get("trophic") or data.get("fetch"):
        b.new_page()
        both = bool(data.get("trophic") and data.get("fetch"))
        if both:
            b.header(_t("Water quality and wind exposure"), height=16)
        else:
            b.header(_t("Water quality") if data.get("trophic") else _t("Wind exposure"), height=16)
        fetch_x = 152 if both else 10
        if data.get("trophic"):
            b.section_title(_t("Trophic state (Carlson)"), 10, 24, 130)
            labels = {k: sections.class_label(k) for k in sections.CLASS_LABELS}
            h = b.svg(class_bar_svg(sections.trophic_counts(data), labels, 620, 52), 10, 30, 135)
            headers, rows, colors = sections.trophic_table(data)
            b.svg(table_svg(headers, rows[:24], [1.7, 0.9, 1, 0.9, 0.7, 1.3], width=640, row_height=21,
                            font_size=11, colors=colors[:24]), 10, 30 + h + 4, 135)
        if data.get("fetch"):
            wind = data["fetch"].get("wind")
            b.section_title(_t("Wind fetch"), fetch_x, 24, 130)
            if wind is not None:
                b.label(_t("Dominant wind from {} degrees.").format(f"{wind:.0f}"), fetch_x, 30, 135, 5, 8, MUTED)
            headers, rows = sections.fetch_table(data)
            b.svg(table_svg(headers, rows[:24], [1.7, 1.1, 0.8, 1.1, 1.1], width=640, row_height=21,
                            font_size=11), fetch_x, 37, 135)
        b.footer(source)

    # ------------------------------------------------ page 5: methods
    b.new_page()
    b.header(_t("Methods and references"), height=16)
    b.section_title(_t("Methods"), 10, 24, 130)
    b.label("\n\n".join(sections.methods(data)), 10, 31, 132, height - 50, 8.5, INK)
    b.section_title(_t("References"), 152, 24, 130)
    b.label("\n\n".join(sections.REFERENCES), 152, 31, 135, height - 50, 7.5, MUTED)
    b.footer(source)

    b.layout.refresh()
    return b.layout


def export_pdf(layout, path):
    exporter = QgsLayoutExporter(layout)
    settings = QgsLayoutExporter.PdfExportSettings()
    settings.dpi = 300
    settings.rasterizeWholeImage = False
    settings.forceVectorOutput = True
    settings.appendGeoreference = True
    settings.exportMetadata = True
    result = exporter.exportToPdf(path, settings)
    return result == QgsLayoutExporter.Success


def map_page_png(layout, width_px=1600):
    """First page of the layout as PNG bytes (for the HTML report)."""
    exporter = QgsLayoutExporter(layout)
    page = layout.pageCollection().page(0)
    ratio = page.pageSize().height() / page.pageSize().width()
    image = exporter.renderPageToImage(0, QSize(width_px, int(width_px * ratio)))
    data = QByteArray()
    buffer = QBuffer(data)
    buffer.open(QIODevice.OpenModeFlag.WriteOnly)
    image.save(buffer, "PNG")
    buffer.close()
    return bytes(data)
