"""Ready to use cartographic styles for LimnoTools outputs."""

from qgis.core import (
    Qgis,
    QgsCategorizedSymbolRenderer,
    QgsColorRampShader,
    QgsFillSymbol,
    QgsGraduatedSymbolRenderer,
    QgsLineSymbol,
    QgsMarkerSymbol,
    QgsPalLayerSettings,
    QgsProcessingLayerPostProcessorInterface,
    QgsRasterBandStats,
    QgsRasterShader,
    QgsRendererCategory,
    QgsRendererRange,
    QgsSingleBandPseudoColorRenderer,
    QgsTextBufferSettings,
    QgsTextFormat,
    QgsVectorLayerSimpleLabeling,
)
from qgis.PyQt.QtCore import QCoreApplication
from qgis.PyQt.QtGui import QColor

from .textfmt import number

# Water palette, from shallow to deep (bathymetry only: depth is water).
DEPTH_COLORS = ["#e0f3f8", "#abd9e9", "#74add1", "#4575b4", "#313695", "#1b1f5e"]

TROPHIC_STYLE = {
    "oligotrophic": ("#2c7bb6", "Oligotrophic (TSI < 40)"),
    "mesotrophic": ("#7fbf7b", "Mesotrophic (40-50)"),
    "eutrophic": ("#d9a21b", "Eutrophic (50-70)"),
    "hypereutrophic": ("#8c510a", "Hypereutrophic (> 70)"),
}

_KEEP_ALIVE = []


def _n(value):
    """Class bound without useless decimals: 1, 0,5, 2,25."""
    decimals = 0 if abs(value - round(value)) < 1e-9 else (1 if abs(value * 10 - round(value * 10)) < 1e-6 else 2)
    return number(value, decimals)


def _tr(text):
    return QCoreApplication.translate("LimnoTools", text)


if hasattr(Qgis, "ShaderInterpolationMethod"):
    _INTERPOLATED = Qgis.ShaderInterpolationMethod.Linear
else:  # pragma: no cover  QGIS < 3.30
    _INTERPOLATED = QgsColorRampShader.Interpolated

if hasattr(Qgis, "RasterBandStatistic"):
    _STATS_MINMAX = Qgis.RasterBandStatistic.Min | Qgis.RasterBandStatistic.Max
else:  # pragma: no cover
    _STATS_MINMAX = QgsRasterBandStats.Min | QgsRasterBandStats.Max


def _interpolate(colors, n):
    """``n`` colours evenly interpolated along a list of hex colours."""
    if n <= 1:
        return [QColor(colors[0])]
    qcolors = [QColor(c) for c in colors]
    out = []
    for i in range(n):
        t = i / (n - 1) * (len(qcolors) - 1)
        k = min(int(t), len(qcolors) - 2)
        f = t - k
        a, b = qcolors[k], qcolors[k + 1]
        out.append(QColor(
            round(a.red() + (b.red() - a.red()) * f),
            round(a.green() + (b.green() - a.green()) * f),
            round(a.blue() + (b.blue() - a.blue()) * f),
        ))
    return out


def style_bathymetry(layer):
    provider = layer.dataProvider()
    stats = provider.bandStatistics(1, _STATS_MINMAX)
    vmin, vmax = max(0.0, stats.minimumValue), max(stats.maximumValue, 0.1)
    colors = _interpolate(DEPTH_COLORS, 6)
    items = []
    for i, color in enumerate(colors):
        value = vmin + (vmax - vmin) * i / (len(colors) - 1)
        items.append(QgsColorRampShader.ColorRampItem(value, color, number(value, 1, "m")))
    ramp = QgsColorRampShader(vmin, vmax)
    ramp.setColorRampType(_INTERPOLATED)
    ramp.setColorRampItemList(items)
    shader = QgsRasterShader()
    shader.setRasterShaderFunction(ramp)
    renderer = QgsSingleBandPseudoColorRenderer(provider, 1, shader)
    renderer.setClassificationMin(vmin)
    renderer.setClassificationMax(vmax)
    layer.setRenderer(renderer)
    layer.triggerRepaint()


def _text_format(size=8, color="#1b1f5e"):
    fmt = QgsTextFormat()
    fmt.setSize(size)
    fmt.setColor(QColor(color))
    buffer = QgsTextBufferSettings()
    buffer.setEnabled(True)
    buffer.setSize(0.8)
    buffer.setColor(QColor("#ffffff"))
    fmt.setBuffer(buffer)
    return fmt


def style_isobaths(layer, field="depth"):
    symbol = QgsLineSymbol.createSimple({"color": "#1f4e8c", "width": "0.3"})
    layer.setRenderer(_single(symbol))
    settings = QgsPalLayerSettings()
    settings.fieldName = f"format_number(\"{field}\", 1) || ' m'"
    settings.isExpression = True
    settings.placement = Qgis.LabelPlacement.Curved if hasattr(Qgis, "LabelPlacement") else QgsPalLayerSettings.Curved
    settings.setFormat(_text_format())
    layer.setLabeling(QgsVectorLayerSimpleLabeling(settings))
    layer.setLabelsEnabled(True)
    layer.triggerRepaint()


def _single(symbol):
    from qgis.core import QgsSingleSymbolRenderer

    return QgsSingleSymbolRenderer(symbol)


def style_depth_zones(layer, field="depth_min"):
    index = layer.fields().indexOf(field)
    if index < 0:
        return
    values = sorted({f[field] for f in layer.getFeatures() if f[field] is not None})
    if not values:
        return
    step = values[1] - values[0] if len(values) > 1 else 1.0
    colors = _interpolate(DEPTH_COLORS, len(values))
    ranges = []
    for value, color in zip(values, colors):
        symbol = QgsFillSymbol.createSimple({"color": color.name(), "outline_style": "no"})
        ranges.append(QgsRendererRange(value - 1e-6, value + step - 1e-6, symbol,
                                       f"{_n(value)} - {_n(value + step)} m"))
    layer.setRenderer(QgsGraduatedSymbolRenderer(field, ranges))
    layer.setOpacity(0.85)
    layer.triggerRepaint()


def style_trophic(layer, field="TROPHIC"):
    categories = []
    for key, (color, label) in TROPHIC_STYLE.items():
        symbol = QgsMarkerSymbol.createSimple(
            {"name": "circle", "color": color, "size": "4", "outline_color": "#ffffff", "outline_width": "0.4"}
        )
        categories.append(QgsRendererCategory(key, symbol, _tr(label)))
    layer.setRenderer(QgsCategorizedSymbolRenderer(field, categories))
    settings = QgsPalLayerSettings()
    settings.fieldName = "format_number(\"TSI_MEAN\", 0)"
    settings.isExpression = True
    settings.setFormat(_text_format(8, "#222222"))
    layer.setLabeling(QgsVectorLayerSimpleLabeling(settings))
    layer.setLabelsEnabled(True)
    layer.triggerRepaint()


def style_fetch_points(layer, field="FETCH_EFF"):
    values = [f[field] for f in layer.getFeatures() if f[field] is not None]
    if not values:
        return
    vmax = max(values) or 1.0
    colors = ["#ffffb2", "#fecc5c", "#fd8d3c", "#f03b20", "#bd0026"]
    ranges = []
    for i, color in enumerate(colors):
        low, high = vmax * i / len(colors), vmax * (i + 1) / len(colors)
        symbol = QgsMarkerSymbol.createSimple({
            "name": "circle", "color": color, "size": str(2.5 + i * 0.8),
            "outline_color": "#4d4d4d", "outline_width": "0.2"})
        ranges.append(QgsRendererRange(low - (1e-6 if i == 0 else 0), high + 1e-6, symbol,
                                       f"{number(low)} - {number(high)} m"))
    layer.setRenderer(QgsGraduatedSymbolRenderer(field, ranges))
    layer.triggerRepaint()


def style_fetch_rays(layer):
    layer.setRenderer(_single(QgsLineSymbol.createSimple({"color": "#7f7f7f", "width": "0.15"})))
    layer.setOpacity(0.6)
    layer.triggerRepaint()


def style_morphometry_lines(layer, field="TYPE"):
    categories = [
        QgsRendererCategory("max_length", QgsLineSymbol.createSimple(
            {"color": "#c0392b", "width": "0.7"}), _tr("Maximum length")),
        QgsRendererCategory("max_width", QgsLineSymbol.createSimple(
            {"color": "#e67e22", "width": "0.7", "line_style": "dash"}), _tr("Maximum width")),
    ]
    layer.setRenderer(QgsCategorizedSymbolRenderer(field, categories))
    layer.triggerRepaint()


STYLE_FUNCTIONS = {
    "bathymetry": style_bathymetry,
    "isobaths": style_isobaths,
    "depth_zones": style_depth_zones,
    "trophic": style_trophic,
    "fetch_points": style_fetch_points,
    "fetch_rays": style_fetch_rays,
    "morphometry_lines": style_morphometry_lines,
}


class StylePostProcessor(QgsProcessingLayerPostProcessorInterface):
    """Applies a LimnoTools style when Processing loads an output layer."""

    def __init__(self, style_key):
        super().__init__()
        self.style_key = style_key

    def postProcessLayer(self, layer, context, feedback):  # noqa: N802  (Qt API)
        try:
            STYLE_FUNCTIONS[self.style_key](layer)
        except Exception as err:  # styling must never break an analysis
            feedback.reportError(f"Style not applied: {err}")

    @staticmethod
    def create(style_key):
        processor = StylePostProcessor(style_key)
        _KEEP_ALIVE.append(processor)
        return processor


def attach_style(context, output_id, style_key):
    """Register a style post processor for a Processing output."""
    if context.willLoadLayerOnCompletion(output_id):
        details = context.layerToLoadOnCompletionDetails(output_id)
        details.setPostProcessor(StylePostProcessor.create(style_key))
