"""Vector charts and tables as SVG strings.

The same SVG is embedded in the HTML report and placed as pictures in the QGIS
print layout, so it only uses the SVG Tiny features understood by Qt
(no CSS classes, explicit width and height, plain attributes).
"""

import html

from qgis.PyQt.QtCore import QCoreApplication

from .textfmt import number

FONT = "Segoe UI"
INK = "#14213d"
MUTED = "#5b6475"
LINE = "#dfe5ee"
GRID = "#e8edf2"
ACCENT = "#0f6e8c"
ACCENT_DARK = "#0b3c5d"
WARM = "#e07a1f"
RED = "#d1453b"
LAYER_COLORS = ("#f4a259", "#9b8fd6", "#3d7ea6")
TROPHIC_COLORS = {
    "oligotrophic": "#2c7bb6",
    "mesotrophic": "#7fbf7b",
    "eutrophic": "#d9a21b",
    "hypereutrophic": "#8c510a",
}


def _t(text):
    return QCoreApplication.translate("LimnoTools", text)


def _e(text):
    return html.escape(str(text), quote=True)


def _open(width, height, label=""):
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" '
            f'viewBox="0 0 {width} {height}" font-family="{FONT}" role="img" aria-label="{_e(label)}">')


def _text(x, y, text, size=11, fill=INK, anchor="start", weight="normal", extra=""):
    return (f'<text x="{x:.1f}" y="{y:.1f}" font-size="{size}" fill="{fill}" text-anchor="{anchor}" '
            f'font-weight="{weight}"{extra}>{_e(text)}</text>')


# ---------------------------------------------------------------- tables
def table_svg(headers, rows, widths, aligns=None, width=None, row_height=22, font_size=11, colors=None):
    """Table with a coloured header and zebra rows.

    ``widths`` are relative column widths, ``aligns`` 'l' or 'r' per column,
    ``colors`` an optional list of swatch colours drawn before the first cell.
    """
    width = width or 640
    total = float(sum(widths))
    xs, x = [], 0.0
    for w in widths:
        xs.append(x)
        x += width * w / total
    aligns = aligns or ["l"] + ["r"] * (len(widths) - 1)
    has_header = bool(headers)
    height = row_height * (len(rows) + (1 if has_header else 0)) + 2
    parts = [_open(width, height, "table")]
    y = 0
    if has_header:
        parts.append(f'<rect x="0" y="0" width="{width}" height="{row_height}" fill="{ACCENT_DARK}"/>')
        for i, head in enumerate(headers):
            cw = width * widths[i] / total
            tx = xs[i] + 8 if aligns[i] == "l" else xs[i] + cw - 8
            parts.append(_text(tx, row_height * 0.68, head, font_size - 0.5, "#ffffff",
                               "start" if aligns[i] == "l" else "end", "bold"))
        y = row_height
    for r, row in enumerate(rows):
        if r % 2 == 1:
            parts.append(f'<rect x="0" y="{y}" width="{width}" height="{row_height}" fill="#f4f7fa"/>')
        for i, cell in enumerate(row):
            cw = width * widths[i] / total
            offset = 0
            if i == 0 and colors and colors[r]:
                parts.append(f'<rect x="{xs[0] + 8}" y="{y + row_height / 2 - 5}" width="10" height="10" rx="2" '
                             f'fill="{colors[r]}"/>')
                offset = 16
            tx = xs[i] + 8 + offset if aligns[i] == "l" else xs[i] + cw - 8
            weight = "bold" if i == 0 and not has_header else "normal"
            parts.append(_text(tx, y + row_height * 0.68, cell, font_size, INK if i else INK,
                               "start" if aligns[i] == "l" else "end", weight))
        y += row_height
        parts.append(f'<line x1="0" y1="{y}" x2="{width}" y2="{y}" stroke="{LINE}" stroke-width="1"/>')
    parts.append("</svg>")
    return "".join(parts)


# ---------------------------------------------------------------- charts
def hypsography_svg(rows, width=620, height=340):
    """Hypsographic curve: area % and cumulative volume % against depth."""
    if not rows:
        return ""
    zmax = max(r["depth"] for r in rows) or 1.0
    left, right, top, bottom = 58, 20, 18, 44
    pw, ph = width - left - right, height - top - bottom

    def x(pct):
        return left + pw * pct / 100.0

    def y(depth):
        return top + ph * depth / zmax

    parts = [_open(width, height, _t("Hypsographic curve")),
             f'<rect x="0" y="0" width="{width}" height="{height}" fill="#ffffff"/>']
    for pct in range(0, 101, 20):
        parts.append(f'<line x1="{x(pct):.1f}" y1="{top}" x2="{x(pct):.1f}" y2="{top + ph}" stroke="{GRID}"/>')
        parts.append(_text(x(pct), top + ph + 16, f"{pct} %", 11, MUTED, "middle"))
    for i in range(6):
        depth = zmax * i / 5
        parts.append(f'<line x1="{left}" y1="{y(depth):.1f}" x2="{left + pw}" y2="{y(depth):.1f}" stroke="{GRID}"/>')
        parts.append(_text(left - 8, y(depth) + 4, number(depth, 1), 11, MUTED, "end"))
    parts.append(_text(14, top + ph / 2, _t("Depth (m)"), 11, MUTED, "middle",
                       extra=f' transform="rotate(-90 14 {top + ph / 2:.1f})"'))
    area_pts = " ".join(f"{x(r['area_pct']):.1f},{y(r['depth']):.1f}" for r in rows)
    vol_pts = " ".join(f"{x(r['volume_above_pct']):.1f},{y(r['depth']):.1f}" for r in rows)
    parts.append(f'<polygon points="{x(0):.1f},{y(0):.1f} {area_pts} {x(0):.1f},{y(zmax):.1f}" '
                 f'fill="{ACCENT}" fill-opacity="0.12"/>')
    parts.append(f'<polyline points="{area_pts}" fill="none" stroke="{ACCENT}" stroke-width="2.2"/>')
    parts.append(f'<polyline points="{vol_pts}" fill="none" stroke="{WARM}" stroke-width="2.2" '
                 'stroke-dasharray="6 4"/>')
    lx, ly = left + pw - 200, top + ph - 54
    parts.append(f'<rect x="{lx}" y="{ly}" width="192" height="46" rx="6" fill="#ffffff" stroke="{LINE}"/>')
    parts.append(f'<line x1="{lx + 10}" y1="{ly + 16}" x2="{lx + 34}" y2="{ly + 16}" stroke="{ACCENT}" '
                 'stroke-width="2.2"/>')
    parts.append(_text(lx + 40, ly + 20, _t("Area at depth") + " (%)", 11))
    parts.append(f'<line x1="{lx + 10}" y1="{ly + 34}" x2="{lx + 34}" y2="{ly + 34}" stroke="{WARM}" '
                 'stroke-width="2.2" stroke-dasharray="6 4"/>')
    parts.append(_text(lx + 40, ly + 38, _t("Cumulative volume") + " (%)", 11))
    parts.append("</svg>")
    return "".join(parts)


def profile_svg(profile, width=420, height=380):
    """Vertical profile with temperature, oxygen and the three layers."""
    data = profile["profile"]
    depths = data["depth"]
    temps = data["temp"]
    oxygen = data.get("oxygen")
    if not depths:
        return ""
    zmax = max(max(depths), 0.5)
    tmin, tmax = min(temps), max(temps)
    if tmax - tmin < 1.0:
        mid = (tmax + tmin) / 2
        tmin, tmax = mid - 0.5, mid + 0.5
    valid_o = [o for o in (oxygen or []) if o is not None and o == o]
    omax = max(1.0, max(valid_o)) if valid_o else 1.0
    left, right, top, bottom = 48, 14, 40, 56
    pw, ph = width - left - right, height - top - bottom

    def y(z):
        return top + ph * z / zmax

    def xt(v):
        return left + pw * (v - tmin) / (tmax - tmin)

    def xo(v):
        return left + pw * v / omax

    title = " | ".join(v for v in (profile.get("station"), profile.get("date")) if v)
    parts = [_open(width, height, title), f'<rect x="0" y="0" width="{width}" height="{height}" fill="#ffffff"/>']
    parts.append(_text(left, 14, title, 12, INK, "start", "bold"))
    if profile.get("stratified"):
        bounds = (0.0, profile.get("epi_bottom") or 0.0, profile.get("hypo_top") or zmax, zmax)
        names = (_t("Epilimnion"), _t("Metalimnion"), _t("Hypolimnion"))
        for k, color in enumerate(LAYER_COLORS):
            a, b = min(bounds[k], zmax), min(bounds[k + 1], zmax)
            if b > a:
                parts.append(f'<rect x="{left}" y="{y(a):.1f}" width="{pw}" height="{y(b) - y(a):.1f}" '
                             f'fill="{color}" fill-opacity="0.18"/>')
                if k < 2:  # warm, oxygenated layers: curves are on the right
                    parts.append(_text(left + 6, y(a) + 13, names[k], 10, color, "start", "bold"))
                else:
                    parts.append(_text(left + pw - 6, y(a) + 13, names[k], 10, color, "end", "bold"))
    for i in range(6):
        z = zmax * i / 5
        parts.append(f'<line x1="{left}" y1="{y(z):.1f}" x2="{left + pw}" y2="{y(z):.1f}" stroke="{GRID}"/>')
        parts.append(_text(left - 6, y(z) + 4, number(z, 1), 10, MUTED, "end"))
    for i in range(5):
        xx = left + pw * i / 4
        parts.append(f'<line x1="{xx:.1f}" y1="{top}" x2="{xx:.1f}" y2="{top + ph}" stroke="{GRID}"/>')
        parts.append(_text(xx, top + ph + 14, number(tmin + (tmax - tmin) * i / 4, 1), 10, RED, "middle"))
        if valid_o:
            parts.append(_text(xx, top - 6, number(omax * i / 4, 1), 10, ACCENT, "middle"))
    parts.append(_text(12, top + ph / 2, _t("Depth (m)"), 10, MUTED, "middle",
                       extra=f' transform="rotate(-90 12 {top + ph / 2:.1f})"'))
    thermo = profile.get("thermocline")
    if thermo is not None:
        parts.append(f'<line x1="{left}" y1="{y(thermo):.1f}" x2="{left + pw}" y2="{y(thermo):.1f}" '
                     f'stroke="{INK}" stroke-width="1.2" stroke-dasharray="5 4"/>')
        parts.append(_text(left + 6, y(thermo) + 12, f"{_t('Thermocline')} {number(thermo, 1, 'm')}", 10))
    if valid_o:
        pts = " ".join(f"{xo(o):.1f},{y(z):.1f}" for z, o in zip(depths, oxygen) if o is not None and o == o)
        parts.append(f'<polyline points="{pts}" fill="none" stroke="{ACCENT}" stroke-width="2" '
                     'stroke-dasharray="6 4"/>')
    pts = " ".join(f"{xt(t):.1f},{y(z):.1f}" for z, t in zip(depths, temps))
    parts.append(f'<polyline points="{pts}" fill="none" stroke="{RED}" stroke-width="2.2"/>')
    ly = height - 14
    parts.append(f'<line x1="{left}" y1="{ly - 4}" x2="{left + 20}" y2="{ly - 4}" stroke="{RED}" stroke-width="2.2"/>')
    parts.append(_text(left + 26, ly, _t("Temperature (°C)"), 10, MUTED))
    if valid_o:
        x2 = left + pw / 2 + 10
        parts.append(f'<line x1="{x2}" y1="{ly - 4}" x2="{x2 + 20}" y2="{ly - 4}" stroke="{ACCENT}" '
                     'stroke-width="2" stroke-dasharray="6 4"/>')
        parts.append(_text(x2 + 26, ly, _t("Oxygen (mg/L)"), 10, MUTED))
    parts.append("</svg>")
    return "".join(parts)


def class_bar_svg(counts, labels, width=620, height=60):
    """Stacked bar of the number of stations per trophic class."""
    total = sum(counts.get(k, 0) for k in TROPHIC_COLORS)
    parts = [_open(width, height, _t("Trophic state"))]
    if not total:
        parts.append("</svg>")
        return "".join(parts)
    x = 0.0
    for key, color in TROPHIC_COLORS.items():
        n = counts.get(key, 0)
        if not n:
            continue
        w = width * n / total
        parts.append(f'<rect x="{x:.1f}" y="0" width="{w:.1f}" height="20" fill="{color}"/>')
        if w > 24:
            parts.append(_text(x + w / 2, 14, str(n), 11, "#ffffff", "middle", "bold"))
        x += w
    col = width / 4
    for i, (key, color) in enumerate(TROPHIC_COLORS.items()):
        cx = i * col
        parts.append(f'<rect x="{cx:.1f}" y="34" width="10" height="10" rx="2" fill="{color}"/>')
        parts.append(_text(cx + 15, 43, f"{labels.get(key, key)} ({counts.get(key, 0)})", 10, INK))
    parts.append("</svg>")
    return "".join(parts)
