"""Hypsographic curve and water-level drawdown table."""

import json

from osgeo import gdal
from qgis.core import (
    QgsCoordinateTransform,
    QgsFeature,
    QgsFields,
    QgsGeometry,
    QgsProcessingException,
    QgsProcessingOutputString,
    QgsProcessingParameterFeatureSink,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterFileDestination,
    QgsProcessingParameterNumber,
    QgsProcessingParameterRasterLayer,
    QgsRectangle,
)

from ..compat import FAST_INSERT, NUMBER_DOUBLE, SOURCE_NO_GEOMETRY, SOURCE_POLYGON, WKB_NOGEOMETRY, double_field
from ..core import limnology
from ..core.geometry import read_depths_in_polygon
from ..core.report import build_report
from .bathymetry import dissolve
from .base import LimnoAlgorithm, check_projected, plugin_version
from .morphometry import _auto_step

TABLE_FIELDS = (
    ("DEPTH_M", "depth"),
    ("AREA_M2", "area"),
    ("AREA_PCT", "area_pct"),
    ("VOL_ABOVE", "volume_above"),
    ("VOL_BELOW", "volume_below"),
    ("VOL_PCT", "volume_above_pct"),
)


class HypsometryAlgorithm(LimnoAlgorithm):
    INPUT = "INPUT"
    LAKE = "LAKE"
    STEP = "STEP"
    OUTPUT = "OUTPUT"
    OUTPUT_HTML = "OUTPUT_HTML"

    GROUP_ID = "morphometry"
    GROUP_NAME = "Morphometry"
    ICON = "hypsometry"

    def name(self):
        return "hypsometry"

    def displayName(self):  # noqa: N802
        return self.tr("Hypsographic curve")

    def shortHelpString(self):  # noqa: N802
        return self.tr(
            "Computes the hypsographic table of a lake from its bathymetry raster: for every depth "
            "level, the area of the horizontal section, the water volume above and below that level "
            "and the cumulative percentages.\n\n"
            "The <i>volume below</i> column answers drawdown questions: it is the volume left in the "
            "lake if the water level drops by the depth of the row, and <i>area</i> is the remaining "
            "water surface.\n\n"
            "An optional lake outline restricts the computation to the pixels inside it. "
            "Depth step 0 picks an automatic step (20 to 50 levels)."
        )

    def initAlgorithm(self, config=None):  # noqa: N802
        self.addParameter(QgsProcessingParameterRasterLayer(self.INPUT, self.tr("Bathymetry raster (depth in m)")))
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.LAKE, self.tr("Lake outline (optional mask)"), [SOURCE_POLYGON], optional=True))
        self.addParameter(QgsProcessingParameterNumber(
            self.STEP, self.tr("Depth step (m, 0 = automatic)"), type=NUMBER_DOUBLE, minValue=0.0, defaultValue=0.0))
        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT, self.tr("Hypsographic table"), type=SOURCE_NO_GEOMETRY))
        self.addParameter(QgsProcessingParameterFileDestination(
            self.OUTPUT_HTML, self.tr("HTML report"), self.tr("HTML files (*.html)"),
            optional=True, createByDefault=False))
        self.addOutput(QgsProcessingOutputString("TABLE", self.tr("Table (JSON)")))

    def processAlgorithm(self, parameters, context, feedback):  # noqa: N802
        raster = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        if raster is None:
            raise QgsProcessingException(self.tr("Invalid raster layer."))
        check_projected(raster.crs(), self.tr("The bathymetry raster"), self.tr)
        lake = self.parameterAsSource(parameters, self.LAKE, context)
        step = self.parameterAsDouble(parameters, self.STEP, context)
        html_path = self.parameterAsFileOutput(parameters, self.OUTPUT_HTML, context)

        if lake is not None:
            transform = None
            if lake.sourceCrs() != raster.crs():
                transform = QgsCoordinateTransform(lake.sourceCrs(), raster.crs(), context.transformContext())
            mask_geom = dissolve(lake, transform, feedback)
            if mask_geom.isEmpty():
                raise QgsProcessingException(self.tr("The lake outline layer has no valid polygon."))
        else:
            dataset = gdal.Open(raster.source())
            gt = dataset.GetGeoTransform()
            extent = QgsRectangle(gt[0], gt[3] + gt[5] * dataset.RasterYSize,
                                  gt[0] + gt[1] * dataset.RasterXSize, gt[3])
            mask_geom = QgsGeometry.fromRect(extent)
            dataset = None

        feedback.pushInfo(self.tr("Reading depths..."))
        depths, pixel_area = read_depths_in_polygon(raster.source(), mask_geom.asWkt())
        if not len(depths):
            raise QgsProcessingException(self.tr("No valid depth value found."))
        if step <= 0:
            step = _auto_step(float(depths.max()))
        feedback.pushInfo(self.tr("Depth step: {} m").format(step))
        rows = limnology.hypsometry(depths, pixel_area, step)
        feedback.setProgress(60)

        fields = QgsFields()
        for name, _key in TABLE_FIELDS:
            fields.append(double_field(name, 20, 3))
        sink, dest_id = self.parameterAsSink(parameters, self.OUTPUT, context, fields, WKB_NOGEOMETRY, raster.crs())
        if sink is None:
            raise QgsProcessingException(self.invalidSinkError(parameters, self.OUTPUT))
        for row in rows:
            feature = QgsFeature(fields)
            feature.setAttributes([row[key] for _name, key in TABLE_FIELDS])
            sink.addFeature(feature, FAST_INSERT)

        results = {self.OUTPUT: dest_id, "TABLE": json.dumps(rows)}
        if html_path:
            stats = limnology.depth_statistics(depths, pixel_area)
            metrics = {
                "AREA_HA": stats["wet_area"] / 1e4,
                "VOLUME_M3": stats["volume"],
                "ZMAX_M": stats["max_depth"],
                "ZMEAN_M": stats["mean_depth"],
            }
            with open(html_path, "w", encoding="utf-8") as handle:
                handle.write(build_report(self.tr("Hypsographic report"),
                                          [{"name": raster.name(), "metrics": metrics, "hypsography": rows}],
                                          plugin_version(), raster.crs().authid()))
            results[self.OUTPUT_HTML] = html_path
        feedback.setProgress(100)
        return results
