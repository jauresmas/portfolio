"""Wind fetch and effective fetch at sampling sites."""

import math

from qgis.core import (
    QgsCoordinateTransform,
    QgsFeature,
    QgsFields,
    QgsGeometry,
    QgsPointXY,
    QgsProcessingException,
    QgsProcessingParameterFeatureSink,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterNumber,
)

from ..compat import (
    FAST_INSERT,
    NUMBER_DOUBLE,
    NUMBER_INTEGER,
    SOURCE_LINE,
    SOURCE_POINT,
    SOURCE_POLYGON,
    WKB_LINESTRING,
    WKB_POINT,
    double_field,
    int_field,
)
from ..core.geometry import fetch_rays
from ..core.limnology import effective_fetch
from ..core.styles import attach_style
from .base import LimnoAlgorithm, check_projected
from .bathymetry import dissolve

RESULT_FIELDS = ("FETCH_MAX", "DIR_MAX", "FETCH_MEAN", "FETCH_WIND", "FETCH_EFF")


class FetchAlgorithm(LimnoAlgorithm):
    LAKE = "LAKE"
    POINTS = "POINTS"
    STEP = "STEP"
    WIND = "WIND"
    OUTPUT = "OUTPUT"
    OUTPUT_RAYS = "OUTPUT_RAYS"

    GROUP_ID = "hydrodynamics"
    GROUP_NAME = "Hydrodynamics"
    ICON = "fetch"

    def name(self):
        return "fetch"

    def displayName(self):  # noqa: N802
        return self.tr("Wind fetch")

    def shortHelpString(self):  # noqa: N802
        return self.tr(
            "Fetch is the open-water distance over which the wind blows before reaching a point. "
            "It controls wave height, shore erosion and sediment resuspension.\n\n"
            "For each site, rays are cast every <i>step</i> degrees until they reach the shore "
            "(islands included). Outputs per site:\n"
            "FETCH_MAX / DIR_MAX: longest fetch and its azimuth;\n"
            "FETCH_MEAN: mean fetch over all directions (exposure index);\n"
            "FETCH_WIND: fetch towards the dominant wind direction;\n"
            "FETCH_EFF: effective fetch for that wind (Shore Protection Manual 1984), weighting "
            "radials every 3&deg; within &plusmn;45&deg; by cos&sup2;.\n\n"
            "The wind direction is the direction the wind blows <b>from</b> (meteorological "
            "convention, degrees clockwise from north)."
        )

    def initAlgorithm(self, config=None):  # noqa: N802
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.LAKE, self.tr("Lake outline (polygons)"), [SOURCE_POLYGON]))
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.POINTS, self.tr("Sites (points on the water)"), [SOURCE_POINT]))
        self.addParameter(QgsProcessingParameterNumber(
            self.STEP, self.tr("Angular step (degrees)"), type=NUMBER_INTEGER,
            minValue=1, maxValue=90, defaultValue=10))
        self.addParameter(QgsProcessingParameterNumber(
            self.WIND, self.tr("Dominant wind direction (degrees, from)"), type=NUMBER_DOUBLE,
            minValue=0.0, maxValue=360.0, defaultValue=225.0))
        self.addParameter(QgsProcessingParameterFeatureSink(self.OUTPUT, self.tr("Fetch at sites"), type=SOURCE_POINT))
        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT_RAYS, self.tr("Fetch rays"), type=SOURCE_LINE, optional=True, createByDefault=False))

    def processAlgorithm(self, parameters, context, feedback):  # noqa: N802
        lake = self.parameterAsSource(parameters, self.LAKE, context)
        points = self.parameterAsSource(parameters, self.POINTS, context)
        if lake is None or points is None:
            raise QgsProcessingException(self.tr("Invalid input layers."))
        crs = lake.sourceCrs()
        check_projected(crs, self.tr("The lake outline"), self.tr)
        step = self.parameterAsInt(parameters, self.STEP, context)
        wind = self.parameterAsDouble(parameters, self.WIND, context) % 360.0

        lake_geom = dissolve(lake, feedback=feedback)
        if lake_geom.isEmpty():
            raise QgsProcessingException(self.tr("The lake outline layer has no valid polygon."))
        bbox = lake_geom.boundingBox()
        reach = math.hypot(bbox.width(), bbox.height()) * 1.05
        engine_geom = lake_geom

        transform = None
        if points.sourceCrs() != crs:
            transform = QgsCoordinateTransform(points.sourceCrs(), crs, context.transformContext())

        fields = QgsFields(points.fields())
        for name in RESULT_FIELDS:
            fields.append(int_field(name) if name == "DIR_MAX" else double_field(name, 20, 1))
        sink, dest_id = self.parameterAsSink(parameters, self.OUTPUT, context, fields, WKB_POINT, crs)
        if sink is None:
            raise QgsProcessingException(self.invalidSinkError(parameters, self.OUTPUT))

        ray_fields = QgsFields()
        ray_fields.append(int_field("SITE_FID"))
        ray_fields.append(double_field("AZIMUTH", 10, 1))
        ray_fields.append(double_field("FETCH_M", 20, 1))
        ray_sink, ray_id = self.parameterAsSink(parameters, self.OUTPUT_RAYS, context, ray_fields, WKB_LINESTRING, crs)

        directions = [float(a) for a in range(0, 360, step)]
        eff_dirs = [wind + k for k in range(-45, 46, 3)]
        total = max(points.featureCount(), 1)
        outside = 0
        for i, feature in enumerate(points.getFeatures()):
            if feedback.isCanceled():
                break
            geom = QgsGeometry(feature.geometry())
            if geom.isNull() or geom.isEmpty():
                continue
            if transform is not None:
                geom.transform(transform)
            point = QgsPointXY(geom.vertexAt(0))

            rays = fetch_rays(engine_geom, point, directions, reach)
            distances = [d for _a, d, _g in rays]
            if not any(distances):
                outside += 1
            imax = max(range(len(distances)), key=distances.__getitem__)
            wind_ray = fetch_rays(engine_geom, point, [wind], reach)[0][1]
            eff_rays = fetch_rays(engine_geom, point, eff_dirs, reach)
            fetch_eff = effective_fetch([a for a, _d, _g in eff_rays], [d for _a, d, _g in eff_rays], wind)

            out = QgsFeature(fields)
            out.setGeometry(geom)
            out.setAttributes(list(feature.attributes()) + [
                distances[imax], int(directions[imax]), sum(distances) / len(distances), wind_ray, fetch_eff])
            sink.addFeature(out, FAST_INSERT)

            if ray_sink is not None:
                for azimuth, distance, line in rays:
                    ray = QgsFeature(ray_fields)
                    ray.setGeometry(line)
                    ray.setAttributes([feature.id(), azimuth, distance])
                    ray_sink.addFeature(ray, FAST_INSERT)
            feedback.setProgress(int(100 * (i + 1) / total))

        if outside:
            feedback.reportError(self.tr("{} site(s) are not on the water surface: fetch set to 0.").format(outside))
        attach_style(context, dest_id, "fetch_points")
        results = {self.OUTPUT: dest_id}
        if ray_sink is not None:
            attach_style(context, ray_id, "fetch_rays")
            results[self.OUTPUT_RAYS] = ray_id
        return results
