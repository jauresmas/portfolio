"""Lake morphometry: planimetric and depth based indices."""

import json

from qgis.core import (
    QgsCoordinateTransform,
    QgsFeature,
    QgsFields,
    QgsGeometry,
    QgsProcessingException,
    QgsProcessingOutputString,
    QgsProcessingParameterFeatureSink,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterField,
    QgsProcessingParameterFileDestination,
    QgsProcessingParameterNumber,
    QgsProcessingParameterRasterLayer,
)

from ..compat import (
    FAST_INSERT,
    FIELD_ANY,
    NUMBER_DOUBLE,
    SOURCE_LINE,
    SOURCE_NO_GEOMETRY,
    SOURCE_POLYGON,
    WKB_LINESTRING,
    WKB_NOGEOMETRY,
    double_field,
    int_field,
    set_advanced,
    string_field,
)
from ..core import limnology
from ..core.geometry import maximum_length, maximum_width, read_depths_in_polygon
from ..core.report import build_report
from ..core.styles import attach_style
from ..core.textfmt import is_missing
from .base import LimnoAlgorithm, check_projected, plugin_version

FIELDS = (
    ("NAME", "string"),
    ("AREA_M2", "double"),
    ("AREA_HA", "double"),
    ("PERIM_M", "double"),
    ("ISLANDS", "int"),
    ("ISLAND_M2", "double"),
    ("LMAX_M", "double"),
    ("WMAX_M", "double"),
    ("WMEAN_M", "double"),
    ("DL", "double"),
    ("ZMAX_M", "double"),
    ("ZMEAN_M", "double"),
    ("ZMED_M", "double"),
    ("VOLUME_M3", "double"),
    ("ZR_PCT", "double"),
    ("DV", "double"),
)


def lake_metrics(geometry, depths=None, pixel_area=None, feedback=None):
    """Morphometric indices of one lake (geometry in a metric CRS).

    ``depths`` (optional) are the positive depths of the raster pixels inside
    the lake. Returns (metrics dict, max length line, max width line).
    """
    geometry = geometry.makeValid()
    area = geometry.area()
    perimeter = geometry.length()
    islands, island_area = 0, 0.0
    polygons = geometry.asMultiPolygon() if geometry.isMultipart() else [geometry.asPolygon()]
    for polygon in polygons:
        for ring in polygon[1:]:
            islands += 1
            island_area += QgsGeometry.fromPolygonXY([ring]).area()

    lmax, lmax_line = maximum_length(geometry, feedback)
    wmax, wmax_line = maximum_width(geometry, lmax_line)
    metrics = {
        "AREA_M2": area,
        "AREA_HA": area / 1e4,
        "PERIM_M": perimeter,
        "ISLANDS": islands,
        "ISLAND_M2": island_area,
        "LMAX_M": lmax,
        "WMAX_M": wmax,
        "WMEAN_M": area / lmax if lmax else None,
        "DL": limnology.shoreline_development(perimeter, area),
        "ZMAX_M": None,
        "ZMEAN_M": None,
        "ZMED_M": None,
        "VOLUME_M3": None,
        "ZR_PCT": None,
        "DV": None,
    }
    if depths is not None and len(depths):
        stats = limnology.depth_statistics(depths, pixel_area)
        zmean = stats["volume"] / area if area else 0.0
        metrics.update({
            "ZMAX_M": stats["max_depth"],
            "ZMEAN_M": zmean,
            "ZMED_M": stats["median_depth"],
            "VOLUME_M3": stats["volume"],
            "ZR_PCT": limnology.relative_depth(stats["max_depth"], area),
            "DV": limnology.volume_development(zmean, stats["max_depth"]),
        })
    return metrics, lmax_line, wmax_line


class MorphometryAlgorithm(LimnoAlgorithm):
    LAKE = "LAKE"
    NAME_FIELD = "NAME_FIELD"
    DEPTH = "DEPTH"
    STEP = "STEP"
    OUTPUT = "OUTPUT"
    OUTPUT_LINES = "OUTPUT_LINES"
    OUTPUT_HTML = "OUTPUT_HTML"

    GROUP_ID = "morphometry"
    GROUP_NAME = "Morphometry"
    ICON = "morphometry"

    def name(self):
        return "morphometry"

    def displayName(self):  # noqa: N802
        return self.tr("Lake morphometry")

    def shortHelpString(self):  # noqa: N802
        return self.tr(
            "Computes the standard morphometric indices of each lake polygon.\n\n"
            "<b>Planimetric</b>: surface area, shoreline length, islands, maximum length (longest "
            "straight line crossing only water), maximum width (perpendicular to it), mean width "
            "and shoreline development D<sub>L</sub> = L / (2&radic;(&pi;A)).\n"
            "<b>With a bathymetry raster</b>: volume, maximum, mean and median depth, relative "
            "depth Z<sub>r</sub> (%) and volume development D<sub>V</sub> = 3 Z<sub>mean</sub> / Z<sub>max</sub>.\n\n"
            "Optionally writes the maximum length and width lines and a complete HTML report "
            "(with the hypsographic curve when a raster is given). The lake layer must use a "
            "projected CRS in metres."
        )

    def initAlgorithm(self, config=None):  # noqa: N802
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.LAKE, self.tr("Lake outline (polygons)"), [SOURCE_POLYGON]))
        self.addParameter(QgsProcessingParameterField(
            self.NAME_FIELD, self.tr("Lake name field"), parentLayerParameterName=self.LAKE,
            type=FIELD_ANY, optional=True))
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.DEPTH, self.tr("Bathymetry raster (depth in m)"), optional=True))
        step = QgsProcessingParameterNumber(
            self.STEP, self.tr("Depth step of the hypsographic curve in the report (m, 0 = automatic)"),
            type=NUMBER_DOUBLE, minValue=0.0, defaultValue=0.0)
        self.addParameter(set_advanced(step))
        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT, self.tr("Morphometry table"), type=SOURCE_NO_GEOMETRY))
        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT_LINES, self.tr("Maximum length and width lines"), type=SOURCE_LINE,
            optional=True, createByDefault=True))
        self.addParameter(QgsProcessingParameterFileDestination(
            self.OUTPUT_HTML, self.tr("HTML report"), self.tr("HTML files (*.html)"),
            optional=True, createByDefault=False))
        self.addOutput(QgsProcessingOutputString("SUMMARY", self.tr("Summary (JSON)")))

    def processAlgorithm(self, parameters, context, feedback):  # noqa: N802
        lake = self.parameterAsSource(parameters, self.LAKE, context)
        if lake is None:
            raise QgsProcessingException(self.invalidSourceError(parameters, self.LAKE))
        check_projected(lake.sourceCrs(), self.tr("The lake outline"), self.tr)
        name_field = self.parameterAsString(parameters, self.NAME_FIELD, context)
        raster = self.parameterAsRasterLayer(parameters, self.DEPTH, context)
        step = self.parameterAsDouble(parameters, self.STEP, context)
        html_path = self.parameterAsFileOutput(parameters, self.OUTPUT_HTML, context)

        to_raster = None
        if raster is not None and raster.crs() != lake.sourceCrs():
            to_raster = QgsCoordinateTransform(lake.sourceCrs(), raster.crs(), context.transformContext())

        fields = QgsFields()
        for name, kind in FIELDS:
            fields.append({"string": string_field, "int": int_field}.get(kind, double_field)(name))
        sink, dest_id = self.parameterAsSink(parameters, self.OUTPUT, context, fields, WKB_NOGEOMETRY, lake.sourceCrs())
        if sink is None:
            raise QgsProcessingException(self.invalidSinkError(parameters, self.OUTPUT))

        line_fields = QgsFields()
        line_fields.append(string_field("NAME"))
        line_fields.append(string_field("TYPE", 20))
        line_fields.append(double_field("LENGTH_M"))
        line_sink, line_id = self.parameterAsSink(parameters, self.OUTPUT_LINES, context, line_fields,
                                                  WKB_LINESTRING, lake.sourceCrs())

        total = max(lake.featureCount(), 1)
        report_lakes, summary = [], []
        for i, feature in enumerate(lake.getFeatures()):
            if feedback.isCanceled():
                break
            geometry = feature.geometry()
            if geometry.isNull() or geometry.isEmpty():
                continue
            name = f"Lake {feature.id()}"
            if name_field and not is_missing(feature[name_field]):
                name = str(feature[name_field])
            feedback.pushInfo(self.tr("Processing {}...").format(name))

            depths, pixel_area = None, None
            if raster is not None:
                geom_r = QgsGeometry(geometry)
                if to_raster is not None:
                    geom_r.transform(to_raster)
                depths, pixel_area = read_depths_in_polygon(raster.source(), geom_r.asWkt())
                if not len(depths):
                    feedback.reportError(self.tr("{}: no raster pixel inside the lake.").format(name))

            metrics, lmax_line, wmax_line = lake_metrics(geometry, depths, pixel_area, feedback)
            metrics["NAME"] = name
            out = QgsFeature(fields)
            out.setAttributes([metrics[n] for n, _ in FIELDS])
            sink.addFeature(out, FAST_INSERT)

            if line_sink is not None:
                for kind, line, length in (("max_length", lmax_line, metrics["LMAX_M"]),
                                           ("max_width", wmax_line, metrics["WMAX_M"])):
                    if line is None:
                        continue
                    lf = QgsFeature(line_fields)
                    lf.setGeometry(line)
                    lf.setAttributes([name, kind, length])
                    line_sink.addFeature(lf, FAST_INSERT)

            hypso = None
            if html_path and depths is not None and len(depths):
                lake_step = step if step > 0 else _auto_step(metrics["ZMAX_M"])
                hypso = limnology.hypsometry(depths, pixel_area, lake_step)
            report_lakes.append({"name": name, "metrics": metrics, "hypsography": hypso})
            summary.append(metrics)
            feedback.setProgress(int(100 * (i + 1) / total))

        results = {self.OUTPUT: dest_id, "SUMMARY": json.dumps(summary)}
        if line_sink is not None:
            attach_style(context, line_id, "morphometry_lines")
            results[self.OUTPUT_LINES] = line_id
        if html_path:
            with open(html_path, "w", encoding="utf-8") as handle:
                handle.write(build_report(self.tr("Lake morphometry report"), report_lakes, plugin_version(),
                                          lake.sourceCrs().authid()))
            results[self.OUTPUT_HTML] = html_path
        return results


def _auto_step(zmax):
    """About 20 to 50 levels whatever the depth of the lake."""
    if not zmax:
        return 1.0
    for candidate in (0.1, 0.2, 0.25, 0.5, 1.0, 2.0, 5.0, 10.0, 20.0, 50.0):
        if zmax / candidate <= 50:
            return candidate
    return 100.0
