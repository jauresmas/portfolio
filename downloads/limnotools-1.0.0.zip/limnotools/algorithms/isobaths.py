"""Isobaths (depth contours) and depth zones from a bathymetric raster."""

import numpy as np
from osgeo import gdal, ogr
from qgis.core import (
    QgsFeature,
    QgsFields,
    QgsGeometry,
    QgsProcessingException,
    QgsProcessingParameterBand,
    QgsProcessingParameterFeatureSink,
    QgsProcessingParameterNumber,
    QgsProcessingParameterRasterLayer,
)

from ..compat import (
    FAST_INSERT,
    NUMBER_DOUBLE,
    SOURCE_LINE,
    SOURCE_POLYGON,
    WKB_MULTILINESTRING,
    WKB_MULTIPOLYGON,
    double_field,
)
from ..core.styles import attach_style
from .base import LimnoAlgorithm

gdal.UseExceptions()


def _qgs_geometry(ogr_geometry):
    geometry = QgsGeometry()
    geometry.fromWkb(bytes(ogr_geometry.ExportToIsoWkb()))
    return geometry


class IsobathsAlgorithm(LimnoAlgorithm):
    INPUT = "INPUT"
    BAND = "BAND"
    INTERVAL = "INTERVAL"
    OUTPUT = "OUTPUT"
    OUTPUT_ZONES = "OUTPUT_ZONES"

    GROUP_ID = "bathymetry"
    GROUP_NAME = "Bathymetry"
    ICON = "isobaths"

    def name(self):
        return "isobaths"

    def displayName(self):  # noqa: N802
        return self.tr("Isobaths and depth zones")

    def shortHelpString(self):  # noqa: N802
        return self.tr(
            "Draws isobaths (lines of equal depth) from a bathymetric raster, every <i>interval</i> "
            "metres, and optionally depth zones (polygons between two isobaths) ready for "
            "cartography. Depths are expected as positive values; a raster storing negative "
            "elevations is handled automatically."
        )

    def initAlgorithm(self, config=None):  # noqa: N802
        self.addParameter(QgsProcessingParameterRasterLayer(self.INPUT, self.tr("Bathymetry raster")))
        self.addParameter(QgsProcessingParameterBand(self.BAND, self.tr("Band"), 1, self.INPUT))
        self.addParameter(QgsProcessingParameterNumber(
            self.INTERVAL, self.tr("Interval (m)"), type=NUMBER_DOUBLE, minValue=0.01, defaultValue=1.0))
        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT, self.tr("Isobaths"), type=SOURCE_LINE))
        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT_ZONES, self.tr("Depth zones"), type=SOURCE_POLYGON, optional=True, createByDefault=False))

    def processAlgorithm(self, parameters, context, feedback):  # noqa: N802
        raster = self.parameterAsRasterLayer(parameters, self.INPUT, context)
        if raster is None:
            raise QgsProcessingException(self.tr("Invalid raster layer."))
        band_index = self.parameterAsInt(parameters, self.BAND, context) or 1
        interval = self.parameterAsDouble(parameters, self.INTERVAL, context)

        dataset = gdal.Open(raster.source())
        if dataset is None:
            raise QgsProcessingException(self.tr("This raster cannot be read by GDAL."))
        band = dataset.GetRasterBand(band_index)
        nodata = band.GetNoDataValue()

        # Work on positive depths
        data = band.ReadAsArray().astype("float64")

        valid = np.isfinite(data) if nodata is None else (data != nodata) & np.isfinite(data)
        if not valid.any():
            raise QgsProcessingException(self.tr("The raster has no valid pixel."))
        if np.median(data[valid]) < 0:
            data = np.where(valid, -data, data)
        fill = -9999.0
        mem = gdal.GetDriverByName("MEM").Create("", dataset.RasterXSize, dataset.RasterYSize, 1, gdal.GDT_Float64)
        mem.SetGeoTransform(dataset.GetGeoTransform())
        mem.SetProjection(dataset.GetProjection())
        mem_band = mem.GetRasterBand(1)
        mem_band.WriteArray(np.where(valid, np.clip(data, 0, None), fill))
        mem_band.SetNoDataValue(fill)

        line_fields = QgsFields()
        line_fields.append(double_field("depth", 10, 2))
        sink, dest_id = self.parameterAsSink(parameters, self.OUTPUT, context, line_fields,
                                             WKB_MULTILINESTRING, raster.crs())
        if sink is None:
            raise QgsProcessingException(self.invalidSinkError(parameters, self.OUTPUT))

        ogr_ds = ogr.GetDriverByName("Memory").CreateDataSource("contours")
        lines = ogr_ds.CreateLayer("lines", geom_type=ogr.wkbLineString)
        lines.CreateField(ogr.FieldDefn("id", ogr.OFTInteger))
        lines.CreateField(ogr.FieldDefn("depth", ogr.OFTReal))
        zmax = float(data[valid].max())
        levels = [interval * k for k in range(1, int(zmax / interval) + 1)]
        if len(levels) > 5000:
            raise QgsProcessingException(self.tr("Too many isobaths: increase the interval."))
        fixed = ",".join(f"{level:g}" for level in levels)
        if levels:
            gdal.ContourGenerateEx(mem_band, lines, options=[
                f"FIXED_LEVELS={fixed}", "ID_FIELD=0", "ELEV_FIELD=1", f"NODATA={fill}"])
        feedback.setProgress(50)

        count = 0
        for ogr_feature in lines:
            depth = ogr_feature.GetField("depth")
            if depth is None or depth <= 0:
                continue  # the 0 m contour is the shoreline itself
            feature = QgsFeature(line_fields)
            feature.setGeometry(_qgs_geometry(ogr_feature.GetGeometryRef()))
            feature.setAttributes([round(depth, 3)])
            sink.addFeature(feature, FAST_INSERT)
            count += 1
        feedback.pushInfo(self.tr("{} isobaths created.").format(count))
        attach_style(context, dest_id, "isobaths")
        results = {self.OUTPUT: dest_id}

        if parameters.get(self.OUTPUT_ZONES) is not None:
            zone_fields = QgsFields()
            zone_fields.append(double_field("depth_min", 10, 2))
            zone_fields.append(double_field("depth_max", 10, 2))
            zone_sink, zone_id = self.parameterAsSink(parameters, self.OUTPUT_ZONES, context, zone_fields,
                                                      WKB_MULTIPOLYGON, raster.crs())
            if zone_sink is not None:
                polys = ogr_ds.CreateLayer("zones", geom_type=ogr.wkbMultiPolygon)
                polys.CreateField(ogr.FieldDefn("id", ogr.OFTInteger))
                polys.CreateField(ogr.FieldDefn("depth_min", ogr.OFTReal))
                polys.CreateField(ogr.FieldDefn("depth_max", ogr.OFTReal))
                bounds = ",".join(f"{level:g}" for level in [0.0] + levels + [interval * (len(levels) + 1)])
                gdal.ContourGenerateEx(mem_band, polys, options=[
                    f"FIXED_LEVELS={bounds}", "ID_FIELD=0", "ELEV_FIELD_MIN=1",
                    "ELEV_FIELD_MAX=2", "POLYGONIZE=YES", f"NODATA={fill}"])
                for ogr_feature in polys:
                    geom = ogr_feature.GetGeometryRef()
                    if geom is None or geom.IsEmpty():
                        continue
                    feature = QgsFeature(zone_fields)
                    feature.setGeometry(_qgs_geometry(geom))
                    feature.setAttributes([max(0.0, round(ogr_feature.GetField("depth_min"), 3)),
                                           round(ogr_feature.GetField("depth_max"), 3)])
                    zone_sink.addFeature(feature, FAST_INSERT)
                attach_style(context, zone_id, "depth_zones")
                results[self.OUTPUT_ZONES] = zone_id

        feedback.setProgress(100)
        return results
