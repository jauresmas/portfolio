"""Carlson Trophic State Index."""

from qgis.core import (
    QgsFeature,
    QgsFields,
    QgsProcessingException,
    QgsProcessingParameterEnum,
    QgsProcessingParameterFeatureSink,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterField,
    QgsWkbTypes,
)

from ..compat import FAST_INSERT, FIELD_ANY, GEOMETRY_POINT, SOURCE_ANY_GEOMETRY, double_field, string_field
from ..core.limnology import carlson_tsi
from ..core.textfmt import to_float
from ..core.styles import attach_style
from .base import LimnoAlgorithm

TSI_FIELDS = (
    ("TSI_SD", "tsi_sd"),
    ("TSI_CHL", "tsi_chl"),
    ("TSI_TP", "tsi_tp"),
    ("TSI_MEAN", "tsi_mean"),
    ("TROPHIC", "trophic_class"),
    ("DEV_CHL_SD", "dev_chl_sd"),
    ("DEV_CHL_TP", "dev_chl_tp"),
)


class TrophicStateAlgorithm(LimnoAlgorithm):
    INPUT = "INPUT"
    SECCHI = "SECCHI"
    CHL = "CHL"
    TP = "TP"
    UNIT = "UNIT"
    OUTPUT = "OUTPUT"

    GROUP_ID = "waterquality"
    GROUP_NAME = "Water quality"
    ICON = "trophic"

    def name(self):
        return "trophicstate"

    def displayName(self):  # noqa: N802
        return self.tr("Trophic State Index (Carlson)")

    def shortHelpString(self):  # noqa: N802
        return self.tr(
            "Computes Carlson's Trophic State Index (1977) for each sample from one, two or three "
            "variables:\n"
            "TSI(SD) = 60 - 14.41 ln(Secchi depth, m)\n"
            "TSI(CHL) = 9.81 ln(chlorophyll-a, &micro;g/L) + 30.6\n"
            "TSI(TP) = 14.42 ln(total phosphorus, &micro;g/L) + 4.15\n\n"
            "TSI_MEAN is the mean of the available indices and TROPHIC its class: oligotrophic "
            "(&lt; 40), mesotrophic (40-50), eutrophic (50-70), hypereutrophic (&gt; 70).\n\n"
            "Deviations help interpret the result (Carlson 1991): DEV_CHL_SD &lt; 0 points to "
            "non-algal turbidity, DEV_CHL_TP &lt; 0 suggests that phosphorus is not the limiting "
            "factor.\n\n"
            "Empty, zero or negative values are ignored."
        )

    def initAlgorithm(self, config=None):  # noqa: N802
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.INPUT, self.tr("Sampling stations"), [SOURCE_ANY_GEOMETRY]))
        for key, label in ((self.SECCHI, "Secchi depth field (m)"),
                           (self.CHL, "Chlorophyll-a field"),
                           (self.TP, "Total phosphorus field")):
            self.addParameter(QgsProcessingParameterField(
                key, self.tr(label), parentLayerParameterName=self.INPUT, type=FIELD_ANY, optional=True))
        self.addParameter(QgsProcessingParameterEnum(
            self.UNIT, self.tr("Unit of chlorophyll-a and phosphorus"),
            options=["µg/L", "mg/L"], defaultValue=0))
        self.addParameter(QgsProcessingParameterFeatureSink(self.OUTPUT, self.tr("Trophic state")))

    def processAlgorithm(self, parameters, context, feedback):  # noqa: N802
        source = self.parameterAsSource(parameters, self.INPUT, context)
        if source is None:
            raise QgsProcessingException(self.invalidSourceError(parameters, self.INPUT))
        secchi = self.parameterAsString(parameters, self.SECCHI, context)
        chl = self.parameterAsString(parameters, self.CHL, context)
        tp = self.parameterAsString(parameters, self.TP, context)
        if not (secchi or chl or tp):
            raise QgsProcessingException(self.tr("Choose at least one variable (Secchi, chlorophyll-a or phosphorus)."))
        factor = 1000.0 if self.parameterAsEnum(parameters, self.UNIT, context) == 1 else 1.0

        fields = QgsFields(source.fields())
        for name, _key in TSI_FIELDS:
            fields.append(string_field(name, 20) if name == "TROPHIC" else double_field(name, 10, 2))
        sink, dest_id = self.parameterAsSink(parameters, self.OUTPUT, context, fields,
                                             source.wkbType(), source.sourceCrs())
        if sink is None:
            raise QgsProcessingException(self.invalidSinkError(parameters, self.OUTPUT))

        def value(feature, field, scale=1.0):
            if not field:
                return None
            number = to_float(feature[field])
            return None if number is None else number * scale

        counts = {}
        total = max(source.featureCount(), 1)
        for i, feature in enumerate(source.getFeatures()):
            if feedback.isCanceled():
                break
            tsi = carlson_tsi(value(feature, secchi), value(feature, chl, factor), value(feature, tp, factor))
            out = QgsFeature(fields)
            out.setGeometry(feature.geometry())
            out.setAttributes(list(feature.attributes()) + [tsi[key] for _name, key in TSI_FIELDS])
            sink.addFeature(out, FAST_INSERT)
            counts[tsi["trophic_class"]] = counts.get(tsi["trophic_class"], 0) + 1
            feedback.setProgress(int(100 * (i + 1) / total))

        for key, count in counts.items():
            feedback.pushInfo(f"{key or 'no data'}: {count}")
        if QgsWkbTypes.geometryType(source.wkbType()) == GEOMETRY_POINT:
            attach_style(context, dest_id, "trophic")
        return {self.OUTPUT: dest_id}
