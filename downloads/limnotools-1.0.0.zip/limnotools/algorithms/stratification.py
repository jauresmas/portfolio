"""Thermal stratification from vertical profiles (temperature, oxygen)."""

import json
import math

from osgeo import gdal
from qgis.core import (
    QgsCoordinateTransform,
    QgsFeature,
    QgsFields,
    QgsGeometry,
    QgsProcessingException,
    QgsProcessingOutputString,
    QgsProcessingParameterFeatureSink,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterField,
    QgsProcessingParameterNumber,
    QgsProcessingParameterRasterLayer,
    QgsRectangle,
)

from ..compat import (
    FAST_INSERT,
    FIELD_ANY,
    NUMBER_DOUBLE,
    SOURCE_NO_GEOMETRY,
    SOURCE_POLYGON,
    WKB_NOGEOMETRY,
    double_field,
    int_field,
    set_advanced,
    string_field,
)
from ..core.geometry import read_depths_in_polygon
from ..core.stratification import MIN_GRADIENT, analyse_profile
from ..core.textfmt import is_missing, to_float
from .base import LimnoAlgorithm
from .bathymetry import dissolve

OUTPUT_FIELDS = (
    ("STATION", "string", "station"),
    ("DATE", "string", "date"),
    ("N_DEPTHS", "int", "n_depths"),
    ("DEPTH_M", "double", "max_depth"),
    ("T_SURF", "double", "t_surface"),
    ("T_BOTTOM", "double", "t_bottom"),
    ("DELTA_T", "double", "delta_t"),
    ("STATUS", "string", "status"),
    ("THERMO_M", "double", "thermocline"),
    ("EPI_BOT_M", "double", "epi_bottom"),
    ("HYPO_TOP_M", "double", "hypo_top"),
    ("MAX_GRAD", "double", "max_gradient"),
    ("OXYCLINE_M", "double", "oxycline"),
    ("HYPOXIA_M", "double", "hypoxia"),
    ("SCHMIDT", "double", "schmidt"),
    ("VOL_EPI", "double", "vol_epi"),
    ("VOL_META", "double", "vol_meta"),
    ("VOL_HYPO", "double", "vol_hypo"),
    ("PCT_HYPO", "double", "pct_hypo"),
)


def _text(value):
    if is_missing(value):
        return ""
    if hasattr(value, "toString") and hasattr(value, "isValid"):
        try:
            from qgis.PyQt.QtCore import Qt

            return value.toString(Qt.DateFormat.ISODate)
        except (AttributeError, TypeError):
            return value.toString()
    return str(value)


def _number(value):
    return to_float(value)


class StratificationAlgorithm(LimnoAlgorithm):
    INPUT = "INPUT"
    STATION = "STATION"
    DATE = "DATE"
    DEPTH = "DEPTH"
    TEMPERATURE = "TEMPERATURE"
    OXYGEN = "OXYGEN"
    BATHYMETRY = "BATHYMETRY"
    LAKE = "LAKE"
    MIN_GRADIENT = "MIN_GRADIENT"
    OUTPUT = "OUTPUT"

    GROUP_ID = "watercolumn"
    GROUP_NAME = "Water column"
    ICON = "stratification"

    def name(self):
        return "stratification"

    def displayName(self):  # noqa: N802
        return self.tr("Thermal stratification")

    def shortHelpString(self):  # noqa: N802
        return self.tr(
            "Analyses vertical profiles measured with a multiparameter probe (one row per depth) "
            "and finds the layers of the water column for each station and date:\n"
            "<b>epilimnion</b>: warm, mixed surface layer;\n"
            "<b>metalimnion</b>: transition layer, which contains the <b>thermocline</b> (depth of "
            "the steepest density change);\n"
            "<b>hypolimnion</b>: cold bottom layer, often poor in oxygen.\n\n"
            "A profile is <i>stratified</i> when the density gradient exceeds the threshold "
            "(0.1 kg/m3/m by default), otherwise <i>mixed</i>. With dissolved oxygen, the tool also "
            "gives the oxycline and the depth where oxygen drops below 2 mg/L (hypoxia).\n\n"
            "With the bathymetry raster, it computes the Schmidt stability (J/m2, energy needed "
            "to mix the lake) and the water volume of each layer.\n\n"
            "Methods of rLakeAnalyzer (Read et al. 2011); water density after Martin & "
            "McCutcheon (1999)."
        )

    def initAlgorithm(self, config=None):  # noqa: N802
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.INPUT, self.tr("Vertical profiles (table or CSV)"), [SOURCE_NO_GEOMETRY]))
        self.addParameter(QgsProcessingParameterField(
            self.STATION, self.tr("Station field"), parentLayerParameterName=self.INPUT,
            type=FIELD_ANY, optional=True))
        self.addParameter(QgsProcessingParameterField(
            self.DATE, self.tr("Date field"), parentLayerParameterName=self.INPUT,
            type=FIELD_ANY, optional=True))
        self.addParameter(QgsProcessingParameterField(
            self.DEPTH, self.tr("Depth field (m)"), parentLayerParameterName=self.INPUT, type=FIELD_ANY))
        self.addParameter(QgsProcessingParameterField(
            self.TEMPERATURE, self.tr("Temperature field (°C)"), parentLayerParameterName=self.INPUT,
            type=FIELD_ANY))
        self.addParameter(QgsProcessingParameterField(
            self.OXYGEN, self.tr("Dissolved oxygen field (mg/L)"), parentLayerParameterName=self.INPUT,
            type=FIELD_ANY, optional=True))
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.BATHYMETRY, self.tr("Bathymetry raster (optional, for stability and volumes)"), optional=True))
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.LAKE, self.tr("Lake outline (optional mask)"), [SOURCE_POLYGON], optional=True))
        gradient = QgsProcessingParameterNumber(
            self.MIN_GRADIENT, self.tr("Stratification threshold (kg/m3/m)"), type=NUMBER_DOUBLE,
            minValue=0.001, defaultValue=MIN_GRADIENT)
        self.addParameter(set_advanced(gradient))
        self.addParameter(QgsProcessingParameterFeatureSink(
            self.OUTPUT, self.tr("Stratification"), type=SOURCE_NO_GEOMETRY))
        self.addOutput(QgsProcessingOutputString("PROFILES", self.tr("Profiles and results (JSON)")))

    def processAlgorithm(self, parameters, context, feedback):  # noqa: N802
        source = self.parameterAsSource(parameters, self.INPUT, context)
        if source is None:
            raise QgsProcessingException(self.invalidSourceError(parameters, self.INPUT))
        station_field = self.parameterAsString(parameters, self.STATION, context)
        date_field = self.parameterAsString(parameters, self.DATE, context)
        depth_field = self.parameterAsString(parameters, self.DEPTH, context)
        temp_field = self.parameterAsString(parameters, self.TEMPERATURE, context)
        oxygen_field = self.parameterAsString(parameters, self.OXYGEN, context)
        raster = self.parameterAsRasterLayer(parameters, self.BATHYMETRY, context)
        lake = self.parameterAsSource(parameters, self.LAKE, context)
        threshold = self.parameterAsDouble(parameters, self.MIN_GRADIENT, context)

        # Group the rows into profiles (station, date)
        profiles = {}
        for feature in source.getFeatures():
            if feedback.isCanceled():
                return {}
            depth = _number(feature[depth_field])
            temperature = _number(feature[temp_field])
            if depth is None or temperature is None:
                continue
            key = (_text(feature[station_field]) if station_field else "",
                   _text(feature[date_field]) if date_field else "")
            profile = profiles.setdefault(key, {"depth": [], "temp": [], "oxygen": []})
            profile["depth"].append(abs(depth))
            profile["temp"].append(temperature)
            profile["oxygen"].append(_number(feature[oxygen_field]) if oxygen_field else None)
        if not profiles:
            raise QgsProcessingException(self.tr("No row with both a depth and a temperature."))
        feedback.pushInfo(self.tr("{} profile(s) found.").format(len(profiles)))

        lake_depths, pixel_area = None, None
        if raster is not None:
            if raster.crs().isGeographic():
                raise QgsProcessingException(self.tr("The bathymetry raster must use a projected CRS in metres."))
            if lake is not None:
                transform = None
                if lake.sourceCrs() != raster.crs():
                    transform = QgsCoordinateTransform(lake.sourceCrs(), raster.crs(), context.transformContext())
                mask = dissolve(lake, transform, feedback)
            else:
                dataset = gdal.Open(raster.source())
                gt = dataset.GetGeoTransform()
                mask = QgsGeometry.fromRect(QgsRectangle(
                    gt[0], gt[3] + gt[5] * dataset.RasterYSize, gt[0] + gt[1] * dataset.RasterXSize, gt[3]))
                dataset = None
            lake_depths, pixel_area = read_depths_in_polygon(raster.source(), mask.asWkt())
            if not len(lake_depths):
                feedback.reportError(self.tr("No valid depth in the bathymetry raster: stability and volumes skipped."))
                lake_depths = None

        fields = QgsFields()
        for name, kind, _key in OUTPUT_FIELDS:
            fields.append({"string": string_field, "int": int_field}.get(kind, double_field)(name))
        sink, dest_id = self.parameterAsSink(parameters, self.OUTPUT, context, fields, WKB_NOGEOMETRY,
                                             source.sourceCrs())
        if sink is None:
            raise QgsProcessingException(self.invalidSinkError(parameters, self.OUTPUT))

        summary = []
        for i, ((station, date), data) in enumerate(sorted(profiles.items())):
            oxygen = data["oxygen"] if oxygen_field else None
            if oxygen is not None:
                oxygen = [o if o is not None else float("nan") for o in oxygen]
            result = analyse_profile(data["depth"], data["temp"], oxygen, lake_depths, pixel_area, threshold)
            result.update({"station": station, "date": date,
                           "status": "stratified" if result["stratified"] else "mixed"})
            feature = QgsFeature(fields)
            feature.setAttributes([result[key] for _name, _kind, key in OUTPUT_FIELDS])
            sink.addFeature(feature, FAST_INSERT)

            order = sorted(range(len(data["depth"])), key=data["depth"].__getitem__)
            result["profile"] = {
                "depth": [data["depth"][k] for k in order],
                "temp": [data["temp"][k] for k in order],
                "oxygen": [oxygen[k] for k in order] if oxygen is not None else None,
            }
            summary.append(result)
            label = f"{station or '-'} {date}".strip()
            if result["stratified"]:
                message = self.tr("{}: stratified, thermocline at {:.1f} m")
                feedback.pushInfo(message.format(label, result["thermocline"]))
            else:
                feedback.pushInfo(self.tr("{}: mixed").format(label))
            feedback.setProgress(int(100 * (i + 1) / len(profiles)))

        def clean(value):
            if isinstance(value, float) and not math.isfinite(value):
                return None
            if isinstance(value, list):
                return [clean(v) for v in value]
            if isinstance(value, dict):
                return {k: clean(v) for k, v in value.items()}
            return value

        return {self.OUTPUT: dest_id, "PROFILES": json.dumps(clean(summary))}
