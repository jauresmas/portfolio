"""Common base class for LimnoTools Processing algorithms."""

import os

from qgis.core import QgsProcessingAlgorithm, QgsProcessingException
from qgis.PyQt.QtCore import QCoreApplication
from qgis.PyQt.QtGui import QIcon

PLUGIN_DIR = os.path.dirname(os.path.dirname(__file__))
ICONS_DIR = os.path.join(PLUGIN_DIR, "icons")
HELP_URL = "https://github.com/jauresmas/limnotools#readme"


def plugin_version():
    import configparser

    parser = configparser.ConfigParser(interpolation=None)
    parser.read(os.path.join(PLUGIN_DIR, "metadata.txt"), encoding="utf-8")
    return parser.get("general", "version", fallback="")


def icon(name):
    return QIcon(os.path.join(ICONS_DIR, f"{name}.svg"))


def check_projected(crs, label, tr):
    """Morphometry needs metric distances: refuse geographic CRS."""
    if not crs.isValid():
        raise QgsProcessingException(tr("{} has no valid coordinate reference system.").format(label))
    if crs.isGeographic():
        raise QgsProcessingException(
            tr("{} uses a geographic CRS ({}). Reproject it to a projected CRS in metres "
               "(UTM, Lambert...) before running this tool.").format(label, crs.authid())
        )


class LimnoAlgorithm(QgsProcessingAlgorithm):
    """Shared plumbing: translation, icons, groups and help."""

    GROUP_ID = ""
    GROUP_NAME = ""
    ICON = "icon"

    def tr(self, text):
        return QCoreApplication.translate("LimnoTools", text)

    def createInstance(self):  # noqa: N802
        return type(self)()

    def group(self):
        return self.tr(self.GROUP_NAME)

    def groupId(self):  # noqa: N802
        return self.GROUP_ID

    def icon(self):
        return icon(self.ICON)

    def helpUrl(self):  # noqa: N802
        return HELP_URL
