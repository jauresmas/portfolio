"""Bathymetric surface interpolation from echo-sounding points."""

import math
import os

import numpy as np
from osgeo import gdal, ogr, osr
from qgis.core import (
    QgsCoordinateTransform,
    QgsFeatureRequest,
    QgsGeometry,
    QgsProcessingException,
    QgsProcessingOutputNumber,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterEnum,
    QgsProcessingParameterFeatureSource,
    QgsProcessingParameterField,
    QgsProcessingParameterNumber,
    QgsProcessingParameterRasterDestination,
    QgsProcessingUtils,
)

from ..compat import FIELD_ANY, NUMBER_DOUBLE, SOURCE_POINT, SOURCE_POLYGON, set_advanced
from ..core.geometry import rasterize_mask, shoreline_points
from ..core.limnology import depth_statistics
from ..core.styles import attach_style
from ..core.textfmt import to_float
from .base import LimnoAlgorithm, check_projected

NODATA = -9999.0


def nice_pixel_size(extent_size, target_cells=400):
    """Round ``extent_size / target_cells`` to 1, 2 or 5 x 10^k."""
    raw = max(extent_size / target_cells, 1e-6)
    exponent = math.floor(math.log10(raw))
    for factor in (1, 2, 5, 10):
        size = factor * 10 ** exponent
        if size >= raw:
            return float(size)
    return float(10 ** (exponent + 1))


def dissolve(source, transform=None, feedback=None):
    """Union of all the features of a polygon source."""
    parts = []
    for feature in source.getFeatures(QgsFeatureRequest()):
        if feedback is not None and feedback.isCanceled():
            break
        geom = QgsGeometry(feature.geometry())
        if geom.isNull() or geom.isEmpty():
            continue
        if transform is not None:
            geom.transform(transform)
        parts.append(geom.makeValid())
    if not parts:
        return QgsGeometry()
    return QgsGeometry.unaryUnion(parts)


class BathymetryAlgorithm(LimnoAlgorithm):
    SOUNDINGS = "SOUNDINGS"
    DEPTH_FIELD = "DEPTH_FIELD"
    LAKE = "LAKE"
    METHOD = "METHOD"
    PIXEL_SIZE = "PIXEL_SIZE"
    POWER = "POWER"
    SHORE_ZERO = "SHORE_ZERO"
    OUTPUT = "OUTPUT"

    GROUP_ID = "bathymetry"
    GROUP_NAME = "Bathymetry"
    ICON = "bathymetry"

    METHODS = ("linear", "idw")

    def name(self):
        return "bathymetry"

    def displayName(self):  # noqa: N802
        return self.tr("Interpolate bathymetry")

    def shortHelpString(self):  # noqa: N802
        return self.tr(
            "Builds a bathymetric raster (water depth in metres) from echo-sounding points.\n\n"
            "<b>Soundings</b>: points with a depth value. Negative values (elevations below the "
            "water surface) are converted to positive depths.\n"
            "<b>Lake outline</b>: polygon(s) of the water body. The raster is clipped to it and, "
            "if requested, its shoreline is used as a zero depth contour so that the surface "
            "meets the shore.\n"
            "<b>Method</b>: TIN (Delaunay triangulation, linear) honours every sounding and suits "
            "dense transects; IDW (inverse distance weighting) gives a smoother surface for "
            "scattered points.\n"
            "<b>Pixel size</b>: 0 picks a size giving about 400 cells along the longest side.\n\n"
            "The layers must use a projected CRS in metres. Outputs the maximum depth, mean depth "
            "and volume of the interpolated surface."
        )

    def initAlgorithm(self, config=None):  # noqa: N802
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.SOUNDINGS, self.tr("Soundings (points)"), [SOURCE_POINT]))
        self.addParameter(QgsProcessingParameterField(
            self.DEPTH_FIELD, self.tr("Depth field (m)"), parentLayerParameterName=self.SOUNDINGS,
            type=FIELD_ANY))
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.LAKE, self.tr("Lake outline (polygons)"), [SOURCE_POLYGON]))
        self.addParameter(QgsProcessingParameterEnum(
            self.METHOD, self.tr("Interpolation method"),
            options=[self.tr("TIN (triangulation, linear)"), self.tr("IDW (inverse distance weighting)")],
            defaultValue=0))
        self.addParameter(QgsProcessingParameterNumber(
            self.PIXEL_SIZE, self.tr("Pixel size (m, 0 = automatic)"), type=NUMBER_DOUBLE,
            minValue=0.0, defaultValue=0.0))
        power = QgsProcessingParameterNumber(
            self.POWER, self.tr("IDW power"), type=NUMBER_DOUBLE, minValue=0.5, maxValue=6.0, defaultValue=2.0)
        self.addParameter(set_advanced(power))
        self.addParameter(QgsProcessingParameterBoolean(
            self.SHORE_ZERO, self.tr("Force zero depth along the shoreline"), defaultValue=True))
        self.addParameter(QgsProcessingParameterRasterDestination(self.OUTPUT, self.tr("Bathymetry")))
        self.addOutput(QgsProcessingOutputNumber("MAX_DEPTH", self.tr("Maximum depth (m)")))
        self.addOutput(QgsProcessingOutputNumber("MEAN_DEPTH", self.tr("Mean depth (m)")))
        self.addOutput(QgsProcessingOutputNumber("VOLUME", self.tr("Volume (m3)")))

    def processAlgorithm(self, parameters, context, feedback):  # noqa: N802
        soundings = self.parameterAsSource(parameters, self.SOUNDINGS, context)
        lake = self.parameterAsSource(parameters, self.LAKE, context)
        if soundings is None or lake is None:
            raise QgsProcessingException(self.tr("Invalid input layers."))
        depth_field = self.parameterAsString(parameters, self.DEPTH_FIELD, context)
        method = self.METHODS[self.parameterAsEnum(parameters, self.METHOD, context)]
        pixel = self.parameterAsDouble(parameters, self.PIXEL_SIZE, context)
        power = self.parameterAsDouble(parameters, self.POWER, context)
        shore_zero = self.parameterAsBoolean(parameters, self.SHORE_ZERO, context)
        output = self.parameterAsOutputLayer(parameters, self.OUTPUT, context)

        crs = lake.sourceCrs()
        check_projected(crs, self.tr("The lake outline"), self.tr)

        feedback.pushInfo(self.tr("Reading the lake outline..."))
        lake_geom = dissolve(lake, feedback=feedback)
        if lake_geom.isEmpty():
            raise QgsProcessingException(self.tr("The lake outline layer has no valid polygon."))
        bbox = lake_geom.boundingBox()
        if pixel <= 0:
            pixel = nice_pixel_size(max(bbox.width(), bbox.height()))
        feedback.pushInfo(self.tr("Pixel size: {} m").format(pixel))

        # Snap the grid to the pixel size, one pixel margin.
        minx = math.floor(bbox.xMinimum() / pixel) * pixel - pixel
        maxx = math.ceil(bbox.xMaximum() / pixel) * pixel + pixel
        miny = math.floor(bbox.yMinimum() / pixel) * pixel - pixel
        maxy = math.ceil(bbox.yMaximum() / pixel) * pixel + pixel
        width, height = int(round((maxx - minx) / pixel)), int(round((maxy - miny) / pixel))
        if width * height > 60_000_000:
            raise QgsProcessingException(self.tr(
                "The requested grid is too large ({} x {} cells). Increase the pixel size.").format(width, height))

        transform = None
        if soundings.sourceCrs() != crs:
            transform = QgsCoordinateTransform(soundings.sourceCrs(), crs, context.transformContext())

        # Temporary point dataset for gdal.Grid
        tmp_path = QgsProcessingUtils.generateTempFilename("limnotools_soundings.gpkg")
        srs = osr.SpatialReference()
        srs.ImportFromWkt(crs.toWkt())
        ds = ogr.GetDriverByName("GPKG").CreateDataSource(tmp_path)
        layer = ds.CreateLayer("points", srs, ogr.wkbPoint25D)
        layer.CreateField(ogr.FieldDefn("z", ogr.OFTReal))
        defn = layer.GetLayerDefn()
        layer.StartTransaction()

        n_points, total = 0, max(soundings.featureCount(), 1)
        request = QgsFeatureRequest().setSubsetOfAttributes([depth_field], soundings.fields())
        for i, feature in enumerate(soundings.getFeatures(request)):
            if feedback.isCanceled():
                return {}
            value = feature[depth_field]
            geom = feature.geometry()
            number = to_float(value)
            if number is None or geom.isNull():
                continue
            depth = abs(number)
            if transform is not None:
                geom.transform(transform)
            for vertex in geom.vertices():
                f = ogr.Feature(defn)
                f.SetField("z", depth)
                f.SetGeometry(ogr.CreateGeometryFromWkt(f"POINT Z ({vertex.x()} {vertex.y()} {depth})"))
                layer.CreateFeature(f)
                n_points += 1
            feedback.setProgress(int(20 * i / total))

        if n_points < 3:
            raise QgsProcessingException(self.tr("At least 3 soundings with a depth value are needed."))

        if shore_zero:
            for point in shoreline_points(lake_geom, pixel * 2, max_points=20000):
                f = ogr.Feature(defn)
                f.SetField("z", 0.0)
                f.SetGeometry(ogr.CreateGeometryFromWkt(f"POINT Z ({point.x()} {point.y()} 0)"))
                layer.CreateFeature(f)
        layer.CommitTransaction()
        ds = None

        feedback.pushInfo(self.tr("{} soundings used, interpolating ({})...").format(n_points, method.upper()))
        if method == "linear":
            algorithm = f"linear:radius=-1:nodata={NODATA}"
        else:
            # A search radius covering the whole lake makes GDAL visit every sounding for every
            # cell (minutes on a large lake). Six times the mean sounding spacing is enough for
            # the 12 nearest points; the rare cells left empty are filled afterwards.
            spacing = math.sqrt(max(lake_geom.area(), 1.0) / n_points)
            radius = max(6.0 * spacing, 4.0 * pixel)
            algorithm = (f"invdistnn:power={power}:smoothing=0:radius={radius}:"
                         f"max_points=12:min_points=1:nodata={NODATA}")

        def progress(complete, _message, _data):
            feedback.setProgress(20 + int(70 * complete))
            return 0 if feedback.isCanceled() else 1

        source = gdal.OpenEx(tmp_path, gdal.OF_VECTOR)
        options = gdal.GridOptions(
            format="GTiff", outputType=gdal.GDT_Float32, width=width, height=height,
            outputBounds=[minx, maxy, maxx, miny], outputSRS=crs.toWkt(), algorithm=algorithm,
            zfield="z", layers=["points"], creationOptions=["COMPRESS=DEFLATE", "TILED=YES"],
            callback=progress)
        result = gdal.Grid(output, source, options=options)
        source = None
        if result is None:
            raise QgsProcessingException(self.tr("GDAL interpolation failed."))

        # Clip to the lake outline, make depths positive, set nodata.
        band = result.GetRasterBand(1)
        if method == "idw":
            band.SetNoDataValue(NODATA)
            gdal.FillNodata(band, None, max(width, height), 0)
        data = band.ReadAsArray().astype("float32")
        mask = rasterize_mask(lake_geom.asWkt(), result.GetGeoTransform(), width, height, crs.toWkt())
        valid = mask & (data != NODATA) & np.isfinite(data)
        data = np.where(valid, np.clip(data, 0.0, None), NODATA).astype("float32")
        band.WriteArray(data)
        band.SetNoDataValue(NODATA)
        band.SetDescription("depth (m)")
        band.ComputeStatistics(False)
        result.FlushCache()
        result = None
        try:
            os.remove(tmp_path)
        except OSError:
            pass

        stats = depth_statistics(data[valid], pixel * pixel)
        volume = stats["volume"]
        mean_depth = volume / lake_geom.area() if lake_geom.area() else 0.0
        feedback.pushInfo(self.tr("Maximum depth: {:.2f} m, mean depth: {:.2f} m, volume: {:,.0f} m3").format(
            stats["max_depth"], mean_depth, volume))
        feedback.setProgress(100)

        attach_style(context, output, "bathymetry")
        return {
            self.OUTPUT: output,
            "MAX_DEPTH": stats["max_depth"],
            "MEAN_DEPTH": mean_depth,
            "VOLUME": volume,
        }
