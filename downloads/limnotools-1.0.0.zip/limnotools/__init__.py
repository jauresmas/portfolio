"""LimnoTools: lake bathymetry and limnology toolkit for QGIS.

Copyright (C) 2026 Jaurès DAA-Hingbanon
Licensed under the GNU General Public License v2 or later.
"""


def classFactory(iface):  # noqa: N802  (QGIS plugin API)
    from .plugin import LimnoToolsPlugin

    return LimnoToolsPlugin(iface)
