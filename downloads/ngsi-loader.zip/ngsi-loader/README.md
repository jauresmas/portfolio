# NGSI Loader

Plugin QGIS pour charger des entités NGSI v2 / NGSI-LD depuis n'importe quel
Context Broker compatible (Stellio, Orion-LD, Scorpio, Orion, ou tout broker
générique conforme au standard) comme couche vecteur.

Le plugin lui-même, sa documentation complète (installation, configuration
par broker, filtres, limites connues) et ses tests se trouvent dans le
dossier [`ngsi_qgis_plugin/`](ngsi_qgis_plugin/).

## Installation rapide

1. Clonez ce dépôt ou téléchargez-le en zip.
2. Copiez le dossier `ngsi_qgis_plugin/` dans votre répertoire de plugins QGIS :
   - Linux : `~/.local/share/QGIS/QGIS3/profiles/default/python/plugins/`
   - Windows : `%APPDATA%\QGIS\QGIS3\profiles\default\python\plugins\`
   - macOS : `~/Library/Application Support/QGIS/QGIS3/profiles/default/python/plugins/`
3. Voir [`ngsi_qgis_plugin/README.md`](ngsi_qgis_plugin/README.md) pour la suite
   (dépendance `requests`, mot de passe maître QGIS, configuration d'un broker).

## Statut du projet

Version de test — recherche activement des retours d'utilisateurs ayant
accès à un vrai Context Broker (Stellio, Orion-LD, Scorpio...). Les
particularités propres à chaque broker sont isolées dans des adaptateurs
dédiés mais n'ont pas encore été confirmées contre de vraies instances —
voir les limites détaillées dans le README du plugin.

Les retours, bugs et suggestions sont les bienvenus via les issues de ce
dépôt.

## Licence

MIT — voir [LICENSE](LICENSE).
