# -*- coding: utf-8 -*-
"""
Conversion d'entités NGSI (v2 ou LD) en FeatureCollection GeoJSON,
indépendante du broker source.
"""
import json
import tempfile
import os

from ..ngsild.parser import parse_ngsild_entities

RESERVED_GEOJSON_PROP_KEYS = {"id", "type"}


def _sanitize_properties(raw_properties, entity_id, entity_type):
    """Place id/type dans properties sans collision, garantit des valeurs JSON-sérialisables."""
    props = {"entity_id": entity_id, "entity_type": entity_type}
    for k, v in raw_properties.items():
        key = k
        if key in RESERVED_GEOJSON_PROP_KEYS:
            key = f"attr_{key}"
        if v is None or isinstance(v, (str, int, float, bool)):
            props[key] = v
        else:
            try:
                props[key] = json.dumps(v, ensure_ascii=False)
            except (TypeError, ValueError):
                props[key] = str(v)
    return props


def build_feature_collection_from_ngsild(entities, include_without_geometry=False):
    """
    entities : liste d'entités NGSI-LD brutes.
    Retourne (feature_collection: dict, stats: dict).
    """
    with_geom, without_geom = parse_ngsild_entities(entities)

    features = []
    for parsed in with_geom:
        features.append({
            "type": "Feature",
            "geometry": parsed.geometry,
            "properties": _sanitize_properties(parsed.properties, parsed.id, parsed.type),
        })

    if include_without_geometry:
        for parsed in without_geom:
            features.append({
                "type": "Feature",
                "geometry": None,
                "properties": _sanitize_properties(parsed.properties, parsed.id, parsed.type),
            })

    stats = {
        "total_received": len(entities),
        "with_geometry": len(with_geom),
        "without_geometry": len(without_geom),
        "included_without_geometry": len(without_geom) if include_without_geometry else 0,
    }
    return {"type": "FeatureCollection", "features": features}, stats


def build_feature_collection_from_ngsiv2(entities, include_without_geometry=False):
    """
    entities : liste d'entités NGSI v2 brutes (mode keyValues ou complet).
    """
    features = []
    with_geom_count = 0
    without_geom_count = 0

    for e in entities:
        if not isinstance(e, dict) or "id" not in e:
            continue

        entity_id = e.get("id")
        entity_type = e.get("type")

        geom = None
        loc = e.get("location")
        if isinstance(loc, dict):
            val = loc.get("value") if "value" in loc else loc
            if isinstance(val, dict) and val.get("type") and "coordinates" in val:
                geom = val

        raw_props = {}
        for k, v in e.items():
            if k in ("location", "id", "type"):
                continue
            if isinstance(v, dict) and "value" in v and "type" in v:
                raw_props[k] = v.get("value")
            else:
                raw_props[k] = v

        if geom is not None:
            with_geom_count += 1
            features.append({
                "type": "Feature",
                "geometry": geom,
                "properties": _sanitize_properties(raw_props, entity_id, entity_type),
            })
        else:
            without_geom_count += 1
            if include_without_geometry:
                features.append({
                    "type": "Feature",
                    "geometry": None,
                    "properties": _sanitize_properties(raw_props, entity_id, entity_type),
                })

    stats = {
        "total_received": len(entities),
        "with_geometry": with_geom_count,
        "without_geometry": without_geom_count,
        "included_without_geometry": without_geom_count if include_without_geometry else 0,
    }
    return {"type": "FeatureCollection", "features": features}, stats


def write_feature_collection_to_tempfile(feature_collection):
    """
    Écrit la FeatureCollection dans un fichier temporaire .geojson et
    retourne son chemin. Recommandé pour les gros volumes.
    """
    fd, path = tempfile.mkstemp(suffix=".geojson", prefix="ngsi_loader_")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(feature_collection, f, ensure_ascii=False)
    except Exception:
        os.unlink(path)
        raise
    return path
