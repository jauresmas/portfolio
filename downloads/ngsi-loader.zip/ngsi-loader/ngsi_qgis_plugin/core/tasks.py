# -*- coding: utf-8 -*-
"""
Tâches QgsTask génériques pour exécuter les appels aux Context Brokers
en arrière-plan, sans jamais bloquer l'interface QGIS.
Ne connaît que l'interface BaseBrokerClient — aucune logique propre à
un broker particulier ici.
"""
from qgis.core import QgsTask, QgsMessageLog, Qgis

from ..brokers.base_broker import BaseBrokerClient
from .broker_client import BrokerError

LOG_TAG = "NGSI Loader"


class BrokerTaskResult:
    """Conteneur simple pour le résultat d'une tâche de broker."""

    def __init__(self, success, data=None, error_message=None):
        self.success = success
        self.data = data
        self.error_message = error_message


class FetchEntitiesTask(QgsTask):
    """
    Tâche générique de récupération d'entités depuis un broker.
    Le broker fourni doit implémenter BaseBrokerClient — cette tâche
    ne sait rien de plus sur lui.
    """

    def __init__(self, description, broker_client, entity_type=None,
                 query_params=None, limit=100, offset=0, on_progress=None):
        """
        broker_client : instance respectant BaseBrokerClient.
        query_params : dict de paramètres additionnels (ex. attrs, georel,
                        geometry, coordinates/coords) transmis tels quels
                        au broker — voir core/spatial_filter.py.
        on_progress : callable(str) optionnel, appelé depuis le thread de
                      la tâche pour signaler un message de progression.
                      Ne doit PAS toucher directement des widgets Qt.
        """
        super().__init__(description, QgsTask.CanCancel)
        if not isinstance(broker_client, BaseBrokerClient):
            raise TypeError("broker_client doit implémenter BaseBrokerClient")
        self.broker_client = broker_client
        self.entity_type = entity_type
        self.query_params = query_params
        self.limit = limit
        self.offset = offset
        self.on_progress = on_progress
        self.result = None  # BrokerTaskResult, rempli par run()

    def run(self):
        """
        Exécuté dans un thread séparé par le gestionnaire de tâches QGIS.
        Ne JAMAIS manipuler de widgets Qt ici — uniquement des données.
        """
        try:
            all_entities = []
            offset = self.offset
            page = 0
            while True:
                if self.isCanceled():
                    self.result = BrokerTaskResult(False, error_message="Annulé par l'utilisateur.")
                    return False

                page += 1
                batch = self.broker_client.get_entities(
                    entity_type=self.entity_type,
                    query_params=self.query_params,
                    limit=self.limit,
                    offset=offset,
                    is_cancelled_cb=self.isCanceled,
                )
                all_entities.extend(batch)

                if self.on_progress:
                    self.on_progress(f"Page {page} récupérée : {len(batch)} entité(s), total {len(all_entities)}.")

                self.setProgress(min(95, page * 10))

                if len(batch) < self.limit:
                    break  # dernière page atteinte
                offset += self.limit

            self.setProgress(100)
            self.result = BrokerTaskResult(True, data=all_entities)
            return True

        except BrokerError as e:
            QgsMessageLog.logMessage(f"Échec de la récupération : {e}", LOG_TAG, Qgis.Warning)
            self.result = BrokerTaskResult(False, error_message=str(e))
            return False
        except Exception as e:  # garde-fou : ne jamais laisser une tâche planter QGIS silencieusement
            QgsMessageLog.logMessage(f"Erreur inattendue dans FetchEntitiesTask : {e}", LOG_TAG, Qgis.Critical)
            self.result = BrokerTaskResult(False, error_message=f"Erreur inattendue : {e}")
            return False

    def finished(self, success):
        """
        Exécuté dans le thread principal par QGIS une fois run() terminé.
        C'est ICI, et seulement ici, qu'il est sûr de toucher l'UI.
        """
        if success and self.result and self.result.success:
            QgsMessageLog.logMessage(
                f"Tâche terminée : {len(self.result.data)} entité(s) au total.", LOG_TAG, Qgis.Success
            )
        else:
            msg = self.result.error_message if self.result else "Échec inconnu."
            QgsMessageLog.logMessage(f"Tâche terminée en échec : {msg}", LOG_TAG, Qgis.Warning)


class TestConnectionTask(QgsTask):
    """Tâche légère pour le bouton « Tester la connexion », en arrière-plan."""

    def __init__(self, description, broker_client):
        super().__init__(description, QgsTask.CanCancel)
        if not isinstance(broker_client, BaseBrokerClient):
            raise TypeError("broker_client doit implémenter BaseBrokerClient")
        self.broker_client = broker_client
        self.result = None  # dict retourné par test_connection()

    def run(self):
        if self.isCanceled():
            return False
        try:
            self.result = self.broker_client.test_connection()
            self.setProgress(100)
            return bool(self.result.get("ok"))
        except Exception as e:
            QgsMessageLog.logMessage(f"Erreur inattendue lors du test de connexion : {e}", LOG_TAG, Qgis.Critical)
            self.result = {"ok": False, "message": f"Erreur inattendue : {e}", "details": None}
            return False

    def finished(self, success):
        if self.result and self.result.get("ok"):
            QgsMessageLog.logMessage("Test de connexion réussi.", LOG_TAG, Qgis.Success)
        else:
            msg = self.result.get("message") if self.result else "Échec inconnu."
            QgsMessageLog.logMessage(f"Test de connexion échoué : {msg}", LOG_TAG, Qgis.Warning)
