# -*- coding: utf-8 -*-
"""
Fabrique centrale : transforme un BrokerProfile en instance concrète
respectant BaseBrokerClient. C'est le SEUL endroit du plugin où le
broker_kind est utilisé pour aiguiller vers un adaptateur.
"""
from .broker_profile import (
    BrokerProfile, BROKER_KIND_GENERIC_LD, BROKER_KIND_GENERIC_V2,
    BROKER_KIND_STELLIO, BROKER_KIND_ORIONLD, BROKER_KIND_SCORPIO,
    BROKER_KIND_CUSTOM,
)
from .broker_client import BrokerError
from ..brokers.generic_adapter import (
    build_generic_ngsild_client, build_generic_ngsiv2_client, build_custom_client,
)
from ..brokers.stellio_adapter import StellioBroker
from ..brokers.orionld_adapter import OrionLDBroker
from ..brokers.scorpio_adapter import ScorpioBroker


def create_broker_client(profile: BrokerProfile):
    """Point d'entrée unique pour obtenir un client à partir d'un profil."""
    if profile.broker_kind == BROKER_KIND_GENERIC_LD:
        return build_generic_ngsild_client(profile)

    if profile.broker_kind == BROKER_KIND_GENERIC_V2:
        return build_generic_ngsiv2_client(profile)

    if profile.broker_kind == BROKER_KIND_STELLIO:
        return StellioBroker(
            profile.base_url, headers=profile.build_headers(),
            timeout=profile.timeout, verify_tls=profile.verify_tls,
            context_link=profile.default_context,
        )

    if profile.broker_kind == BROKER_KIND_ORIONLD:
        return OrionLDBroker(
            profile.base_url, headers=profile.build_headers(),
            timeout=profile.timeout, verify_tls=profile.verify_tls,
            context_link=profile.default_context,
        )

    if profile.broker_kind == BROKER_KIND_SCORPIO:
        return ScorpioBroker(
            profile.base_url, headers=profile.build_headers(),
            timeout=profile.timeout, verify_tls=profile.verify_tls,
            context_link=profile.default_context,
        )

    if profile.broker_kind == BROKER_KIND_CUSTOM:
        return build_custom_client(profile)

    raise BrokerError(f"Type de broker non pris en charge : {profile.broker_kind}")
