# -*- coding: utf-8 -*-
"""
Couche de transport HTTP sécurisée et commune à tous les brokers NGSI.
Ne contient aucune logique NGSI v2 / NGSI-LD : uniquement la sécurisation
et la normalisation des appels HTTP (timeout, TLS, gestion d'erreurs,
masquage des secrets dans les journaux).
"""
import json
from urllib.parse import urlsplit, urlunsplit, urlencode, parse_qsl

try:
    import requests
except ImportError:  # pragma: no cover
    requests = None

from qgis.core import QgsMessageLog, Qgis

LOG_TAG = "NGSI Loader"

DEFAULT_TIMEOUT = 30  # secondes
MAX_RESPONSE_BYTES = 50 * 1024 * 1024  # 50 Mo, garde-fou anti-DoS


class BrokerError(Exception):
    """Erreur générique de communication avec un Context Broker."""


class BrokerConnectionError(BrokerError):
    """Erreur réseau / DNS / connexion refusée."""


class BrokerTimeoutError(BrokerError):
    """Le broker n'a pas répondu dans le délai imparti."""


class BrokerHTTPError(BrokerError):
    """Le broker a répondu avec un code HTTP d'erreur (4xx / 5xx)."""

    def __init__(self, status_code, message, body=None):
        super().__init__(message)
        self.status_code = status_code
        self.body = body


class BrokerResponseError(BrokerError):
    """La réponse du broker n'est pas un JSON valide ou dépasse la taille max."""


def _mask_headers(headers):
    """Retourne une copie des en-têtes avec les secrets masqués, pour les logs."""
    masked = {}
    sensitive = {"authorization", "x-auth-token", "apikey", "api-key"}
    for k, v in (headers or {}).items():
        masked[k] = "***" if k.lower() in sensitive else v
    return masked


def build_url(base_url, path, query_params=None):
    """
    Construit une URL de façon sûre à partir d'une base, d'un chemin et de
    paramètres de requête, en fusionnant proprement avec les paramètres déjà
    présents dans base_url. Aucune concaténation manuelle de chaînes.
    """
    parts = urlsplit(base_url.rstrip("/") + path)
    existing_params = dict(parse_qsl(parts.query))
    if query_params:
        for k, v in query_params.items():
            if v is not None:
                existing_params[k] = v
    new_query = urlencode(existing_params)
    return urlunsplit((parts.scheme, parts.netloc, parts.path, new_query, parts.fragment))


class HttpClient:
    """
    Client HTTP bas niveau partagé par tous les adaptateurs de broker.
    Centralise : timeout, vérification TLS, gestion d'erreurs par code HTTP,
    validation de taille de réponse, journalisation sans fuite de secrets.
    Ne connaît rien à NGSI v2 / NGSI-LD.
    """

    def __init__(self, timeout=DEFAULT_TIMEOUT, verify_tls=True, max_response_bytes=MAX_RESPONSE_BYTES):
        if requests is None:
            raise BrokerError(
                "Le module 'requests' est introuvable dans l'environnement Python de QGIS. "
                "Installez-le via OSGeo4W Shell : python3 -m pip install requests"
            )
        self.timeout = timeout
        self.verify_tls = verify_tls
        self.max_response_bytes = max_response_bytes
        self._session = requests.Session()

    def request(self, method, url, headers=None, json_body=None, params=None, is_cancelled_cb=None):
        """
        Exécute une requête HTTP et retourne le JSON décodé (ou None pour un 204).
        Lève une sous-classe de BrokerError en cas de problème.
        is_cancelled_cb : callable optionnel, retourne True si la tâche appelante
                          (ex. QgsTask) a été annulée entre-temps.
        """
        if not url.lower().startswith(("http://", "https://")):
            raise BrokerError("URL invalide : le schéma doit être http:// ou https://")

        QgsMessageLog.logMessage(
            f"{method} {url} — en-têtes: {_mask_headers(headers)}", LOG_TAG, Qgis.Info
        )

        try:
            resp = self._session.request(
                method=method,
                url=url,
                headers=headers,
                params=params,
                json=json_body,
                timeout=self.timeout,
                verify=self.verify_tls,
                stream=True,
            )
        except requests.exceptions.Timeout as e:
            raise BrokerTimeoutError(f"Délai d'attente dépassé ({self.timeout}s) pour {url}") from e
        except requests.exceptions.SSLError as e:
            raise BrokerConnectionError(f"Erreur de certificat TLS pour {url} : {e}") from e
        except requests.exceptions.ConnectionError as e:
            raise BrokerConnectionError(f"Impossible de se connecter à {url} : {e}") from e
        except requests.exceptions.RequestException as e:
            raise BrokerError(f"Erreur réseau pour {url} : {e}") from e

        if is_cancelled_cb and is_cancelled_cb():
            resp.close()
            raise BrokerError("Requête annulée par l'utilisateur.")

        content_length = resp.headers.get("Content-Length")
        if content_length and int(content_length) > self.max_response_bytes:
            resp.close()
            raise BrokerResponseError(
                f"Réponse trop volumineuse ({content_length} octets, max {self.max_response_bytes})."
            )

        raw = b""
        for chunk in resp.iter_content(chunk_size=65536):
            raw += chunk
            if len(raw) > self.max_response_bytes:
                resp.close()
                raise BrokerResponseError(
                    f"Réponse tronquée : dépassement de la taille max autorisée "
                    f"({self.max_response_bytes} octets)."
                )

        if resp.status_code == 204 or not raw:
            if not (200 <= resp.status_code < 300):
                self._raise_for_status(resp.status_code, raw, url)
            return None

        if not (200 <= resp.status_code < 300):
            self._raise_for_status(resp.status_code, raw, url)

        try:
            return json.loads(raw.decode("utf-8"))
        except (json.JSONDecodeError, UnicodeDecodeError) as e:
            raise BrokerResponseError(f"Réponse non JSON ou mal encodée depuis {url} : {e}") from e

    def _raise_for_status(self, status_code, raw_body, url):
        try:
            body_text = raw_body.decode("utf-8", errors="replace")
        except Exception:
            body_text = "<binaire>"

        messages = {
            400: "Requête invalide (400) — vérifiez les paramètres envoyés au broker.",
            401: "Authentification requise ou invalide (401) — vérifiez le token.",
            403: "Accès refusé (403) — le compte n'a pas les droits nécessaires.",
            404: "Ressource introuvable (404) — vérifiez l'URL ou l'identifiant d'entité.",
            408: "Délai d'attente dépassé côté serveur (408).",
            429: "Trop de requêtes envoyées (429) — ralentissez ou réessayez plus tard.",
            500: "Erreur interne du broker (500).",
        }
        message = messages.get(status_code, f"Le broker a répondu avec le code {status_code}.")
        QgsMessageLog.logMessage(
            f"Erreur HTTP {status_code} sur {url} : {body_text[:500]}", LOG_TAG, Qgis.Warning
        )
        raise BrokerHTTPError(status_code, message, body=body_text)
