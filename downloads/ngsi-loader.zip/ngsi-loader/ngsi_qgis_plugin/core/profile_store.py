# -*- coding: utf-8 -*-
"""
Persistance des profils de broker (hors secrets) via QgsSettings.
Le token n'est JAMAIS stocké ici : seul un auth_cfg_id (référence vers
QgsAuthManager) est conservé.
"""
import json
import re

from qgis.core import QgsSettings, QgsMessageLog, Qgis

from .broker_profile import BrokerProfile
from ..auth.credentials import save_token, load_token, delete_token, CredentialsError

LOG_TAG = "NGSI Loader"
SETTINGS_GROUP = "NGSILoader/profiles"


def _slugify(name):
    slug = re.sub(r"[^a-zA-Z0-9_-]+", "_", name.strip().lower())
    return slug or "profil"


def _settings():
    return QgsSettings()


def list_profile_ids():
    """Retourne la liste des identifiants de profils enregistrés."""
    settings = _settings()
    settings.beginGroup(SETTINGS_GROUP)
    ids = list(settings.childGroups())
    settings.endGroup()
    return ids


def save_profile(profile: BrokerProfile, profile_id=None):
    """
    Enregistre un profil. Le token (profile.token) est extrait et envoyé
    vers QgsAuthManager ; seul l'auth_cfg_id qui en résulte est stocké
    dans QgsSettings avec le reste du profil.
    """
    profile_id = profile_id or _slugify(profile.name)
    settings = _settings()
    settings.beginGroup(f"{SETTINGS_GROUP}/{profile_id}")

    existing_auth_cfg_id = settings.value("auth_cfg_id", None)

    auth_cfg_id = existing_auth_cfg_id
    if profile.token:
        try:
            auth_cfg_id = save_token(
                profile_id, profile.token,
                auth_type=profile.auth_type,
                existing_auth_cfg_id=existing_auth_cfg_id or None,
            )
        except CredentialsError:
            settings.endGroup()
            raise

    settings.setValue("name", profile.name)
    settings.setValue("base_url", profile.base_url)
    settings.setValue("api_version", profile.api_version)
    settings.setValue("broker_kind", profile.broker_kind)
    settings.setValue("api_base_path", profile.api_base_path or "")
    settings.setValue("auth_type", profile.auth_type)
    settings.setValue("custom_headers_json", json.dumps(profile.custom_headers))
    settings.setValue("default_context", profile.default_context or "")
    settings.setValue("timeout", profile.timeout)
    settings.setValue("verify_tls", profile.verify_tls)
    settings.setValue("key_values_v2", profile.key_values_v2)
    settings.setValue("auth_cfg_id", auth_cfg_id or "")
    settings.setValue("supports_pagination", profile.supports_pagination)
    settings.setValue("supports_spatial_filter", profile.supports_spatial_filter)
    settings.setValue("supports_write", profile.supports_write)
    settings.setValue("supports_subscriptions", profile.supports_subscriptions)

    settings.endGroup()
    QgsMessageLog.logMessage(f"Profil '{profile.name}' enregistré (id={profile_id}).", LOG_TAG, Qgis.Info)
    return profile_id


def load_profile(profile_id):
    """Recharge un profil depuis QgsSettings, avec son token depuis QgsAuthManager."""
    settings = _settings()
    settings.beginGroup(f"{SETTINGS_GROUP}/{profile_id}")
    if "name" not in settings.childKeys():
        settings.endGroup()
        return None

    auth_cfg_id = settings.value("auth_cfg_id", "") or None
    auth_type = settings.value("auth_type", "none")
    token = load_token(auth_cfg_id, auth_type=auth_type) if auth_cfg_id else None

    profile = BrokerProfile(
        name=settings.value("name"),
        base_url=settings.value("base_url"),
        api_version=settings.value("api_version", "ngsi-ld"),
        broker_kind=settings.value("broker_kind", "generic_ngsild"),
        api_base_path=settings.value("api_base_path") or None,
        auth_type=auth_type,
        token=token,
        custom_headers=json.loads(settings.value("custom_headers_json", "{}")),
        default_context=settings.value("default_context") or None,
        timeout=int(settings.value("timeout", 30)),
        verify_tls=_to_bool(settings.value("verify_tls", True)),
        key_values_v2=_to_bool(settings.value("key_values_v2", True)),
        supports_pagination=_to_optional_bool(settings.value("supports_pagination", None)),
        supports_spatial_filter=_to_optional_bool(settings.value("supports_spatial_filter", None)),
        supports_write=_to_optional_bool(settings.value("supports_write", None)),
        supports_subscriptions=_to_optional_bool(settings.value("supports_subscriptions", None)),
    )
    settings.endGroup()
    return profile


def delete_profile(profile_id):
    """Supprime un profil et son token associé (si présent)."""
    settings = _settings()
    settings.beginGroup(f"{SETTINGS_GROUP}/{profile_id}")
    auth_cfg_id = settings.value("auth_cfg_id", "") or None
    settings.endGroup()
    settings.remove(f"{SETTINGS_GROUP}/{profile_id}")

    if auth_cfg_id:
        try:
            delete_token(auth_cfg_id)
        except CredentialsError as e:
            QgsMessageLog.logMessage(f"Échec de la suppression du token pour '{profile_id}' : {e}", LOG_TAG, Qgis.Warning)

    QgsMessageLog.logMessage(f"Profil '{profile_id}' supprimé.", LOG_TAG, Qgis.Info)


def _to_bool(value):
    if isinstance(value, bool):
        return value
    return str(value).lower() in ("true", "1", "yes")


def _to_optional_bool(value):
    if value in (None, "", "None"):
        return None
    return _to_bool(value)
