# -*- coding: utf-8 -*-
"""
Construction des paramètres de requête pour le filtrage par attributs et
le filtrage spatial (bbox), indépendante du broker source — les deux
versions (NGSI-LD et NGSI v2) suivent leurs conventions de query params
respectives, toutes deux normalisées ici plutôt que dispersées dans l'UI.

Filtrage spatial : implémenté via une bounding box (rectangle), convertie
en filtre "within" d'un polygone. C'est la forme la plus simple et la
plus largement supportée ; un dessin interactif sur la carte ou d'autres
relations géographiques (near, intersects...) ne sont pas couverts par
cette version et pourraient être ajoutés en étendant ce module sans
toucher au reste du plugin.
"""


def build_attrs_param(attrs_text):
    """
    attrs_text : chaîne saisie par l'utilisateur, ex. "temperature, humidity".
    Retourne la valeur du paramètre 'attrs' (NGSI-LD et NGSI v2 partagent
    ce nom de paramètre et ce format), ou None si rien n'est saisi.
    """
    if not attrs_text or not attrs_text.strip():
        return None
    attrs = [a.strip() for a in attrs_text.split(",") if a.strip()]
    return ",".join(attrs) if attrs else None


def _bbox_to_polygon_coordinates(min_lon, min_lat, max_lon, max_lat):
    """Construit un anneau de polygone GeoJSON fermé à partir d'une bbox."""
    return [[
        [min_lon, min_lat],
        [max_lon, min_lat],
        [max_lon, max_lat],
        [min_lon, max_lat],
        [min_lon, min_lat],
    ]]


def build_spatial_query_params_ngsild(min_lon, min_lat, max_lon, max_lat):
    """
    Retourne un dict de query params NGSI-LD pour une recherche "within"
    (entités dont la géométrie est contenue dans la bbox donnée) :
    georel=within, geometry=Polygon, coordinates=<GeoJSON coords sérialisées>.
    """
    import json
    coords = _bbox_to_polygon_coordinates(min_lon, min_lat, max_lon, max_lat)
    return {
        "georel": "within",
        "geometry": "Polygon",
        "coordinates": json.dumps(coords),
    }


def build_spatial_query_params_ngsiv2(min_lon, min_lat, max_lon, max_lat):
    """
    Retourne un dict de query params NGSI v2 pour une recherche "coveredBy"
    (équivalent v2 d'une bbox) : georel=coveredBy, geometry=polygon,
    coords="lat1,lon1;lat2,lon2;...". NGSI v2 attend l'ordre lat,lon
    (inverse de GeoJSON) et un anneau non forcément refermé.
    """
    ring = _bbox_to_polygon_coordinates(min_lon, min_lat, max_lon, max_lat)[0][:-1]  # sans le point de fermeture
    coords_str = ";".join(f"{lat},{lon}" for lon, lat in ring)
    return {
        "georel": "coveredBy",
        "geometry": "polygon",
        "coords": coords_str,
    }


def validate_bbox(min_lon, min_lat, max_lon, max_lat):
    """
    Valide une bbox WGS84 simple. Retourne (ok: bool, message: str|None).
    Ne prétend pas gérer l'antiméridien ou des systèmes de coordonnées
    autres que WGS84 (limite assumée, cohérente avec l'usage GeoJSON
    déjà fait dans le reste du plugin).
    """
    if None in (min_lon, min_lat, max_lon, max_lat):
        return False, "Les 4 coordonnées de la zone (bbox) sont requises."
    if not (-180 <= min_lon <= 180 and -180 <= max_lon <= 180):
        return False, "Longitude hors de la plage valide (-180 à 180)."
    if not (-90 <= min_lat <= 90 and -90 <= max_lat <= 90):
        return False, "Latitude hors de la plage valide (-90 à 90)."
    if min_lon >= max_lon or min_lat >= max_lat:
        return False, "La bbox doit avoir min < max pour la longitude et la latitude."
    return True, None
