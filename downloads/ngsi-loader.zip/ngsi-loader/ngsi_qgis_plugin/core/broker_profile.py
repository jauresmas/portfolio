# -*- coding: utf-8 -*-
"""
Définition d'un profil de connexion à un Context Broker.
Un profil décrit COMMENT se connecter (URL, version, auth, particularités),
jamais la logique de communication elle-même (voir broker_factory.py et
les adaptateurs dans brokers/).
"""
from dataclasses import dataclass, field
from typing import Optional, Dict

BROKER_KIND_GENERIC_LD = "generic_ngsild"
BROKER_KIND_GENERIC_V2 = "generic_ngsiv2"
BROKER_KIND_STELLIO = "stellio"
BROKER_KIND_ORIONLD = "orionld"
BROKER_KIND_SCORPIO = "scorpio"
BROKER_KIND_CUSTOM = "custom"

VALID_BROKER_KINDS = {
    BROKER_KIND_GENERIC_LD, BROKER_KIND_GENERIC_V2, BROKER_KIND_STELLIO,
    BROKER_KIND_ORIONLD, BROKER_KIND_SCORPIO, BROKER_KIND_CUSTOM,
}

API_VERSION_NGSI_LD = "ngsi-ld"
API_VERSION_NGSI_V2 = "ngsi-v2"


@dataclass
class BrokerProfile:
    """
    Profil de connexion complet. Tous les champs non liés à l'identité du
    broker (kind, name) sont volontairement neutres : ce sont eux qui
    pilotent le comportement, pas des conditions dispersées dans le code.
    """
    name: str
    base_url: str
    api_version: str = API_VERSION_NGSI_LD          # "ngsi-ld" ou "ngsi-v2"
    broker_kind: str = BROKER_KIND_GENERIC_LD         # une valeur de VALID_BROKER_KINDS
    api_base_path: Optional[str] = None               # ex. "/ngsi-ld/v1" si non standard
    auth_type: str = "none"                            # "none" | "bearer" | "apikey" | "custom"
    token: Optional[str] = None                        # jamais stocké en dur dans le code appelant
    custom_headers: Dict[str, str] = field(default_factory=dict)
    supports_pagination: Optional[bool] = None          # None = inconnu, à détecter
    supports_spatial_filter: Optional[bool] = None
    supports_write: Optional[bool] = None
    supports_subscriptions: Optional[bool] = None
    default_context: Optional[str] = None               # URL du contexte JSON-LD par défaut
    timeout: int = 30
    verify_tls: bool = True
    key_values_v2: bool = True                          # pertinent seulement si api_version == ngsi-v2

    def __post_init__(self):
        if self.broker_kind not in VALID_BROKER_KINDS:
            raise ValueError(
                f"broker_kind invalide : {self.broker_kind!r}. "
                f"Valeurs autorisées : {sorted(VALID_BROKER_KINDS)}"
            )
        if not self.base_url or not self.base_url.lower().startswith(("http://", "https://")):
            raise ValueError("base_url doit commencer par http:// ou https://")

    def build_headers(self):
        """Construit les en-têtes HTTP à partir du profil, sans jamais logger le token en clair."""
        headers = dict(self.custom_headers)
        if self.auth_type == "bearer" and self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        elif self.auth_type == "apikey" and self.token:
            headers["X-Auth-Token"] = self.token
        # "custom" : on suppose que le token/les en-têtes nécessaires sont déjà dans custom_headers
        return headers


# Profils prédéfinis, utilisables tels quels ou comme point de départ pour "Custom Broker".
# Le base_url et le token restent à renseigner par l'utilisateur dans tous les cas —
# ces gabarits ne contiennent aucun identifiant ni URL réelle.
PREDEFINED_PROFILE_TEMPLATES = {
    "Generic NGSI-LD": dict(broker_kind=BROKER_KIND_GENERIC_LD, api_version=API_VERSION_NGSI_LD),
    "Generic NGSI v2": dict(broker_kind=BROKER_KIND_GENERIC_V2, api_version=API_VERSION_NGSI_V2),
    "Stellio": dict(broker_kind=BROKER_KIND_STELLIO, api_version=API_VERSION_NGSI_LD),
    "Orion-LD": dict(broker_kind=BROKER_KIND_ORIONLD, api_version=API_VERSION_NGSI_LD),
    "Scorpio": dict(broker_kind=BROKER_KIND_SCORPIO, api_version=API_VERSION_NGSI_LD),
    "Custom Broker": dict(broker_kind=BROKER_KIND_CUSTOM, api_version=API_VERSION_NGSI_LD),
}
