# -*- coding: utf-8 -*-
"""
Détection active des capacités d'un Context Broker.
Complète (sans jamais écraser silencieusement) les capacités déclarées
par un adaptateur par des constats mesurés en interrogeant réellement
le broker.
"""
from ..brokers.base_broker import BaseBrokerClient
from .broker_client import BrokerError, BrokerHTTPError

LOG_TAG = "NGSI Loader"


class DetectedCapabilities:
    """
    Résultat de la détection. Chaque champ vaut True/False si mesuré avec
    confiance, ou None si non testable / test ayant échoué sans conclusion
    exploitable.
    """

    def __init__(self):
        self.reachable = None
        self.pagination = None
        self.spatial_filter = None
        self.write_operations = None
        self.subscriptions = None
        self.content_type_returned = None
        self.requires_context_link = None
        self.notes = []

    def as_dict(self):
        return {
            "reachable": self.reachable,
            "pagination": self.pagination,
            "spatial_filter": self.spatial_filter,
            "write_operations": self.write_operations,
            "subscriptions": self.subscriptions,
            "content_type_returned": self.content_type_returned,
            "requires_context_link": self.requires_context_link,
            "notes": self.notes,
        }


def detect_capabilities(broker_client, http_client=None, entities_url=None, headers=None,
                         test_entity_type=None, allow_write_probe=False):
    """
    broker_client : instance BaseBrokerClient déjà construite (via broker_factory).
    allow_write_probe : False par défaut. Si True, autorise un test d'écriture
        RÉEL et EXPLICITEMENT CONSENTI par l'utilisateur (création puis
        suppression immédiate d'une entité de test). Ne jamais activer sans
        confirmation explicite de l'utilisateur dans l'UI.
    """
    if not isinstance(broker_client, BaseBrokerClient):
        raise TypeError("broker_client doit implémenter BaseBrokerClient")

    caps = DetectedCapabilities()

    _detect_reachability(broker_client, caps)
    if not caps.reachable:
        caps.notes.append("Broker injoignable — les autres capacités n'ont pas pu être testées.")
        return caps

    _detect_pagination(broker_client, caps)
    _detect_content_type(http_client, entities_url, headers, caps)

    if allow_write_probe:
        _detect_write_support(broker_client, caps, test_entity_type=test_entity_type)
    else:
        caps.notes.append(
            "Support de l'écriture non testé (allow_write_probe=False) — "
            "activez-le uniquement après consentement explicite de l'utilisateur."
        )

    caps.notes.append(
        "Filtrage spatial et abonnements non testés activement : "
        "capacité laissée à None faute de méthode de test fiable et non intrusive."
    )

    return caps


def _detect_reachability(broker_client, caps):
    try:
        result = broker_client.test_connection()
        caps.reachable = bool(result.get("ok"))
        if not caps.reachable:
            caps.notes.append(f"Test de connexion échoué : {result.get('message')}")
    except BrokerError as e:
        caps.reachable = False
        caps.notes.append(f"Erreur lors du test de connexion : {e}")


def _detect_pagination(broker_client, caps):
    try:
        page1 = broker_client.get_entities(limit=1, offset=0)
        page2 = broker_client.get_entities(limit=1, offset=1)
    except BrokerError as e:
        caps.pagination = None
        caps.notes.append(f"Test de pagination impossible : {e}")
        return

    if not page1:
        caps.pagination = None
        caps.notes.append("Aucune entité disponible : pagination non testable.")
        return

    if not page2:
        caps.pagination = None
        caps.notes.append("Une seule entité disponible chez ce broker : pagination non conclusive.")
        return

    id1 = page1[0].get("id") if isinstance(page1[0], dict) else None
    id2 = page2[0].get("id") if isinstance(page2[0], dict) else None
    caps.pagination = bool(id1 and id2 and id1 != id2)
    if not caps.pagination:
        caps.notes.append(
            "offset=1 n'a pas renvoyé une entité différente d'offset=0 : "
            "la pagination pourrait ne pas être supportée telle quelle."
        )


def _detect_content_type(http_client, entities_url, headers, caps):
    if http_client is None or entities_url is None:
        caps.notes.append("Détection du Content-Type ignorée (accès bas niveau non fourni).")
        return
    try:
        resp = http_client._session.get(
            entities_url, headers=headers, params={"limit": 1},
            timeout=http_client.timeout, verify=http_client.verify_tls,
        )
        caps.content_type_returned = resp.headers.get("Content-Type")
    except Exception as e:
        caps.notes.append(f"Détection du Content-Type impossible : {e}")


def _detect_write_support(broker_client, caps, test_entity_type=None):
    """
    ATTENTION : crée réellement une entité de test sur le broker puis tente
    de la supprimer immédiatement. Ne doit JAMAIS être exécuté sans
    consentement explicite de l'utilisateur.
    """
    test_id = "urn:ngsi-ld:NGSILoaderCapabilityProbe:001"
    test_entity = {
        "id": test_id,
        "type": test_entity_type or "NGSILoaderCapabilityProbe",
    }
    try:
        broker_client.create_entity(test_entity)
    except BrokerHTTPError as e:
        caps.write_operations = False
        caps.notes.append(f"Écriture non autorisée par le broker (HTTP {e.status_code}).")
        return
    except BrokerError as e:
        caps.write_operations = None
        caps.notes.append(f"Test d'écriture non conclusif : {e}")
        return

    caps.write_operations = True
    try:
        broker_client.delete_entity(test_id)
        caps.notes.append("Test d'écriture réussi ; entité de test créée puis supprimée avec succès.")
    except BrokerError as e:
        caps.notes.append(
            f"Entité de test '{test_id}' créée mais NON supprimée automatiquement "
            f"(erreur : {e}) — une suppression manuelle sur le broker peut être nécessaire."
        )
