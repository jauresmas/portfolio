# NGSI Loader — Plugin QGIS multi-brokers

Plugin QGIS permettant de connecter QGIS à **n'importe quel Context Broker conforme aux standards NGSI v2 ou NGSI-LD** (ETSI GS CIM 009), et de charger ses entités comme couche vecteur.

Le plugin ne dépend d'aucun broker en particulier : il repose sur les **standards NGSI v2, NGSI-LD, JSON-LD et GeoJSON**. Des adaptateurs dédiés isolent les particularités connues de certains brokers courants, sans jamais rendre le cœur du plugin dépendant d'un produit précis.

## Brokers compatibles

- **Stellio**
- **Orion-LD**
- **Scorpio Broker**
- **Orion Context Broker** (NGSI v2)
- Tout autre broker conforme NGSI v2 ou NGSI-LD, via le profil **Custom Broker**

## Fonctionnalités

**NGSI v2**
- Récupération d'entités (`GET /v2/entities`), mode `keyValues` optionnel
- Pagination (`limit`/`offset`)
- Liste des types d'entités

**NGSI-LD**
- Récupération d'entités (`GET /ngsi-ld/v1/entities`)
- Gestion explicite de `Property`, `GeoProperty`, `Relationship`
- Normalisation minimale du `@context` (limite documentée ci-dessous)
- Création / modification / suppression d'entités (`POST`/`PATCH`/`DELETE`), désactivées si le broker ne les supporte pas
- En-tête `Link` pour le contexte JSON-LD quand le broker l'exige (ex. Orion-LD)

**Filtres**
- Par type d'entité
- Par attributs (liste d'attributs à récupérer, paramètre `attrs`)
- Spatial : zone rectangulaire (bbox WGS84), traduite en `georel=within`/`coveredBy` selon la version d'API

**Commun**
- Exécution en arrière-plan via `QgsTask` — **l'interface QGIS n'est jamais bloquée**
- Test de connexion et détection active des capacités du broker
- Profils de connexion réutilisables, avec token stocké de façon sécurisée via `QgsAuthManager` (jamais en clair), authentification Bearer ou clé API (`X-Auth-Token`)
- Conversion générique vers GeoJSON, avec statistiques explicites (entités avec/sans géométrie)
- Journal visible dans l'interface

## Installation

1. Copiez le dossier `ngsi_qgis_plugin` dans votre répertoire de plugins QGIS :
   - Linux : `~/.local/share/QGIS/QGIS3/profiles/default/python/plugins/`
   - Windows : `%APPDATA%\QGIS\QGIS3\profiles\default\python\plugins\`
   - macOS : `~/Library/Application Support/QGIS/QGIS3/profiles/default/python/plugins/`
2. Assurez-vous que `requests` est disponible dans l'environnement Python de QGIS (OSGeo4W Shell : `python3 -m pip install requests`).
3. Configurez un **mot de passe maître** QGIS (`Préférences > Authentification`) — requis pour l'enregistrement sécurisé des tokens.
4. Démarrez ou redémarrez QGIS → **Extensions > Installer/Gérer les extensions** → activez **NGSI Loader**.

## Configuration d'un broker

Ouvrez **NGSI Loader** depuis le menu Extensions ou la barre d'outils. Renseignez :
- **Type de broker** : sélectionnez un profil prédéfini ou « Custom Broker »
- **Version API** : NGSI-LD ou NGSI v2
- **URL du broker**
- **Authentification** : aucune, Bearer, clé API, ou en-têtes personnalisés
- **Contexte JSON-LD** (recommandé pour Orion-LD)

Cliquez sur **Tester la connexion**, puis **Détecter les capacités** pour vérifier ce que le broker supporte réellement avant de charger des données.

### Configuration Stellio
Renseignez l'URL de base de votre instance Stellio. Le contexte JSON-LD par défaut suffit généralement.

### Configuration Orion-LD
Le champ **Contexte JSON-LD** est **obligatoire** si vos entités n'embarquent pas leur propre `@context` — le plugin refuse la connexion avec un message explicite sinon.

### Configuration Scorpio
Aucune particularité imposée par défaut ; ajustez les en-têtes personnalisés si votre déploiement l'exige.

### Configuration d'un broker personnalisé (Custom Broker)
Sélectionnez « Custom Broker », choisissez la version API, renseignez l'URL et les en-têtes nécessaires — aucune modification de code requise.

## Exemples d'URL

- NGSI v2 : `https://broker.example.org/v2/entities?type=Sensor`
- NGSI-LD : `https://broker.example.org/ngsi-ld/v1/entities`

## Configuration du token

Le token est stocké via `QgsAuthManager` (coffre-fort chiffré), jamais dans le fichier de configuration QGIS ni dans le code. Enregistrez-le une fois via le champ « Token / clé API » puis « Enregistrer le profil » — il sera automatiquement rechargé aux sessions suivantes.

## Filtres

- **Type d'entité** : champ simple, transmis tel quel au broker.
- **Attributs** : liste séparée par des virgules (ex. `temperature, humidity`) — seuls ces attributs sont demandés au broker.
- **Filtre spatial** : cochez « Activer » et renseignez une bbox (longitude/latitude min et max, WGS84). Traduit en filtre "within"/"coveredBy" — les relations spatiales plus avancées (near, intersects...) ou un dessin interactif sur la carte ne sont pas couverts par cette version.

## Limites connues

- La résolution du `@context` JSON-LD reste **partielle** (pas d'expansion/compaction complète au sens de la spec JSON-LD, pour éviter une dépendance externe) — les attributs utilisant un vocabulaire personnalisé non standard peuvent apparaître sous leur forme brute.
- La détection du filtrage spatial et des abonnements n'est pas testée activement (aucune méthode fiable non intrusive identifiée) — ces capacités restent affichées comme « non déterminées ».
- Le filtre spatial ne couvre que la relation "contenu dans une bbox" (WGS84) — pas de dessin interactif, pas d'autres relations géographiques.
- Le test d'écriture (case à cocher dédiée) crée puis supprime une entité de test réelle sur le broker — à n'activer que sur un environnement de test.
- Une seule géométrie par entité est représentée dans QGIS (limite du modèle vecteur) ; les `GeoProperty` additionnelles sont conservées en attribut sérialisé.
- Pas de boutons dédiés création/modification/suppression d'entité dans l'UI (l'API `BaseBrokerClient` le permet déjà en programmatique) ; pas de gestion des abonnements NGSI-LD.

## Tests

Tests unitaires avec `pytest`, utilisant des mocks (aucun broker réel requis) :

```bash
pip install pytest --break-system-packages
pytest ngsi_qgis_plugin/tests/
```

Certains tests importent `qgis.core` (via les modules `core`/`auth`) : exécutez-les idéalement depuis la console Python de QGIS ou un environnement disposant de PyQGIS.

## Architecture

```
ngsi_qgis_plugin/
├── ui/            interface QGIS (Qt), aucune logique métier
├── core/          transport HTTP, tâches QgsTask, profils, fabrique,
│                  détection de capacités, filtres spatiaux/attributs
├── brokers/       interface commune + adaptateurs par broker
├── ngsild/        parseur NGSI-LD, normalisation du contexte
├── geo/           conversion vers GeoJSON
├── auth/          intégration QgsAuthManager
└── tests/         tests unitaires (pytest, mocks)
```

## Contribution

Les contributions sont bienvenues, en particulier pour confirmer ou corriger les particularités des adaptateurs de broker (marquées `# À VÉRIFIER` dans le code) contre des instances réelles. Merci d'accompagner toute correction d'un test dans `tests/`.

## Licence

MIT
