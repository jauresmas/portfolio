# -*- coding: utf-8 -*-
"""
Stockage sécurisé des tokens via QgsAuthManager (coffre-fort chiffré
natif de QGIS, protégé par le mot de passe maître de l'utilisateur).
Aucun token n'est jamais écrit dans QgsSettings ni dans un fichier en
clair.
"""
from qgis.core import QgsApplication, QgsAuthMethodConfig, QgsMessageLog, Qgis

LOG_TAG = "NGSI Loader"
AUTH_CONFIG_NAME_PREFIX = "NGSI Loader - "

AUTH_HEADER_NAMES = {
    "bearer": "Authorization",
    "apikey": "X-Auth-Token",
}


class CredentialsError(Exception):
    """Erreur lors du stockage/récupération d'un identifiant."""


def _auth_manager():
    manager = QgsApplication.authManager()
    if manager is None:
        raise CredentialsError("Le gestionnaire d'authentification QGIS n'est pas disponible.")
    if not manager.isDisabled():
        return manager
    raise CredentialsError(
        "Le système d'authentification QGIS est désactivé. "
        "Configurez un mot de passe maître dans QGIS (Préférences > Authentification) "
        "avant d'enregistrer un token."
    )


def save_token(profile_id, token, auth_type="bearer", existing_auth_cfg_id=None):
    """
    Enregistre (ou met à jour) un token dans QgsAuthManager, associé à
    profile_id. auth_type détermine l'en-tête HTTP produit :
        "bearer" -> "Authorization: Bearer <token>"
        "apikey" -> "X-Auth-Token: <token>"
    Retourne l'auth_cfg_id à conserver dans le profil — jamais le token lui-même.
    """
    if not token:
        raise CredentialsError("Token vide : rien à enregistrer.")
    if auth_type not in AUTH_HEADER_NAMES:
        raise CredentialsError(
            f"auth_type non pris en charge pour le stockage de token : {auth_type!r} "
            f"(valeurs gérées : {sorted(AUTH_HEADER_NAMES)})"
        )

    manager = _auth_manager()
    header_name = AUTH_HEADER_NAMES[auth_type]
    header_value = f"Bearer {token}" if auth_type == "bearer" else token

    auth_config = QgsAuthMethodConfig()
    auth_config.setName(f"{AUTH_CONFIG_NAME_PREFIX}{profile_id}")
    auth_config.setMethod("APIHeader")
    auth_config.setConfigMap({"headers": f"{header_name}: {header_value}"})

    if existing_auth_cfg_id:
        auth_config.setId(existing_auth_cfg_id)
        ok = manager.updateAuthenticationConfig(auth_config)
    else:
        ok = manager.storeAuthenticationConfig(auth_config)

    if not ok:
        raise CredentialsError("Échec de l'enregistrement du token dans QgsAuthManager.")

    QgsMessageLog.logMessage(
        f"Token enregistré pour le profil '{profile_id}' (type={auth_type}, valeur masquée).",
        LOG_TAG, Qgis.Info
    )
    return auth_config.id()


def load_token(auth_cfg_id, auth_type="bearer"):
    """
    Récupère le token associé à un auth_cfg_id, en tenant compte du format
    d'en-tête attendu selon auth_type. Retourne None si absent.
    """
    if not auth_cfg_id:
        return None
    if auth_type not in AUTH_HEADER_NAMES:
        return None

    manager = _auth_manager()
    auth_config = QgsAuthMethodConfig()
    if not manager.loadAuthenticationConfig(auth_cfg_id, auth_config, full=True):
        return None

    header_name = AUTH_HEADER_NAMES[auth_type].lower()
    headers_raw = auth_config.configMap().get("headers", "")
    for line in headers_raw.splitlines():
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        if key.strip().lower() != header_name:
            continue
        value = value.strip()
        if auth_type == "bearer" and value.lower().startswith("bearer "):
            return value.split(" ", 1)[1]
        if auth_type == "apikey":
            return value
    return None


def delete_token(auth_cfg_id):
    """Supprime un token du coffre-fort. Ne lève pas d'exception si déjà absent."""
    if not auth_cfg_id:
        return True
    manager = _auth_manager()
    return manager.removeAuthenticationConfig(auth_cfg_id)
