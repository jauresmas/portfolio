# -*- coding: utf-8 -*-
from ngsi_qgis_plugin.geo.geojson_builder import (
    build_feature_collection_from_ngsild, build_feature_collection_from_ngsiv2,
)

NGSILD_ENTITY = {
    "id": "urn:ngsi-ld:Sensor:001",
    "type": "Sensor",
    "location": {"type": "GeoProperty", "value": {"type": "Point", "coordinates": [2.35, 48.85]}},
    "temperature": {"type": "Property", "value": 21.5},
}

NGSIV2_ENTITY = {
    "id": "Sensor:001",
    "type": "Sensor",
    "location": {"type": "geo:json", "value": {"type": "Point", "coordinates": [2.35, 48.85]}},
    "temperature": {"type": "Number", "value": 21.5, "metadata": {}},
}


def test_ngsild_feature_collection_valid():
    fc, stats = build_feature_collection_from_ngsild([NGSILD_ENTITY])
    assert fc["type"] == "FeatureCollection"
    assert len(fc["features"]) == 1
    assert stats["with_geometry"] == 1
    assert fc["features"][0]["properties"]["entity_id"] == "urn:ngsi-ld:Sensor:001"


def test_ngsiv2_feature_collection_valid():
    fc, stats = build_feature_collection_from_ngsiv2([NGSIV2_ENTITY])
    assert len(fc["features"]) == 1
    assert stats["with_geometry"] == 1
    assert fc["features"][0]["geometry"]["coordinates"] == [2.35, 48.85]


def test_no_geometry_excluded_by_default():
    entity = {"id": "urn:ngsi-ld:X:1", "type": "X"}
    fc, stats = build_feature_collection_from_ngsild([entity], include_without_geometry=False)
    assert len(fc["features"]) == 0
    assert stats["without_geometry"] == 1


def test_no_geometry_included_when_requested():
    entity = {"id": "urn:ngsi-ld:X:1", "type": "X"}
    fc, stats = build_feature_collection_from_ngsild([entity], include_without_geometry=True)
    assert len(fc["features"]) == 1
    assert fc["features"][0]["geometry"] is None
