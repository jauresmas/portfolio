# -*- coding: utf-8 -*-
import json
from ngsi_qgis_plugin.core.spatial_filter import (
    build_attrs_param, build_spatial_query_params_ngsild,
    build_spatial_query_params_ngsiv2, validate_bbox,
)


def test_build_attrs_param_strips_and_joins():
    assert build_attrs_param(" temperature ,  humidity") == "temperature,humidity"


def test_build_attrs_param_empty_returns_none():
    assert build_attrs_param("   ") is None
    assert build_attrs_param("") is None


def test_validate_bbox_rejects_inverted_bounds():
    ok, message = validate_bbox(10, 10, 5, 20)
    assert ok is False
    assert message is not None


def test_validate_bbox_rejects_out_of_range_longitude():
    ok, message = validate_bbox(-200, 10, 5, 20)
    assert ok is False


def test_validate_bbox_accepts_valid_box():
    ok, message = validate_bbox(2.0, 48.0, 3.0, 49.0)
    assert ok is True
    assert message is None


def test_ngsild_spatial_params_shape():
    params = build_spatial_query_params_ngsild(2.0, 48.0, 3.0, 49.0)
    assert params["georel"] == "within"
    assert params["geometry"] == "Polygon"
    coords = json.loads(params["coordinates"])
    assert coords[0][0] == [2.0, 48.0]  # premier point = coin min


def test_ngsiv2_spatial_params_shape():
    params = build_spatial_query_params_ngsiv2(2.0, 48.0, 3.0, 49.0)
    assert params["georel"] == "coveredBy"
    assert params["geometry"] == "polygon"
    assert "48.0,2.0" in params["coords"]  # ordre lat,lon attendu par NGSI v2
