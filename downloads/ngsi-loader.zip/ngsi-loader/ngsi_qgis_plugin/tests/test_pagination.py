# -*- coding: utf-8 -*-
"""
Vérifie la pagination automatique de FetchEntitiesTask avec plus de 100
entités réparties sur plusieurs pages — non couvert par les autres tests,
qui utilisent des jeux de données volontairement petits.
"""
from unittest.mock import patch, MagicMock
import json

from ngsi_qgis_plugin.core.tasks import FetchEntitiesTask
from ngsi_qgis_plugin.brokers.ngsild_broker import GenericNGSILDBroker


def _make_paged_response_side_effect(total):
    """
    Simule un vrai serveur HTTP paginé : à chaque appel, lit params['offset']
    et params['limit'] pour renvoyer la bonne tranche, comme le ferait un
    vrai broker NGSI-LD.
    """
    def _side_effect(method, url, headers=None, params=None, json=None, timeout=None, verify=None, stream=None):
        import json as json_module
        offset = int((params or {}).get("offset", 0) or 0)
        limit = int((params or {}).get("limit", 100) or 100)
        remaining = max(0, total - offset)
        page_size = min(limit, remaining)
        entities = [{"id": f"urn:ngsi-ld:E:{offset + i}", "type": "E"} for i in range(page_size)]
        resp = MagicMock()
        resp.status_code = 200
        resp.headers = {}
        body = json_module.dumps(entities).encode("utf-8")
        resp.iter_content = MagicMock(return_value=[body])
        return resp
    return _side_effect


@patch("ngsi_qgis_plugin.core.broker_client.requests")
def test_pagination_collects_all_entities_across_multiple_pages(mock_requests):
    mock_requests.Session.return_value.request.side_effect = _make_paged_response_side_effect(total=250)
    broker = GenericNGSILDBroker("https://broker.example.org")

    task = FetchEntitiesTask("test", broker, limit=100)
    task.run()

    assert task.result.success is True
    assert len(task.result.data) == 250
    ids = {e["id"] for e in task.result.data}
    assert len(ids) == 250  # pas de doublons entre pages


@patch("ngsi_qgis_plugin.core.broker_client.requests")
def test_pagination_stops_exactly_on_page_boundary(mock_requests):
    """Cas limite : le total est un multiple exact de la taille de page (200 = 2x100)."""
    mock_requests.Session.return_value.request.side_effect = _make_paged_response_side_effect(total=200)
    broker = GenericNGSILDBroker("https://broker.example.org")

    task = FetchEntitiesTask("test", broker, limit=100)
    task.run()

    assert task.result.success is True
    assert len(task.result.data) == 200
