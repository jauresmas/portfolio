# -*- coding: utf-8 -*-
"""
Tests consolidés pour les adaptateurs Stellio / Orion-LD / Scorpio et
pour la fabrique.
"""
import pytest

from ngsi_qgis_plugin.core.broker_profile import (
    BrokerProfile, BROKER_KIND_STELLIO, BROKER_KIND_ORIONLD, BROKER_KIND_SCORPIO,
    BROKER_KIND_GENERIC_LD, BROKER_KIND_CUSTOM, API_VERSION_NGSI_LD, API_VERSION_NGSI_V2,
)
from ngsi_qgis_plugin.core.broker_factory import create_broker_client
from ngsi_qgis_plugin.core.broker_client import BrokerError
from ngsi_qgis_plugin.brokers.stellio_adapter import StellioBroker
from ngsi_qgis_plugin.brokers.orionld_adapter import OrionLDBroker
from ngsi_qgis_plugin.brokers.scorpio_adapter import ScorpioBroker


def test_factory_returns_stellio_broker_instance():
    profile = BrokerProfile(name="t", base_url="https://x.org", broker_kind=BROKER_KIND_STELLIO)
    client = create_broker_client(profile)
    assert isinstance(client, StellioBroker)


def test_factory_returns_scorpio_broker_instance():
    profile = BrokerProfile(name="t", base_url="https://x.org", broker_kind=BROKER_KIND_SCORPIO)
    client = create_broker_client(profile)
    assert isinstance(client, ScorpioBroker)


def test_orionld_requires_context_link():
    profile = BrokerProfile(
        name="t", base_url="https://x.org", broker_kind=BROKER_KIND_ORIONLD, default_context=None
    )
    with pytest.raises(BrokerError):
        create_broker_client(profile)


def test_orionld_succeeds_with_context_link():
    profile = BrokerProfile(
        name="t", base_url="https://x.org", broker_kind=BROKER_KIND_ORIONLD,
        default_context="https://uri.etsi.org/ngsi-ld/v1/ngsi-ld-core-context.jsonld",
    )
    client = create_broker_client(profile)
    assert isinstance(client, OrionLDBroker)


def test_custom_broker_uses_declared_api_version():
    profile_ld = BrokerProfile(
        name="t", base_url="https://x.org", broker_kind=BROKER_KIND_CUSTOM, api_version=API_VERSION_NGSI_LD
    )
    profile_v2 = BrokerProfile(
        name="t", base_url="https://x.org", broker_kind=BROKER_KIND_CUSTOM, api_version=API_VERSION_NGSI_V2
    )
    from ngsi_qgis_plugin.brokers.ngsild_broker import GenericNGSILDBroker
    from ngsi_qgis_plugin.brokers.ngsiv2_broker import GenericNGSIv2Broker
    assert isinstance(create_broker_client(profile_ld), GenericNGSILDBroker)
    assert isinstance(create_broker_client(profile_v2), GenericNGSIv2Broker)


def test_invalid_base_url_rejected_at_profile_level():
    with pytest.raises(ValueError):
        BrokerProfile(name="t", base_url="broker.example.org", broker_kind=BROKER_KIND_GENERIC_LD)


def test_stellio_capabilities_differ_from_generic_default():
    profile = BrokerProfile(name="t", base_url="https://x.org", broker_kind=BROKER_KIND_STELLIO)
    client = create_broker_client(profile)
    caps = client.get_capabilities()
    assert caps["subscriptions"] is True
