# -*- coding: utf-8 -*-
from unittest.mock import patch, MagicMock
import pytest

from ngsi_qgis_plugin.brokers.ngsild_broker import GenericNGSILDBroker
from ngsi_qgis_plugin.brokers.ngsiv2_broker import GenericNGSIv2Broker
from ngsi_qgis_plugin.core.broker_client import BrokerError, BrokerHTTPError, BrokerTimeoutError


def _mock_response(status_code=200, json_body=None, headers=None):
    resp = MagicMock()
    resp.status_code = status_code
    resp.headers = headers or {}
    body = b"" if json_body is None else __import__("json").dumps(json_body).encode("utf-8")
    resp.iter_content = MagicMock(return_value=[body])
    return resp


@patch("ngsi_qgis_plugin.core.broker_client.requests")
def test_ngsild_get_entities_success(mock_requests):
    mock_requests.Session.return_value.request.return_value = _mock_response(
        200, [{"id": "urn:ngsi-ld:A:1", "type": "A"}]
    )
    client = GenericNGSILDBroker("https://broker.example.org")
    entities = client.get_entities(limit=10)
    assert len(entities) == 1
    assert entities[0]["id"] == "urn:ngsi-ld:A:1"


@patch("ngsi_qgis_plugin.core.broker_client.requests")
def test_ngsild_401_raises_broker_http_error(mock_requests):
    mock_requests.Session.return_value.request.return_value = _mock_response(401, {"error": "unauthorized"})
    client = GenericNGSILDBroker("https://broker.example.org")
    with pytest.raises(BrokerHTTPError) as exc:
        client.get_entities()
    assert exc.value.status_code == 401


@patch("ngsi_qgis_plugin.core.broker_client.requests")
def test_ngsiv2_get_entity_types(mock_requests):
    mock_requests.Session.return_value.request.return_value = _mock_response(
        200, [{"type": "Sensor", "count": 3}]
    )
    client = GenericNGSIv2Broker("https://broker.example.org")
    types = client.get_entity_types()
    assert types == ["Sensor"]


@patch("ngsi_qgis_plugin.core.broker_client.requests")
def test_timeout_is_translated_to_broker_timeout_error(mock_requests):
    import requests as real_requests
    mock_requests.exceptions = real_requests.exceptions
    mock_requests.Session.return_value.request.side_effect = real_requests.exceptions.Timeout()
    client = GenericNGSILDBroker("https://broker.example.org")
    with pytest.raises(BrokerTimeoutError):
        client.get_entities()


@patch("ngsi_qgis_plugin.core.broker_client.QgsMessageLog")
@patch("ngsi_qgis_plugin.core.broker_client.requests")
def test_token_never_appears_in_logs(mock_requests, mock_log):
    mock_requests.Session.return_value.request.return_value = _mock_response(200, [])
    client = GenericNGSILDBroker(
        "https://broker.example.org",
        headers={"Authorization": "Bearer super-secret-token"},
    )
    client.get_entities()
    logged_texts = " ".join(str(call) for call in mock_log.logMessage.call_args_list)
    assert "super-secret-token" not in logged_texts
    assert "***" in logged_texts


@patch("ngsi_qgis_plugin.core.broker_client.requests")
def test_cancellation_callback_interrupts_before_result(mock_requests):
    """
    Vérifie que is_cancelled_cb, propagé jusqu'à HttpClient.request(),
    interrompt bien l'appel avec une BrokerError plutôt que de renvoyer
    des données — c'est le mécanisme branché entre FetchEntitiesTask et
    get_entities() pour permettre l'annulation pendant le téléchargement.
    """
    mock_requests.Session.return_value.request.return_value = _mock_response(
        200, [{"id": "urn:ngsi-ld:A:1", "type": "A"}]
    )
    client = GenericNGSILDBroker("https://broker.example.org")
    with pytest.raises(BrokerError):
        client.get_entities(is_cancelled_cb=lambda: True)
