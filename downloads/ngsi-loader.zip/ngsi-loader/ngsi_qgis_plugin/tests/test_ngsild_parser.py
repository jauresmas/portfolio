# -*- coding: utf-8 -*-
from ngsi_qgis_plugin.ngsild.parser import parse_ngsild_entity, parse_ngsild_entities


def test_geoproperty_and_property_extraction():
    entity = {
        "id": "urn:ngsi-ld:Sensor:001",
        "type": "Sensor",
        "location": {"type": "GeoProperty", "value": {"type": "Point", "coordinates": [2.35, 48.85]}},
        "temperature": {"type": "Property", "value": 21.5},
    }
    parsed = parse_ngsild_entity(entity)
    assert parsed.geometry["coordinates"] == [2.35, 48.85]
    assert parsed.properties["temperature"] == 21.5


def test_relationship_is_kept_as_text():
    entity = {
        "id": "urn:ngsi-ld:Sensor:003",
        "type": "Sensor",
        "location": {"type": "GeoProperty", "value": {"type": "Point", "coordinates": [0, 0]}},
        "controlledAsset": {"type": "Relationship", "object": "urn:ngsi-ld:Device:001"},
    }
    parsed = parse_ngsild_entity(entity)
    assert parsed.properties["controlledAsset"] == "urn:ngsi-ld:Device:001"


def test_entity_without_geometry_is_not_dropped():
    entity = {"id": "urn:ngsi-ld:Sensor:002", "type": "Sensor",
              "temperature": {"type": "Property", "value": 18.0}}
    parsed = parse_ngsild_entity(entity)
    assert parsed is not None
    assert parsed.geometry is None
    assert parsed.skipped_reason is not None
    assert parsed.properties["temperature"] == 18.0


def test_unknown_attribute_shape_is_preserved_not_dropped():
    entity = {
        "id": "urn:ngsi-ld:Thing:001",
        "type": "Thing",
        "location": {"type": "GeoProperty", "value": {"type": "Point", "coordinates": [1, 1]}},
        "weirdAttribute": {"foo": "bar", "no_type_field": True},
    }
    parsed = parse_ngsild_entity(entity)
    assert "weirdAttribute" in parsed.properties


def test_split_with_and_without_geometry():
    entities = [
        {"id": "urn:ngsi-ld:A:1", "type": "A",
         "location": {"type": "GeoProperty", "value": {"type": "Point", "coordinates": [0, 0]}}},
        {"id": "urn:ngsi-ld:A:2", "type": "A"},
    ]
    with_geom, without_geom = parse_ngsild_entities(entities)
    assert len(with_geom) == 1
    assert len(without_geom) == 1


def test_extended_uri_location_key_is_normalized():
    entity = {
        "id": "urn:ngsi-ld:B:1",
        "type": "B",
        "https://uri.etsi.org/ngsi-ld/location": {
            "type": "GeoProperty", "value": {"type": "Point", "coordinates": [3, 4]}
        },
    }
    parsed = parse_ngsild_entity(entity)
    assert parsed.geometry["coordinates"] == [3, 4]


def test_entity_combining_property_geoproperty_and_relationship_in_one():
    """
    Vérifie les trois formes NGSI-LD (Property, GeoProperty, Relationship)
    sur UNE SEULE entité en même temps, plutôt que testées séparément
    dans des entités différentes — cas réaliste d'une vraie entité de
    capteur avec attribut, position et lien vers un autre objet.
    """
    entity = {
        "id": "urn:ngsi-ld:Sensor:combo",
        "type": "Sensor",
        "location": {"type": "GeoProperty", "value": {"type": "Point", "coordinates": [2.35, 48.85]}},
        "temperature": {"type": "Property", "value": 21.4},
        "controlledAsset": {"type": "Relationship", "object": "urn:ngsi-ld:Building:001"},
    }
    parsed = parse_ngsild_entity(entity)
    assert parsed.geometry["coordinates"] == [2.35, 48.85]
    assert parsed.properties["temperature"] == 21.4
    assert parsed.properties["controlledAsset"] == "urn:ngsi-ld:Building:001"
    assert parsed.skipped_reason is None
