# -*- coding: utf-8 -*-
"""
Vérifie séparément trois scénarios d'erreur réseau distincts, chacun
traduit vers la bonne sous-classe de BrokerError :
- erreur de connexion (DNS/refus)
- token invalide (401)
- certificat TLS incorrect
"""
from unittest.mock import patch

from ngsi_qgis_plugin.brokers.ngsild_broker import GenericNGSILDBroker
from ngsi_qgis_plugin.core.broker_client import (
    BrokerConnectionError, BrokerHTTPError,
)


@patch("ngsi_qgis_plugin.core.broker_client.requests")
def test_connection_refused_raises_broker_connection_error(mock_requests):
    import requests as real_requests
    mock_requests.exceptions = real_requests.exceptions
    mock_requests.Session.return_value.request.side_effect = real_requests.exceptions.ConnectionError(
        "Connection refused"
    )
    client = GenericNGSILDBroker("https://broker-inexistant.example.org")

    result = client.test_connection()
    assert result["ok"] is False
    assert "impossible" in result["message"].lower() or "connect" in result["message"].lower()


@patch("ngsi_qgis_plugin.core.broker_client.requests")
def test_invalid_token_raises_401_and_is_reported_distinctly(mock_requests):
    from unittest.mock import MagicMock
    resp = MagicMock()
    resp.status_code = 401
    resp.headers = {}
    resp.iter_content = MagicMock(return_value=[b'{"error":"Unauthorized"}'])
    mock_requests.Session.return_value.request.return_value = resp

    client = GenericNGSILDBroker(
        "https://broker.example.org",
        headers={"Authorization": "Bearer token-invalide"},
    )
    result = client.test_connection()
    assert result["ok"] is False
    assert result["details"]["status_code"] == 401
    assert "authentification" in result["message"].lower()


@patch("ngsi_qgis_plugin.core.broker_client.requests")
def test_tls_certificate_error_raises_broker_connection_error(mock_requests):
    import requests as real_requests
    mock_requests.exceptions = real_requests.exceptions
    mock_requests.Session.return_value.request.side_effect = real_requests.exceptions.SSLError(
        "certificate verify failed"
    )
    client = GenericNGSILDBroker("https://broker-cert-invalide.example.org")

    result = client.test_connection()
    assert result["ok"] is False
    assert "certificat" in result["message"].lower() or "tls" in result["message"].lower()
