# -*- coding: utf-8 -*-
"""
Interface graphique du plugin NGSI Loader — version réorganisée en onglets
(Connexion / Filtres / Journal), avec sections repliables pour les options
avancées et le filtre spatial, et un indicateur de statut de connexion.

Branche : profils, fabrique de broker, tâches en arrière-plan, détection
de capacités, parseur NGSI-LD et conversion GeoJSON, filtres par
attributs et filtre spatial (bbox).
Ne contient aucune logique métier propre à un broker particulier — cette
réorganisation ne touche qu'à la présentation, pas au comportement.
"""
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QFormLayout, QTabWidget, QWidget,
    QLineEdit, QPlainTextEdit, QTextEdit, QPushButton, QLabel, QComboBox, QCheckBox,
    QMessageBox, QSpinBox, QDoubleSpinBox, QProgressBar,
)
from qgis.PyQt.QtCore import Qt
from qgis.core import (
    QgsApplication, QgsVectorLayer, QgsProject, QgsMessageLog, Qgis,
)

from ..core.broker_profile import (
    BrokerProfile, PREDEFINED_PROFILE_TEMPLATES,
    API_VERSION_NGSI_LD, API_VERSION_NGSI_V2,
)
from ..core.broker_factory import create_broker_client
from ..core.broker_client import BrokerError
from ..core.profile_store import save_profile, load_profile, delete_profile, list_profile_ids
from ..core.capability_detector import detect_capabilities
from ..core.tasks import FetchEntitiesTask, TestConnectionTask
from ..core.spatial_filter import (
    build_attrs_param, build_spatial_query_params_ngsild,
    build_spatial_query_params_ngsiv2, validate_bbox,
)
from ..geo.geojson_builder import (
    build_feature_collection_from_ngsild, build_feature_collection_from_ngsiv2,
    write_feature_collection_to_tempfile,
)

LOG_TAG = "NGSI Loader"

# Feuille de style : coins arrondis, espacements cohérents, un bouton
# d'accent pour l'action principale. Reste volontairement simple — pas
# de fichier externe requis, tout est en QSS inline.
STYLESHEET = """
QDialog { }
QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox, QPlainTextEdit, QTextEdit {
    border: 1px solid palette(mid);
    border-radius: 4px;
    padding: 4px 6px;
}
QPushButton {
    border: 1px solid palette(mid);
    border-radius: 4px;
    padding: 6px 12px;
}
QPushButton:hover {
    background-color: palette(light);
}
QPushButton#primaryButton {
    background-color: #2b6cb0;
    color: white;
    border: 1px solid #2b6cb0;
    font-weight: bold;
}
QPushButton#primaryButton:hover {
    background-color: #2c5282;
}
QPushButton#dangerButton {
    color: #c53030;
}
QPushButton#sectionToggle {
    border: none;
    text-align: left;
    padding: 6px 0px;
    color: palette(mid);
}
QTabWidget::pane {
    border: 1px solid palette(mid);
    border-radius: 4px;
    top: -1px;
}
QTabBar::tab {
    padding: 8px 14px;
}
QTabBar::tab:selected {
    font-weight: bold;
}
"""


def _parse_headers_text(text):
    headers = {}
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or ":" not in line:
            continue
        k, v = line.split(":", 1)
        headers[k.strip()] = v.strip()
    return headers


class CollapsibleSection(QWidget):
    """
    Section repliable simple : un bouton-titre cliquable (▶/▼) qui montre
    ou cache un widget de contenu. Aucun composant Qt natif ne fait ça
    directement, donc on l'assemble avec un bouton + setVisible().
    """

    def __init__(self, title, content_widget, parent=None, start_expanded=False):
        super().__init__(parent)
        self.content_widget = content_widget
        self.toggle_btn = QPushButton(f"{'▼' if start_expanded else '▶'}  {title}")
        self.toggle_btn.setObjectName("sectionToggle")
        self.toggle_btn.setCheckable(True)
        self.toggle_btn.setChecked(start_expanded)
        self.toggle_btn.clicked.connect(self._on_toggled)
        self._title = title

        layout = QVBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self.toggle_btn)
        layout.addWidget(self.content_widget)
        self.setLayout(layout)
        self.content_widget.setVisible(start_expanded)

    def _on_toggled(self):
        expanded = self.toggle_btn.isChecked()
        self.content_widget.setVisible(expanded)
        arrow = "▼" if expanded else "▶"
        self.toggle_btn.setText(f"{arrow}  {self._title}")


class StatusIndicator(QWidget):
    """Petit indicateur visuel : point coloré + texte, pour l'état de connexion."""

    COLORS = {"unknown": "#a0aec0", "ok": "#38a169", "error": "#c53030"}
    LABELS = {"unknown": "Non testé", "ok": "Connecté", "error": "Échec de connexion"}

    def __init__(self, parent=None):
        super().__init__(parent)
        self.dot = QLabel()
        self.dot.setFixedSize(10, 10)
        self.text = QLabel()
        layout = QHBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self.dot)
        layout.addWidget(self.text)
        self.setLayout(layout)
        self.set_state("unknown")

    def set_state(self, state):
        color = self.COLORS.get(state, self.COLORS["unknown"])
        self.dot.setStyleSheet(f"background-color: {color}; border-radius: 5px;")
        self.text.setText(self.LABELS.get(state, self.LABELS["unknown"]))
        self.text.setStyleSheet(f"color: {color};")


class NGSIDialog(QDialog):
    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.setWindowTitle("NGSI Loader")
        self.resize(700, 480)
        self.setStyleSheet(STYLESHEET)

        self._current_task = None
        self._current_profile = None
        self._last_capabilities = None

        self._build_ui()
        self._reload_profile_list()

        QgsMessageLog.logMessage("Interface NGSI Loader initialisée.", LOG_TAG, Qgis.Info)
        QgsApplication.messageLog().messageReceived.connect(self._on_log_message)

    # ------------------------------------------------------------------ UI

    def _build_ui(self):
        root_layout = QVBoxLayout()

        # --- En-tête : titre + indicateur de statut ---
        header_layout = QHBoxLayout()
        title_label = QLabel("<b>NGSI Loader</b>")
        self.status_indicator = StatusIndicator()
        header_layout.addWidget(title_label)
        header_layout.addStretch()
        header_layout.addWidget(self.status_indicator)
        root_layout.addLayout(header_layout)

        # --- Onglets ---
        self.tabs = QTabWidget()
        self.tabs.addTab(self._build_connection_tab(), "Connexion")
        self.tabs.addTab(self._build_filters_tab(), "Filtres")
        self.tabs.addTab(self._build_log_tab(), "Journal")
        root_layout.addWidget(self.tabs)

        self.setLayout(root_layout)
        self._on_broker_kind_changed(self.broker_kind_combo.currentText())

    def _build_connection_tab(self):
        tab = QWidget()
        layout = QVBoxLayout()

        # Ligne de gestion de profil
        profile_layout = QHBoxLayout()
        self.profile_combo = QComboBox()
        load_btn = QPushButton("Charger")
        load_btn.clicked.connect(self._on_load_profile_clicked)
        save_btn = QPushButton("Enregistrer")
        save_btn.clicked.connect(self._on_save_profile_clicked)
        delete_btn = QPushButton("Supprimer")
        delete_btn.setObjectName("dangerButton")
        delete_btn.clicked.connect(self._on_delete_profile_clicked)
        profile_layout.addWidget(QLabel("Profil :"))
        profile_layout.addWidget(self.profile_combo, 1)
        profile_layout.addWidget(load_btn)
        profile_layout.addWidget(save_btn)
        profile_layout.addWidget(delete_btn)
        layout.addLayout(profile_layout)

        # Champs principaux
        form = QFormLayout()
        self.name_edit = QLineEdit()
        self.name_edit.setPlaceholderText("Nom du profil (ex. Mon broker Stellio)")

        self.broker_kind_combo = QComboBox()
        self.broker_kind_combo.addItems(list(PREDEFINED_PROFILE_TEMPLATES.keys()))
        self.broker_kind_combo.currentTextChanged.connect(self._on_broker_kind_changed)

        self.api_version_combo = QComboBox()
        self.api_version_combo.addItems([API_VERSION_NGSI_LD, API_VERSION_NGSI_V2])

        self.base_url_edit = QLineEdit()
        self.base_url_edit.setPlaceholderText("https://broker.example.org")

        self.auth_type_combo = QComboBox()
        self.auth_type_combo.addItems(["none", "bearer", "apikey", "custom"])

        self.token_edit = QLineEdit()
        self.token_edit.setEchoMode(QLineEdit.Password)
        self.token_edit.setPlaceholderText("Token / clé API (jamais affiché en clair)")

        form.addRow("Nom du profil :", self.name_edit)
        form.addRow("Type de broker :", self.broker_kind_combo)
        form.addRow("Version API :", self.api_version_combo)
        form.addRow("URL du broker :", self.base_url_edit)
        form.addRow("Authentification :", self.auth_type_combo)
        form.addRow("Token / clé API :", self.token_edit)
        layout.addLayout(form)

        # Section repliable : options avancées
        advanced_content = QWidget()
        advanced_form = QFormLayout()
        advanced_form.setContentsMargins(0, 4, 0, 4)

        self.headers_edit = QPlainTextEdit()
        self.headers_edit.setPlaceholderText("En-têtes personnalisés, un par ligne : Fiware-Service: myservice")
        self.headers_edit.setFixedHeight(55)

        self.context_edit = QLineEdit()
        self.context_edit.setPlaceholderText("URL du contexte JSON-LD (requis pour Orion-LD sans @context embarqué)")

        self.timeout_spin = QSpinBox()
        self.timeout_spin.setRange(1, 300)
        self.timeout_spin.setValue(30)

        self.verify_tls_cb = QCheckBox("Vérifier le certificat TLS (recommandé)")
        self.verify_tls_cb.setChecked(True)

        self.key_values_cb = QCheckBox("Utiliser keyValues (NGSI v2)")
        self.key_values_cb.setChecked(True)

        advanced_form.addRow("En-têtes personnalisés :", self.headers_edit)
        advanced_form.addRow("Contexte JSON-LD :", self.context_edit)
        advanced_form.addRow("Timeout (s) :", self.timeout_spin)
        advanced_form.addRow("", self.verify_tls_cb)
        advanced_form.addRow("", self.key_values_cb)
        advanced_content.setLayout(advanced_form)

        layout.addWidget(CollapsibleSection("Options avancées", advanced_content))

        # Boutons de test
        btn_layout = QHBoxLayout()
        test_btn = QPushButton("Tester la connexion")
        test_btn.clicked.connect(self._on_test_connection_clicked)
        detect_btn = QPushButton("Détecter les capacités")
        detect_btn.clicked.connect(self._on_detect_capabilities_clicked)
        btn_layout.addWidget(test_btn)
        btn_layout.addWidget(detect_btn)
        layout.addLayout(btn_layout)

        self.detect_cb = QCheckBox("Autoriser le test d'écriture (crée puis supprime une entité de test)")
        layout.addWidget(self.detect_cb)

        self.capabilities_label = QLabel("Capacités : non détectées.")
        self.capabilities_label.setWordWrap(True)
        self.capabilities_label.setStyleSheet("color: palette(mid); font-size: 11px; padding: 4px;")
        layout.addWidget(self.capabilities_label)

        tab.setLayout(layout)
        return tab

    def _build_filters_tab(self):
        tab = QWidget()
        layout = QVBoxLayout()

        form = QFormLayout()
        self.entity_type_edit = QLineEdit()
        self.entity_type_edit.setPlaceholderText("Type d'entité (optionnel, ex. Sensor)")
        self.attrs_edit = QLineEdit()
        self.attrs_edit.setPlaceholderText("Attributs à récupérer, séparés par des virgules (optionnel)")
        self.limit_spin = QSpinBox()
        self.limit_spin.setRange(1, 10000)
        self.limit_spin.setValue(100)
        self.layer_name_edit = QLineEdit()
        self.layer_name_edit.setPlaceholderText("NGSI_entities")
        form.addRow("Type d'entité :", self.entity_type_edit)
        form.addRow("Attributs :", self.attrs_edit)
        form.addRow("Taille de page :", self.limit_spin)
        form.addRow("Nom de la couche :", self.layer_name_edit)
        layout.addLayout(form)

        self.include_no_geom_cb = QCheckBox("Inclure les entités sans géométrie (attributs seuls)")
        layout.addWidget(self.include_no_geom_cb)

        # Section repliable : filtre spatial
        spatial_content = QWidget()
        spatial_layout = QVBoxLayout()
        spatial_layout.setContentsMargins(0, 4, 0, 4)
        self.spatial_enabled_cb = QCheckBox("Activer le filtre spatial")
        spatial_layout.addWidget(self.spatial_enabled_cb)

        coords_layout = QHBoxLayout()
        self.min_lon_spin = QDoubleSpinBox()
        self.min_lat_spin = QDoubleSpinBox()
        self.max_lon_spin = QDoubleSpinBox()
        self.max_lat_spin = QDoubleSpinBox()
        for spin in (self.min_lon_spin, self.max_lon_spin):
            spin.setRange(-180.0, 180.0)
            spin.setDecimals(6)
        for spin in (self.min_lat_spin, self.max_lat_spin):
            spin.setRange(-90.0, 90.0)
            spin.setDecimals(6)
        for label_text, widget in [
            ("Lon min", self.min_lon_spin), ("Lat min", self.min_lat_spin),
            ("Lon max", self.max_lon_spin), ("Lat max", self.max_lat_spin),
        ]:
            col = QVBoxLayout()
            lbl = QLabel(label_text)
            lbl.setStyleSheet("font-size: 11px; color: palette(mid);")
            col.addWidget(lbl)
            col.addWidget(widget)
            coords_layout.addLayout(col)
        spatial_layout.addLayout(coords_layout)
        spatial_content.setLayout(spatial_layout)

        layout.addWidget(CollapsibleSection("Filtre spatial (zone rectangulaire, WGS84)", spatial_content))

        # Boutons d'action
        action_layout = QHBoxLayout()
        self.fetch_btn = QPushButton("Charger dans QGIS")
        self.fetch_btn.setObjectName("primaryButton")
        self.fetch_btn.clicked.connect(self._on_fetch_clicked)
        self.cancel_btn = QPushButton("Annuler")
        self.cancel_btn.clicked.connect(self._on_cancel_clicked)
        self.cancel_btn.setEnabled(False)
        action_layout.addWidget(self.fetch_btn, 1)
        action_layout.addWidget(self.cancel_btn)
        layout.addLayout(action_layout)

        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        layout.addWidget(self.progress_bar)

        tab.setLayout(layout)
        return tab

    def _build_log_tab(self):
        tab = QWidget()
        layout = QVBoxLayout()
        self.log_view = QPlainTextEdit()
        self.log_view.setReadOnly(True)
        layout.addWidget(self.log_view)
        tab.setLayout(layout)
        return tab

    # ------------------------------------------------------------- helpers

    def _on_log_message(self, message, tag, level):
        if tag != LOG_TAG:
            return
        self.log_view.appendPlainText(message)

    def _on_broker_kind_changed(self, broker_name):
        template = PREDEFINED_PROFILE_TEMPLATES.get(broker_name, {})
        api_version = template.get("api_version", API_VERSION_NGSI_LD)
        idx = self.api_version_combo.findText(api_version)
        if idx >= 0:
            self.api_version_combo.setCurrentIndex(idx)

    def _profile_kind_from_display_name(self, display_name):
        return PREDEFINED_PROFILE_TEMPLATES.get(display_name, {}).get("broker_kind", "generic_ngsild")

    def _build_profile_from_ui(self):
        try:
            return BrokerProfile(
                name=self.name_edit.text().strip() or "Profil sans nom",
                base_url=self.base_url_edit.text().strip(),
                api_version=self.api_version_combo.currentText(),
                broker_kind=self._profile_kind_from_display_name(self.broker_kind_combo.currentText()),
                auth_type=self.auth_type_combo.currentText(),
                token=self.token_edit.text().strip() or None,
                custom_headers=_parse_headers_text(self.headers_edit.toPlainText()),
                default_context=self.context_edit.text().strip() or None,
                timeout=self.timeout_spin.value(),
                verify_tls=self.verify_tls_cb.isChecked(),
                key_values_v2=self.key_values_cb.isChecked(),
            )
        except ValueError as e:
            QMessageBox.warning(self, "NGSI Loader", f"Profil invalide : {e}")
            return None

    def _apply_profile_to_ui(self, profile):
        self.name_edit.setText(profile.name)
        self.base_url_edit.setText(profile.base_url)
        idx = self.api_version_combo.findText(profile.api_version)
        if idx >= 0:
            self.api_version_combo.setCurrentIndex(idx)
        for display_name, tpl in PREDEFINED_PROFILE_TEMPLATES.items():
            if tpl.get("broker_kind") == profile.broker_kind:
                idx = self.broker_kind_combo.findText(display_name)
                if idx >= 0:
                    self.broker_kind_combo.setCurrentIndex(idx)
                break
        idx = self.auth_type_combo.findText(profile.auth_type)
        if idx >= 0:
            self.auth_type_combo.setCurrentIndex(idx)
        self.token_edit.setText(profile.token or "")
        self.headers_edit.setPlainText(
            "\n".join(f"{k}: {v}" for k, v in profile.custom_headers.items())
        )
        self.context_edit.setText(profile.default_context or "")
        self.timeout_spin.setValue(profile.timeout)
        self.verify_tls_cb.setChecked(profile.verify_tls)
        self.key_values_cb.setChecked(profile.key_values_v2)
        self.status_indicator.set_state("unknown")  # profil rechargé => statut à revérifier

    def _reload_profile_list(self):
        self.profile_combo.blockSignals(True)
        self.profile_combo.clear()
        self.profile_combo.addItems(list_profile_ids())
        self.profile_combo.blockSignals(False)

    def _build_query_params_from_filters(self, api_version):
        """
        Construit les query_params additionnels (attrs + filtre spatial)
        à partir des champs de filtre de l'UI. Retourne (params: dict, error: str|None).
        """
        params = {}

        attrs_param = build_attrs_param(self.attrs_edit.text())
        if attrs_param:
            params["attrs"] = attrs_param

        if self.spatial_enabled_cb.isChecked():
            min_lon = self.min_lon_spin.value()
            min_lat = self.min_lat_spin.value()
            max_lon = self.max_lon_spin.value()
            max_lat = self.max_lat_spin.value()
            ok, message = validate_bbox(min_lon, min_lat, max_lon, max_lat)
            if not ok:
                return None, message
            if api_version == API_VERSION_NGSI_LD:
                params.update(build_spatial_query_params_ngsild(min_lon, min_lat, max_lon, max_lat))
            else:
                params.update(build_spatial_query_params_ngsiv2(min_lon, min_lat, max_lon, max_lat))

        return params, None

    # -------------------------------------------------------- profil : CRUD

    def _on_save_profile_clicked(self):
        profile = self._build_profile_from_ui()
        if profile is None:
            return
        try:
            profile_id = save_profile(profile)
        except Exception as e:
            QMessageBox.critical(self, "NGSI Loader", f"Échec de l'enregistrement du profil : {e}")
            return
        self._reload_profile_list()
        idx = self.profile_combo.findText(profile_id)
        if idx >= 0:
            self.profile_combo.setCurrentIndex(idx)
        QMessageBox.information(self, "NGSI Loader", f"Profil enregistré sous « {profile_id} ».")

    def _on_load_profile_clicked(self):
        profile_id = self.profile_combo.currentText()
        if not profile_id:
            QMessageBox.warning(self, "NGSI Loader", "Aucun profil sélectionné.")
            return
        profile = load_profile(profile_id)
        if profile is None:
            QMessageBox.warning(self, "NGSI Loader", "Profil introuvable.")
            return
        self._apply_profile_to_ui(profile)

    def _on_delete_profile_clicked(self):
        profile_id = self.profile_combo.currentText()
        if not profile_id:
            return
        confirm = QMessageBox.question(
            self, "NGSI Loader", f"Supprimer le profil « {profile_id} » (et son token associé) ?"
        )
        if confirm != QMessageBox.Yes:
            return
        delete_profile(profile_id)
        self._reload_profile_list()

    # ---------------------------------------------------- test / capacités

    def _on_test_connection_clicked(self):
        profile = self._build_profile_from_ui()
        if profile is None or not profile.base_url:
            QMessageBox.warning(self, "NGSI Loader", "Renseignez au moins l'URL du broker.")
            return
        try:
            client = create_broker_client(profile)
        except BrokerError as e:
            self.status_indicator.set_state("error")
            QMessageBox.critical(self, "NGSI Loader", str(e))
            return

        task = TestConnectionTask("NGSI Loader — test de connexion", client)
        task.taskCompleted.connect(lambda: self._on_test_connection_finished(task))
        task.taskTerminated.connect(lambda: self._on_test_connection_finished(task))
        self._current_task = task
        QgsApplication.taskManager().addTask(task)

    def _on_test_connection_finished(self, task):
        result = task.result or {"ok": False, "message": "Échec inconnu."}
        if result.get("ok"):
            self.status_indicator.set_state("ok")
            QMessageBox.information(self, "NGSI Loader", "Connexion réussie.")
        else:
            self.status_indicator.set_state("error")
            QMessageBox.warning(self, "NGSI Loader", f"Échec de la connexion : {result.get('message')}")
        self._current_task = None

    def _on_detect_capabilities_clicked(self):
        profile = self._build_profile_from_ui()
        if profile is None or not profile.base_url:
            QMessageBox.warning(self, "NGSI Loader", "Renseignez au moins l'URL du broker.")
            return
        if self.detect_cb.isChecked():
            confirm = QMessageBox.question(
                self, "NGSI Loader",
                "Le test d'écriture va créer PUIS SUPPRIMER une entité de test sur ce broker. Continuer ?"
            )
            if confirm != QMessageBox.Yes:
                return
        try:
            client = create_broker_client(profile)
            caps = detect_capabilities(client, allow_write_probe=self.detect_cb.isChecked())
        except BrokerError as e:
            QMessageBox.critical(self, "NGSI Loader", str(e))
            return

        self._last_capabilities = caps.as_dict()
        summary = ", ".join(f"{k}={v}" for k, v in self._last_capabilities.items() if k != "notes")
        self.capabilities_label.setText(f"Capacités détectées : {summary}")
        if caps.reachable:
            self.status_indicator.set_state("ok")
        if caps.notes:
            self.log_view.appendPlainText("Notes de détection :\n- " + "\n- ".join(caps.notes))

    # -------------------------------------------------------------- fetch

    def _on_fetch_clicked(self):
        profile = self._build_profile_from_ui()
        if profile is None or not profile.base_url:
            QMessageBox.warning(self, "NGSI Loader", "Renseignez au moins l'URL du broker.")
            return

        query_params, error = self._build_query_params_from_filters(profile.api_version)
        if error:
            QMessageBox.warning(self, "NGSI Loader", f"Filtre spatial invalide : {error}")
            return

        try:
            client = create_broker_client(profile)
        except BrokerError as e:
            QMessageBox.critical(self, "NGSI Loader", str(e))
            return

        self._current_profile = profile
        task = FetchEntitiesTask(
            "NGSI Loader — récupération des entités",
            client,
            entity_type=self.entity_type_edit.text().strip() or None,
            query_params=query_params or None,
            limit=self.limit_spin.value(),
        )
        task.progressChanged.connect(self.progress_bar.setValue)
        task.taskCompleted.connect(lambda: self._on_fetch_finished(task))
        task.taskTerminated.connect(lambda: self._on_fetch_finished(task))
        self._current_task = task
        self.fetch_btn.setEnabled(False)
        self.cancel_btn.setEnabled(True)
        QgsApplication.taskManager().addTask(task)

    def _on_cancel_clicked(self):
        if self._current_task is not None:
            self._current_task.cancel()

    def _on_fetch_finished(self, task):
        self.fetch_btn.setEnabled(True)
        self.cancel_btn.setEnabled(False)
        self.progress_bar.setValue(0)

        result = task.result
        if result is None or not result.success:
            msg = result.error_message if result else "Échec inconnu."
            QMessageBox.warning(self, "NGSI Loader", f"Échec du chargement : {msg}")
            self._current_task = None
            return

        entities = result.data
        profile = self._current_profile
        if profile.api_version == API_VERSION_NGSI_LD:
            fc, stats = build_feature_collection_from_ngsild(
                entities, include_without_geometry=self.include_no_geom_cb.isChecked()
            )
        else:
            fc, stats = build_feature_collection_from_ngsiv2(
                entities, include_without_geometry=self.include_no_geom_cb.isChecked()
            )

        if not fc["features"]:
            QMessageBox.information(
                self, "NGSI Loader",
                f"Aucune feature à afficher (reçu {stats['total_received']}, "
                f"{stats['with_geometry']} avec géométrie)."
            )
            self._current_task = None
            return

        layer_name = self.layer_name_edit.text().strip() or "NGSI_entities"
        try:
            geojson_path = write_feature_collection_to_tempfile(fc)
            vl = QgsVectorLayer(geojson_path, layer_name, "ogr")
            if not vl or not vl.isValid():
                raise BrokerError("La couche générée n'est pas valide.")
            QgsProject.instance().addMapLayer(vl)
        except Exception as e:
            QMessageBox.critical(self, "NGSI Loader", f"Échec de la création de la couche : {e}")
            self._current_task = None
            return

        QMessageBox.information(
            self, "NGSI Loader",
            f"Couche chargée : {vl.featureCount()} feature(s).\n"
            f"Reçues : {stats['total_received']} — avec géométrie : {stats['with_geometry']} — "
            f"sans géométrie : {stats['without_geometry']}."
        )
        self._current_task = None
