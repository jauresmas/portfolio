# -*- coding: utf-8 -*-
"""
Parseur NGSI-LD générique et indépendant du broker.
Transforme une entité NGSI-LD brute (JSON) en une structure GeoJSON-friendly.
"""
import json

from .context_resolver import normalize_entity_keys

RESERVED_TOP_LEVEL_KEYS = {"id", "type", "@context"}
VALID_GEOJSON_GEOM_TYPES = {
    "Point", "MultiPoint", "LineString", "MultiLineString",
    "Polygon", "MultiPolygon", "GeometryCollection",
}


class ParsedEntity:
    """Résultat du parsing d'une entité, prêt à être converti en Feature GeoJSON."""

    def __init__(self, entity_id, entity_type, geometry, properties, skipped_reason=None):
        self.id = entity_id
        self.type = entity_type
        self.geometry = geometry
        self.properties = properties
        self.skipped_reason = skipped_reason


def _is_valid_geojson_geometry(value):
    return (
        isinstance(value, dict)
        and value.get("type") in VALID_GEOJSON_GEOM_TYPES
        and "coordinates" in value
    )


def _extract_geoproperty(attr_value):
    if not isinstance(attr_value, dict):
        return None
    if attr_value.get("type") == "GeoProperty":
        candidate = attr_value.get("value")
        if _is_valid_geojson_geometry(candidate):
            return candidate
    return None


def _extract_property_value(attr_value):
    return attr_value.get("value")


def _extract_relationship(attr_value):
    obj = attr_value.get("object")
    return obj if isinstance(obj, str) else json.dumps(obj)


def parse_ngsild_entity(entity):
    """
    Transforme une entité NGSI-LD brute en ParsedEntity.
    - Property     -> properties[clé] = valeur scalaire/complexe
    - GeoProperty  -> devient la géométrie (la première trouvée)
    - Relationship -> properties[clé] = URI de l'entité liée (texte)
    - Forme inconnue -> conservée telle quelle (jamais ignorée silencieusement)
    """
    if not isinstance(entity, dict) or "id" not in entity:
        return None

    entity = normalize_entity_keys(entity)
    entity_id = entity.get("id")
    entity_type = entity.get("type")

    geometry = None
    properties = {}
    extra_geoproperties = {}

    for key, value in entity.items():
        if key in RESERVED_TOP_LEVEL_KEYS:
            continue

        if isinstance(value, dict) and value.get("type") == "GeoProperty":
            geom = _extract_geoproperty(value)
            if geom is not None:
                if geometry is None:
                    geometry = geom
                else:
                    extra_geoproperties[key] = geom
            continue

        if isinstance(value, dict) and value.get("type") == "Property":
            properties[key] = _extract_property_value(value)
            continue

        if isinstance(value, dict) and value.get("type") == "Relationship":
            properties[key] = _extract_relationship(value)
            continue

        if isinstance(value, (dict, list)):
            try:
                properties[key] = json.dumps(value, ensure_ascii=False)
            except (TypeError, ValueError):
                properties[key] = str(value)
        else:
            properties[key] = value

    for key, geom in extra_geoproperties.items():
        properties[f"{key}_geometry"] = json.dumps(geom, ensure_ascii=False)

    skipped_reason = None
    if geometry is None:
        skipped_reason = "Aucune GeoProperty valide trouvée sur cette entité."

    return ParsedEntity(entity_id, entity_type, geometry, properties, skipped_reason)


def parse_ngsild_entities(entities):
    """
    Parse une liste d'entités NGSI-LD.
    Retourne (parsed_ok, parsed_without_geometry).
    """
    with_geometry, without_geometry = [], []
    for raw in entities:
        parsed = parse_ngsild_entity(raw)
        if parsed is None:
            continue
        if parsed.geometry is not None:
            with_geometry.append(parsed)
        else:
            without_geometry.append(parsed)
    return with_geometry, without_geometry
