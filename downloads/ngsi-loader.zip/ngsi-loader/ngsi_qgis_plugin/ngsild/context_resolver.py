# -*- coding: utf-8 -*-
"""
Normalisation minimale du @context NGSI-LD.

Limitation documentée : ce module NE résout PAS complètement le JSON-LD
(pas d'expansion/compaction complète au sens de la spec JSON-LD, ce qui
nécessiterait une dépendance externe type pyld). Il se contente d'une
normalisation fiable et pragmatique : reconnaître les clés couramment
utilisées pour un même attribut sémantique (forme compactée usuelle vs
URI étendue du cœur NGSI-LD). Pour un contexte personnalisé complexe,
des attributs peuvent ne pas être reconnus automatiquement : ils sont
alors conservés tels quels par le parseur, jamais silencieusement
supprimés.
"""

CORE_CONTEXT_ALIASES = {
    "https://uri.etsi.org/ngsi-ld/location": "location",
    "https://uri.etsi.org/ngsi-ld/observedAt": "observedAt",
    "https://uri.etsi.org/ngsi-ld/createdAt": "createdAt",
    "https://uri.etsi.org/ngsi-ld/modifiedAt": "modifiedAt",
    "https://uri.etsi.org/ngsi-ld/datasetId": "datasetId",
    "https://uri.etsi.org/ngsi-ld/hasObject": "object",
}


def normalize_key(key):
    """Retourne la forme compactée connue d'une clé, sinon la clé inchangée."""
    return CORE_CONTEXT_ALIASES.get(key, key)


def normalize_entity_keys(entity):
    """Retourne une copie de l'entité avec les clés de premier niveau normalisées."""
    return {normalize_key(k): v for k, v in entity.items()}
