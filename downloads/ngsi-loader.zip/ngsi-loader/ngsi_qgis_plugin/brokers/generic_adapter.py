# -*- coding: utf-8 -*-
"""
Adaptateurs "génériques" et "custom" : ne font qu'appliquer le profil
tel quel aux clients génériques, sans aucune particularité propre à un
produit. C'est le cas par défaut pour tout broker conforme au standard
mais non identifié spécifiquement.
"""
from .ngsild_broker import GenericNGSILDBroker
from .ngsiv2_broker import GenericNGSIv2Broker
from ..core.broker_client import BrokerError


def build_generic_ngsild_client(profile):
    return GenericNGSILDBroker(
        base_url=profile.base_url,
        headers=profile.build_headers(),
        timeout=profile.timeout,
        verify_tls=profile.verify_tls,
        context_link=profile.default_context,
    )


def build_generic_ngsiv2_client(profile):
    return GenericNGSIv2Broker(
        base_url=profile.base_url,
        headers=profile.build_headers(),
        timeout=profile.timeout,
        verify_tls=profile.verify_tls,
        key_values=profile.key_values_v2,
    )


def build_custom_client(profile):
    """
    « Custom Broker » : aucune supposition — applique strictement le
    profil fourni par l'utilisateur (URL, en-têtes, version choisie).
    """
    if profile.api_version == "ngsi-ld":
        return build_generic_ngsild_client(profile)
    elif profile.api_version == "ngsi-v2":
        return build_generic_ngsiv2_client(profile)
    raise BrokerError(f"Version d'API non gérée pour un broker personnalisé : {profile.api_version}")
