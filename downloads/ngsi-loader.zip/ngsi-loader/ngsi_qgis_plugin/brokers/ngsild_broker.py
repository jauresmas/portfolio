# -*- coding: utf-8 -*-
"""
Client générique pour tout broker respectant l'API NGSI-LD standard
(ETSI GS CIM 009). Aucune particularité Stellio/Orion-LD/Scorpio ici.
"""
from ..core.broker_client import HttpClient, build_url, BrokerError, BrokerHTTPError
from .base_broker import BaseBrokerClient


class GenericNGSILDBroker(BaseBrokerClient):
    """Implémente BaseBrokerClient pour l'API NGSI-LD standard."""

    def __init__(self, base_url, headers=None, timeout=30, verify_tls=True, context_link=None):
        self.base_url = base_url.rstrip("/")
        self.headers = dict(headers or {})
        self.headers.setdefault("Accept", "application/ld+json")
        self.context_link = context_link
        if context_link:
            self.headers.setdefault(
                "Link",
                f'<{context_link}>; rel="http://www.w3.org/ns/json-ld#context"; type="application/ld+json"',
            )
        self._http = HttpClient(timeout=timeout, verify_tls=verify_tls)

    def _entities_url(self):
        return build_url(self.base_url, "/ngsi-ld/v1/entities")

    def test_connection(self):
        try:
            self._http.request("GET", self._entities_url(), headers=self.headers, params={"limit": 1})
            return {"ok": True, "message": "Connexion réussie (NGSI-LD).", "details": None}
        except BrokerHTTPError as e:
            if e.status_code in (401, 403):
                return {"ok": False, "message": "Broker joignable mais authentification refusée.",
                         "details": {"status_code": e.status_code}}
            return {"ok": False, "message": str(e), "details": {"status_code": e.status_code}}
        except BrokerError as e:
            return {"ok": False, "message": str(e), "details": None}

    def get_entities(self, entity_type=None, query_params=None, limit=100, offset=0, is_cancelled_cb=None):
        params = dict(query_params or {})
        if entity_type:
            params["type"] = entity_type
        if limit is not None:
            params["limit"] = limit
        if offset:
            params["offset"] = offset
        result = self._http.request(
            "GET", self._entities_url(), headers=self.headers, params=params,
            is_cancelled_cb=is_cancelled_cb,
        )
        return result if isinstance(result, list) else []

    def get_entity(self, entity_id):
        url = build_url(self.base_url, f"/ngsi-ld/v1/entities/{entity_id}")
        try:
            return self._http.request("GET", url, headers=self.headers)
        except BrokerHTTPError as e:
            if e.status_code == 404:
                return None
            raise

    def get_entity_types(self):
        url = build_url(self.base_url, "/ngsi-ld/v1/types")
        result = self._http.request("GET", url, headers=self.headers)
        if isinstance(result, dict) and "typeList" in result:
            return result["typeList"]
        return result if isinstance(result, list) else []

    def create_entity(self, entity):
        headers = dict(self.headers)
        headers["Content-Type"] = "application/ld+json"
        self._http.request("POST", self._entities_url(), headers=headers, json_body=entity)
        return entity.get("id")

    def update_entity(self, entity_id, attributes):
        url = build_url(self.base_url, f"/ngsi-ld/v1/entities/{entity_id}/attrs")
        headers = dict(self.headers)
        headers["Content-Type"] = "application/ld+json"
        self._http.request("PATCH", url, headers=headers, json_body=attributes)
        return True

    def delete_entity(self, entity_id):
        url = build_url(self.base_url, f"/ngsi-ld/v1/entities/{entity_id}")
        self._http.request("DELETE", url, headers=self.headers)
        return True

    def get_capabilities(self):
        return {
            "ngsi_ld": True,
            "ngsi_v2": False,
            "pagination": True,
            "spatial_filter": None,
            "write_operations": None,
            "subscriptions": None,
        }
