# -*- coding: utf-8 -*-
"""
Adaptateur Stellio (https://stellio.readthedocs.io/).
Hérite intégralement de GenericNGSILDBroker : Stellio suit le standard
NGSI-LD de près. Les particularités ci-dessous sont marquées
« À VÉRIFIER » quand la certitude n'est pas absolue — à confirmer contre
la version exacte du broker cible avant mise en production.
"""
from .ngsild_broker import GenericNGSILDBroker


class StellioBroker(GenericNGSILDBroker):
    def get_capabilities(self):
        caps = super().get_capabilities()
        caps.update({
            "pagination": True,          # documenté : limit/offset supportés
            "spatial_filter": True,      # georel/geometry/coordinates — À VÉRIFIER selon version
            "subscriptions": True,       # endpoint /ngsi-ld/v1/subscriptions documenté
        })
        return caps
