# -*- coding: utf-8 -*-
"""
Client générique pour tout broker respectant l'API NGSI v2 standard
(FIWARE NGSI v2 specification). Ne suppose aucune particularité propre
à un produit donné.
"""
from ..core.broker_client import HttpClient, build_url, BrokerError, BrokerHTTPError
from .base_broker import BaseBrokerClient


class GenericNGSIv2Broker(BaseBrokerClient):
    """Implémente BaseBrokerClient pour l'API NGSI v2 standard."""

    def __init__(self, base_url, headers=None, timeout=30, verify_tls=True, key_values=True):
        self.base_url = base_url.rstrip("/")
        self.headers = dict(headers or {})
        self.headers.setdefault("Accept", "application/json")
        self.key_values = key_values
        self._http = HttpClient(timeout=timeout, verify_tls=verify_tls)

    def _entities_url(self):
        return build_url(self.base_url, "/v2/entities")

    def test_connection(self):
        try:
            self._http.request("GET", self._entities_url(), headers=self.headers, params={"limit": 1})
            return {"ok": True, "message": "Connexion réussie (NGSI v2).", "details": None}
        except BrokerHTTPError as e:
            if e.status_code in (401, 403):
                return {"ok": False, "message": "Broker joignable mais authentification refusée.",
                         "details": {"status_code": e.status_code}}
            return {"ok": False, "message": str(e), "details": {"status_code": e.status_code}}
        except BrokerError as e:
            return {"ok": False, "message": str(e), "details": None}

    def get_entities(self, entity_type=None, query_params=None, limit=100, offset=0, is_cancelled_cb=None):
        params = dict(query_params or {})
        if entity_type:
            params["type"] = entity_type
        if limit is not None:
            params["limit"] = limit
        if offset:
            params["offset"] = offset
        if self.key_values:
            params.setdefault("options", "keyValues")
        result = self._http.request(
            "GET", self._entities_url(), headers=self.headers, params=params,
            is_cancelled_cb=is_cancelled_cb,
        )
        return result if isinstance(result, list) else []

    def get_entity(self, entity_id):
        url = build_url(self.base_url, f"/v2/entities/{entity_id}")
        params = {"options": "keyValues"} if self.key_values else None
        try:
            return self._http.request("GET", url, headers=self.headers, params=params)
        except BrokerHTTPError as e:
            if e.status_code == 404:
                return None
            raise

    def get_entity_types(self):
        url = build_url(self.base_url, "/v2/types")
        result = self._http.request("GET", url, headers=self.headers)
        if isinstance(result, list):
            return [t.get("type") if isinstance(t, dict) else t for t in result]
        return []

    def create_entity(self, entity):
        headers = dict(self.headers)
        headers["Content-Type"] = "application/json"
        self._http.request("POST", self._entities_url(), headers=headers, json_body=entity)
        return entity.get("id")

    def update_entity(self, entity_id, attributes):
        url = build_url(self.base_url, f"/v2/entities/{entity_id}/attrs")
        headers = dict(self.headers)
        headers["Content-Type"] = "application/json"
        self._http.request("PATCH", url, headers=headers, json_body=attributes)
        return True

    def delete_entity(self, entity_id):
        url = build_url(self.base_url, f"/v2/entities/{entity_id}")
        self._http.request("DELETE", url, headers=self.headers)
        return True

    def get_capabilities(self):
        return {
            "ngsi_ld": False,
            "ngsi_v2": True,
            "pagination": True,
            "spatial_filter": None,
            "write_operations": None,
            "subscriptions": None,
        }
