# -*- coding: utf-8 -*-
"""
Adaptateur Scorpio Broker (https://scorpio.readthedocs.io/).
Aucune particularité forte imposée en dur ici faute de certitude
vérifiée ; ce fichier sert de point d'ancrage pour ajouter une
particularité réelle dès qu'elle est constatée en pratique.
"""
from .ngsild_broker import GenericNGSILDBroker


class ScorpioBroker(GenericNGSILDBroker):
    def get_capabilities(self):
        caps = super().get_capabilities()
        caps.update({
            "pagination": True,          # À VÉRIFIER selon version
            "spatial_filter": None,      # non confirmé — laissé à détecter
            "subscriptions": True,       # endpoint standard documenté
        })
        return caps
