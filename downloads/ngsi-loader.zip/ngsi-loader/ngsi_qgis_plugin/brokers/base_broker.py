# -*- coding: utf-8 -*-
"""
Interface commune que tout adaptateur de Context Broker doit implémenter.
Aucune logique spécifique à un broker ici.
"""
from abc import ABC, abstractmethod


class BaseBrokerClient(ABC):
    """Contrat commun à tous les adaptateurs (Stellio, Orion-LD, Scorpio, générique, custom...)."""

    @abstractmethod
    def test_connection(self):
        """Retourne {"ok": bool, "message": str, "details": dict|None}."""
        raise NotImplementedError

    @abstractmethod
    def get_entities(self, entity_type=None, query_params=None, limit=None, offset=None, is_cancelled_cb=None):
        """
        Retourne une liste d'entités brutes, au format natif du broker.
        is_cancelled_cb : callable optionnel, retourne True si l'appelant
                           (ex. QgsTask) a été annulé — permet d'interrompre
                           la lecture d'une réponse volumineuse en cours.
        """
        raise NotImplementedError

    @abstractmethod
    def get_entity(self, entity_id):
        """Retourne une entité unique, ou None si absente (404)."""
        raise NotImplementedError

    @abstractmethod
    def get_entity_types(self):
        """Retourne la liste des types d'entités disponibles."""
        raise NotImplementedError

    @abstractmethod
    def create_entity(self, entity):
        """Crée une entité."""
        raise NotImplementedError

    @abstractmethod
    def update_entity(self, entity_id, attributes):
        """Met à jour les attributs d'une entité existante."""
        raise NotImplementedError

    @abstractmethod
    def delete_entity(self, entity_id):
        """Supprime une entité."""
        raise NotImplementedError

    @abstractmethod
    def get_capabilities(self):
        """Retourne un dict de capacités connues/détectées."""
        raise NotImplementedError
