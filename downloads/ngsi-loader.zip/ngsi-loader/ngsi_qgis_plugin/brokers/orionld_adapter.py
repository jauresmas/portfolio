# -*- coding: utf-8 -*-
"""
Adaptateur Orion-LD (https://github.com/FIWARE/context.Orion-LD).
Particularité connue et largement documentée : Orion-LD peut exiger que
le contexte JSON-LD soit fourni explicitement (en-tête Link) si l'entité
n'embarque pas de @context — context_link est donc rendu obligatoire.
"""
from .ngsild_broker import GenericNGSILDBroker
from ..core.broker_client import BrokerError


class OrionLDBroker(GenericNGSILDBroker):
    def __init__(self, base_url, headers=None, timeout=30, verify_tls=True, context_link=None):
        if not context_link:
            raise BrokerError(
                "Un contexte JSON-LD (default_context) est requis pour se connecter à Orion-LD "
                "si les entités n'embarquent pas leur propre @context. "
                "Renseignez l'URL du contexte dans le profil de connexion."
            )
        super().__init__(base_url, headers=headers, timeout=timeout,
                          verify_tls=verify_tls, context_link=context_link)

    def get_capabilities(self):
        caps = super().get_capabilities()
        caps.update({
            "pagination": True,
            "spatial_filter": True,     # À VÉRIFIER selon la version d'Orion-LD déployée
            "subscriptions": True,
        })
        return caps
