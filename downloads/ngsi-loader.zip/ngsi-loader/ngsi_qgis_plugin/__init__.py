# -*- coding: utf-8 -*-
def classFactory(iface):
    from .plugin import NGSILoaderPlugin
    return NGSILoaderPlugin(iface)
